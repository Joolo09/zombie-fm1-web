"""Actual host input/control/splash regression, not a hardware test."""
from pathlib import Path
import subprocess,sys,re
R=Path(__file__).resolve().parents[2];F=R/'zombie-fix';O=F/'output/editions-0.8.2';D=O/'groovebox'
commands=[]
for section in ['HOME','FX','SEL','ENV','LFO','EDIT','GLO','ARP','SEQ']:
 commands+=['defaults',f'tap {section}','turn SELECT 1','expect bpm 133','expect subpage 0']
 if section!='HOME':commands +=[f'tap {section}','expect subpage 1','turn SELECT -1','expect bpm 132','expect subpage 1','tap HOME',f'tap {section}','expect subpage 1']
for layer,button in [(1,'FX'),(3,'ENV'),(4,'LFO'),(5,'EDIT'),(6,'GLO'),(7,'ARP'),(8,'SEQ'),(9,'REC')]:
 commands+=['defaults',f'press {button}','wait 220',f'expect layer {layer}','turn SELECT 1','expect bpm 133',f'release {button}','expect layer -1','expect locked 0']
commands+='''defaults
press FX
wait 220
tap HOME
release FX
expect layer 1
expect locked 1
key w0 down 100
expect effect 1
expect voices 0
key w0 up
expect effect 0
shot fx-locked-ru.png
tap ENV
expect layer -1
expect locked 0
expect section 3
defaults
press SEQ
tap HOME
release SEQ
expect layer 8
expect locked 1
tap OCT+
expect bank 1
expect octave 0
key b2 down 100
key b2 up
expect bank 2
expect octave 0
tap HOME
expect layer -1
expect locked 0
defaults
drumtest
turn K2 2
expect drum_choice 42
expect note 36
press SEQ
wait 220
key w0 down 100
key w0 up
expect note 36
expect chord1 43
key w0 down 100
key w0 up
expect note 36
expect velocity 100
expect chord1 0
release SEQ
turn K2 -2
expect drum_choice 36
press SEQ
key w0 down 100
key w0 up
expect velocity 0
release SEQ
press EDIT
tap OCT-
release EDIT
expect velocity 100
defaults
rolltest
press SEQ
key w0 down 100
key w0 up
expect velocity 0
key w0 down 100
key w0 up
release SEQ
expect velocity 100
expect duration 4
expect chord1 65
midiready
out
turn SELECT 1
expect_out USB BF 74 41
expect daw_bpm 133
turn SELECT -2
expect_out USB BF 74 3F
expect daw_bpm 131
tap GLO
turn SELECT 1
expect daw_bpm 132
tap GLO
turn K3 1
expect_out USB B0 07 60
turn K4 1
expect_out USB B0 0A 41
defaults
splashpreview
shot zombie-splash.png
'''.splitlines()
p=O/'controls-check.txt';p.write_text('\n'.join(commands)+'\n',encoding='utf-8')
r=subprocess.run([str(F/'editions/groovebox/build/host/zombie-groovebox_host'),str(p),str(D)],capture_output=True)
(O/'controls-check.log').write_bytes(r.stdout+r.stderr)
if r.returncode:print((r.stdout+r.stderr).decode(errors='replace'));raise SystemExit(r.returncode)
sys.path.insert(0,str(R/'.tooling/audio-deps'))
from PIL import Image
header=(F/'editions/assets/z_logo240.h').read_text();pal=[int(n) for n in re.search(r'Z_LOGO240_PAL\[\] = \{([^}]+)',header)[1].replace('\n','').split(',') if n.strip()];pixels=[int(n) for n in re.search(r'Z_LOGO240_PX\[\] = \{([^}]+)',header)[1].replace('\n','').split(',') if n.strip()]
im=Image.open(D/'zombie-splash.png').convert('RGB');max_error=0
for y in range(240):
 for x in range(240):
  c=pal[pixels[y*240+x]];expected=((c>>11)*255//31,((c>>5)&63)*255//63,(c&31)*255//31)
  max_error=max(max_error,max(abs(a-b) for a,b in zip(im.getpixel((x,y)),expected)))
assert max_error<=7,max_error
print('PASS: SELECT BPM on nine pages/eight layers/DAW, page memory, quick layer lock/unlock, bank keys, additive kit steps, preserved synth chords, MIDI volume/pan and exact Zombie artwork (RGB565 tolerance)')
