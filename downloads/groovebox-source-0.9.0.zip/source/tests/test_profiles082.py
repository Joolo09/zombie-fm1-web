"""FL / Live API contracts including SELECT tempo. No actual DAW session."""
from pathlib import Path
import subprocess,sys
F=Path(__file__).resolve().parents[1];O=F/'output/editions-0.8.2';P=F/'editions/profiles'
s=(F/'tests/test_fl_profile.py').read_text(encoding='utf-8')
s=s.replace("script=runpy.run_path(str(Path(__file__).resolve().parents[1]/'fl-studio/Zombie-Core-FM1/device_Zombie_Core_FM1.py'))",f'''sys.modules['midi']=SimpleNamespace(FPT_TempoJog=105,PME_System=2)
sys.modules['plugins']=SimpleNamespace(isValid=lambda i:True,getParamCount=lambda i:5,setParamValue=lambda *args:None)
def jog(command,value,flags):
 assert command==105
 state['tempo']+=value/10
 calls.append(('tempo',command,value,flags))
sys.modules['transport'].globalTransport=jog
script=runpy.run_path({str(P/'fl-studio/Zombie-Groovebox-FM1/device_Zombie_Groovebox_FM1.py')!r})''')
s=s.replace("Path(__file__).resolve().parents[1]/'output/core-verification/fl-feedback-wire.json'",repr(str(O/'fl-feedback.json'))).replace('out.write_text(json.dumps','Path(out).write_text(json.dumps')
s+='''
assert event(0xbf,116,65).handled and state['tempo']==141.0
assert calls[-1]==('tempo',105,10,2)
assert event(0xbf,116,62).handled and state['tempo']==139.0
n=len(calls);assert event(0xbf,116,64).handled and len(calls)==n
assert not event(0xb0,116,65).handled and state['tempo']==139.0
print('PASS FL: SELECT relative BPM +1/-2/neutral, channel isolation, official FPT_TempoJog contract')
'''
p=O/'test-fl-profile.py';p.write_text(s,encoding='utf-8')
def run(p,log):
 r=subprocess.run([sys.executable,'-X','utf8',str(p)],capture_output=True);(O/log).write_bytes(r.stdout+r.stderr)
 if r.returncode:print((r.stdout+r.stderr).decode(errors='replace'));raise SystemExit(r.returncode)
 print(r.stdout.decode().strip())
run(p,'fl-profile-tests.log')
s=(F/'tests/test_ableton_profile.py').read_text(encoding='utf-8').split("sys.path.insert(0,str(ROOT/'installer'))")[0]
s=s.replace("ROOT = Path(__file__).resolve().parents[1]",f'ROOT = Path({str(P)!r})').replace('Zombie_Core_FM1','Zombie_Groovebox_FM1')
s=s.replace('for cc in (110,114,115)]','for cc in (110,114,115,116)]')
s+='''
song.tempo=140.0;surface.receive_midi((0xbf,116,65));assert song.tempo==141
surface.receive_midi((0xbf,116,62));assert song.tempo==139
surface.receive_midi((0xbf,116,64));assert song.tempo==139
song.tempo=300;surface.receive_midi((0xbf,116,127));assert song.tempo==300
song.tempo=30;surface.receive_midi((0xbf,116,1));assert song.tempo==30
print('PASS Live: existing mappings/feedback/transport plus relative BPM and bounds; fake API only')
'''
p=O/'test-live-profile.py';p.write_text(s,encoding='utf-8');run(p,'live-profile-tests.log')
