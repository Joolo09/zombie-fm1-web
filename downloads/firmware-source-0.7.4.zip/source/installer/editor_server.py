"""Serve the bundled editor on loopback only; MIDI stays in the browser."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        super().end_headers()


def start(folder):
    folder = Path(folder).resolve()
    if not (folder / 'webapp/editor/index.html').exists():
        raise FileNotFoundError('В комплекте отсутствует веб-редактор.')
    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=str(folder)))
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, name='Zombie-editor', daemon=True).start()
    return server, f'http://127.0.0.1:{server.server_port}/webapp/editor/'
