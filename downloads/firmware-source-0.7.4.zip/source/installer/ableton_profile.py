"""Original MIT helper: locate a configured Live User Library and install only our files."""
from pathlib import Path
from datetime import datetime
import os
import shutil
import xml.etree.ElementTree as ET


def find_user_library(preferences_root=None):
    root = Path(preferences_root) if preferences_root else Path(os.environ.get('APPDATA', Path.home() / 'AppData/Roaming')) / 'Ableton'
    try:
        configs = sorted(root.glob('Live */Preferences/Library.cfg'), key=lambda p: p.stat().st_mtime, reverse=True)
    except OSError:
        configs = []
    for config in configs:
        try:
            node = ET.parse(config).find('.//UserLibrary/LibraryProject/ProjectPath')
            value = node.get('Value', '') if node is not None else ''
            if value and Path(value).is_dir():
                return Path(value)
        except (OSError, ET.ParseError):
            continue
    default = Path.home() / 'Documents/Ableton/User Library'
    return default if default.is_dir() else None


def install_profile(source, library):
    library = Path(library).resolve()
    if not library.is_dir():
        raise ValueError('Choose the existing Ableton User Library folder')
    target = library / 'Remote Scripts/Zombie_Core_FM1'
    # Resolve before writing: keep the destination inside the selected library.
    target.resolve().relative_to(library)
    target.mkdir(parents=True, exist_ok=True)
    for src in Path(source).iterdir():
        if src.is_file() and (src.suffix in ('.py', '.md') or src.name == 'LICENSE'):
            dst = target / src.name
            dst.resolve().relative_to(library)
            if dst.exists() and dst.read_bytes() != src.read_bytes():
                backup = dst.with_name(dst.name + '.bak-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
                shutil.copy2(dst, backup)
            shutil.copy2(src, dst)
    return target
