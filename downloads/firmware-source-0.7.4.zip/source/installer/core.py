"""FM-1 package checks and installation; no GUI or automatic device writes."""
from dataclasses import dataclass
from pathlib import Path
import binascii
import hashlib
import re
import struct

from vendor import fm1_install as protocol


@dataclass(frozen=True)
class Package:
    path: Path
    product: str
    image: bytes
    digest: bytes
    size: int

    @property
    def sha256(self):
        return self.digest.hex()


def decrypt(data):
    output = bytearray(data)
    key = 0xFFFF
    for i in range(len(output)):
        output[i] ^= key & 255
        key = ((key << 1) ^ (0x1021 if key & 0x8000 else 0)) & 0xFFFF
    return bytes(output)


def validate_image(image):
    """Verify the UFW header, table, extents and each file's CRC before MIDI I/O."""
    def require(condition, message):
        if not condition:
            raise ValueError(message)
    require(len(image) >= 0x400, 'Файл обрезан: отсутствует заголовок UFW.')
    header = decrypt(image[:0x40])
    crc, table_crc, total, count = struct.unpack_from('<HHIH', header)
    require(binascii.crc_hqx(header[2:], 0) == crc, 'Повреждён заголовок: неверная CRC.')
    require(header[16:22] == b'AC791N', 'Прошивка предназначена для другого процессора.')
    require(total == len(image), 'Размер пакета не совпадает с заголовком.')
    require(1 <= count <= 12 and 0x40 + count * 0x50 <= 0x400, 'Неверная таблица файлов.')
    table = image[0x40:0x40 + count * 0x50]
    require(binascii.crc_hqx(table, 0) == table_crc, 'Повреждена таблица файлов: неверная CRC.')
    names, spans = set(), []
    for index in range(count):
        entry = decrypt(table[index * 0x50:(index + 1) * 0x50])
        _, _, data_crc, _, offset, size, allocated = struct.unpack_from('<HHHHIII', entry)
        name = entry[0x40:0x50].split(b'\0')[0]
        require(size > 0 and allocated >= size and offset >= 0x400 and offset + size <= total,
                'Файл внутри прошивки выходит за границы пакета.')
        require(name not in names, 'Повторяющееся имя файла внутри пакета.')
        require(all(offset + size <= left or offset >= right for left, right in spans),
                'Файлы внутри пакета пересекаются.')
        require(binascii.crc_hqx(image[offset:offset + size], 0) == data_crc,
                f'Повреждены данные {name.decode("ascii", errors="replace")}: неверная CRC.')
        spans.append((offset, offset + size))
        names.add(name)
    require({b'flash.bin', b'ota.bin'}.issubset(names), 'Отсутствует flash.bin или ota.bin.')


def read_package(path):
    path = Path(path)
    if path.suffix.lower() != '.fwsc':
        raise ValueError('Выбери готовый файл прошивки .fwsc. ZIP с исходниками не подходит.')
    if not 960 <= path.stat().st_size <= 4 * 1024 * 1024:
        raise ValueError('Размер файла не соответствует поддерживаемому пакету FM-1.')
    raw = path.read_bytes()
    product = protocol.product_of(raw)
    if not re.fullmatch(r'FM-1_\d+', product):
        raise ValueError(f'Пакет не для FM-1: {product!r}.')
    image = protocol.logical_image(raw)
    digest = hashlib.sha256(raw).digest()
    if digest.hex() != protocol.STOCK_SHA256:
        if protocol.LOADER_MARK not in raw:
            raise ValueError('Не найден поддерживаемый загрузчик Felucca. Принудительная запись отключена.')
        validate_image(image)
    return Package(path, product, image, digest, len(raw))


def find_device(backend, port=None):
    updater = protocol.Updater(backend, port)
    dev = updater.find(lambda ident: ident.open or protocol.model_of(ident.text) == 'FM-1')
    if dev is None:
        raise ValueError('FM-1 не ответил. Подключи USB-кабель с передачей данных, закрой FL Studio '
                         'и другие MIDI-программы, затем повтори поиск.')
    return updater, dev


class TrackedBackend:
    """Release all ports, including a loader port opened after USB re-enumeration."""
    def __init__(self, backend):
        self.backend, self.links = backend, []

    def input_names(self):
        return self.backend.input_names()

    def output_names(self):
        return self.backend.output_names()

    def open(self, in_name, out_name):
        link = self.backend.open(in_name, out_name)
        self.links.append(link)
        return link

    def close(self):
        for link in self.links:
            link.close()


def inspect_device(backend, port=None):
    tracked = TrackedBackend(backend)
    try:
        _, dev = find_device(tracked, port)
        return dev.id.text, dev.name, dev.id.loader
    finally:
        tracked.close()


def install(package, backend, port=None, progress=lambda *args: None):
    # Reload before opening MIDI: a file replaced after selection must be approved again.
    fresh = read_package(package.path)
    if fresh.digest != package.digest:
        raise ValueError('Файл изменился после выбора. Выбери его заново и проверь SHA-256.')
    tracked = TrackedBackend(backend)
    try:
        updater, dev = find_device(tracked, port)
        return updater.install(dev, fresh.image, fresh.product, progress, fresh.digest)
    finally:
        tracked.close()
