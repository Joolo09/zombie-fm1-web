"""Isolated Core 0.7.4 audio/panel fix; production and Lab are preserved."""
from pathlib import Path
import os, sys, json, hashlib, subprocess, shutil, ast
from zipfile import ZipFile, ZIP_DEFLATED
FIX=Path(__file__).resolve().parent
ROOT=FIX.parent
OUT=FIX/'output'
VERSION='0.7.4'
FW=f'zombie-core-{VERSION}.fwsc'
APP=FIX/'zombie-core/firmware'
def verify_main():
    baseline=json.loads((FIX/'MAIN-BASELINE.json').read_text())
    changed=[p for p,h in baseline.items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
    if changed: raise RuntimeError('Production changed: '+', '.join(changed))
    previous=json.loads((FIX/'RELEASE-072-SHA256.json').read_text())
    assert all(hashlib.sha256((OUT/p).read_bytes()).hexdigest()==h for p,h in previous.items()), 'Previous release changed'
    previous3=json.loads((FIX/'RELEASE-073-SHA256.json').read_text())
    assert all(hashlib.sha256((OUT/p).read_bytes()).hexdigest()==h for p,h in previous3.items()), '0.7.3 release changed'
    return len(baseline)
def run(args,env,log):
    result=subprocess.run([str(a) for a in args],cwd=FIX,env=env,capture_output=True)
    (OUT/'verification'/log).write_bytes(result.stdout+result.stderr)
    if result.returncode:
        print((result.stdout+result.stderr).decode('utf-8',errors='replace')[-6500:])
        raise SystemExit(result.returncode)
    print(log+': PASS')
verify_main()
(OUT/'verification').mkdir(parents=True,exist_ok=True)
env=dict(os.environ,PYTHONUTF8='1',JIELI_TOOLCHAIN=str(ROOT/'.tooling/jieli-win/C$/JL/pi32'),
 AC79_SDK=str(ROOT/'.tooling/ac79-sdk'),X0X_FONTSET='terminus',CC=str(ROOT/'tools/host-cc.cmd'),
 ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.tooling/zig-global'),ZIG_LOCAL_CACHE_DIR=str(ROOT/'.tooling/zig-local'))
if '--installer-only' not in sys.argv and '--package-only' not in sys.argv:
    run([sys.executable,'-X','utf8',FIX/'platform/tools/build.py',APP,'--host','--release',VERSION],env,'host-build.log')
    for name in ['core-hat-knobs','core-night','core-arp-route','core-sampler-rec-night','core-audio-fix','core-device','core-midi','core-sampler','core-ableton']:
        dest=OUT/'verification'/name;dest.mkdir(exist_ok=True)
        run([APP/'build/host/zombie-core_host',FIX/f'tests/{name}.txt',dest],env,name+'.log')
    if '--host-only' in sys.argv: sys.exit(0)
    run([sys.executable,'-X','utf8',FIX/'platform/tools/build.py',APP,'--release',VERSION],env,'device-build.log')
    shutil.copy2(APP/'build'/FW,OUT/FW)
    site=OUT/'site/webapp/editor'
    for p in (FIX/'zombie-core/web').iterdir():
        if p.is_file():shutil.copy2(p,site/p.name)
    tree=ast.parse((ROOT/'tools/build-core.py').read_text(encoding='utf-8'))
    exports=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='exports' for t in n.targets))
    run([ROOT/'.tooling/zig-windows-x86_64-0.13.0/zig.exe','cc','-target','wasm32-freestanding','-O2','-ffp-contract=off','-ffreestanding','-nostdlib',
        '-DZ_WASM','-I'+str(APP/'build/gen'),APP/'dsp.c',APP/'output.c','-Wl,--no-entry','-Wl,--export-memory',
        *['-Wl,--export=z_'+n for n in exports],'-o',site/'zombie-core.wasm'],env,'wasm-build.log')
    fixture=OUT/'zombie-core-site/webapp/editor';fixture.mkdir(parents=True,exist_ok=True)
    for name in ['zombie-core.wasm','schema.json']:shutil.copy2(site/name,fixture/name)
    for name in ['test_hat_audio','test_core','test_core_night','test_core_sampler','test_core_system','test_core_midi']:
        run(['node',FIX/('tests/'+name+'.mjs')],env,name+'.log')
    for p in (OUT/'site').rglob('*'):
        if p.is_file() and p.suffix in ('.js','.html'):
            s=p.read_text(encoding='utf-8');p.write_text(s.replace('0.7.3','0.7.4'),encoding='utf-8')
if '--firmware-only' in sys.argv:
    print('Production preserved:',verify_main(),'files');sys.exit(0)
profile=FIX/'installer/profile.json'
profile.write_text(json.dumps(dict(ableton_profile='Zombie_Core_FM1',fl_profile='Zombie-Core-FM1',
 firmware=FW,title='Zombie Core 0.7.4 · проверка звука',heading='ZOMBIE CORE / AUDIO FIX',
 subtitle='0.7.4 · KNOB 2: фильтр · обновлённый хай-хет',
 editor_markers=['ZOMBIE CORE','sample-upload','language']),ensure_ascii=False),encoding='utf-8')
deps=ROOT/'.tooling/installer-deps'
exe='Zombie-Core-0.7.4-Standalone'
buildenv=dict(env,PYTHONPATH=str(deps),PYINSTALLER_CONFIG_DIR=str(FIX/'pyinstaller-config'))
if '--package-only' not in sys.argv: run([sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onefile','--windowed','--name',exe,
 '--icon',FIX/'installer/assets/icon.ico','--distpath',OUT,'--workpath',FIX/'installer-build','--specpath',FIX/'installer-build',
 '--paths',FIX/'installer','--paths',deps,'--hidden-import','mido.backends.rtmidi','--hidden-import','rtmidi','--collect-all','rtmidi',
 '--add-data',str(FIX/'installer/assets')+';assets','--add-data',str(profile)+';.',
 '--add-data',str(ROOT/'fl-studio/Zombie-Core-FM1')+';fl-studio/Zombie-Core-FM1',
 '--add-data',str(ROOT/'ableton/Zombie_Core_FM1')+';ableton/Zombie_Core_FM1',
 '--add-data',str(OUT/'site')+';site','--add-data',str(OUT/FW)+';firmware',FIX/'installer/app.py'],buildenv,'installer-build.log')
shutil.copy2(ROOT/'output/zombie-core-0.7.1.fwsc',OUT/'Return-to-Core-0.7.1.fwsc')
info=dict(version=VERSION,identity='FM-1_61000704',hardware_tested=False,main_preserved_files=verify_main(),
 firmware_sha256=hashlib.sha256((OUT/FW).read_bytes()).hexdigest(),hold_ms=450,
 home_controls=['preset','cutoff','resonance','level'],hat_envelope='single decay, brighter noise, auto voice release',fresh_default='standalone',saved_midi_mode_preserved=False,startup_midi_mode='standalone',audio_test='HOME then PLAY; 440 Hz triangle, 0.5 s, amplitude 0.06, 10 ms ramp; respects MASTER/trim',
 speaker_report='User confirmed built-in speaker working in 0.7.2; audio driver unchanged',notes='0.7.4 not tested on physical FM-1 by developer; HOME knobs and hat envelope verified in host/WASM. Audio hardware driver unchanged.')
(OUT/'BUILD-INFO.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
archive=OUT/'Zombie-Core-0.7.4-Standalone.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for name in [exe+'.exe',FW,'Return-to-Core-0.7.1.fwsc','BUILD-INFO.json']:
        z.write(OUT/name,name)
    z.write(FIX/'README-RU.md','README-RU.md')
    for folder in ['zombie-core','platform','installer','tests']:
        for p in (FIX/folder).rglob('*'):
            if p.is_file() and not set(p.relative_to(FIX).parts)&{'build','.git','__pycache__'}:
                z.write(p,'source/'+p.relative_to(FIX).as_posix())
    for name in ['build.py','MAIN-BASELINE.json','NIGHT-WORK.md','RELEASE-072-SHA256.json','RELEASE-073-SHA256.json','CONTROLS-HATS-074.md']:z.write(FIX/name,'source/'+name)
    for p in (APP/'build/gen').glob('z_*.h'):
        z.write(p,'source/'+p.relative_to(FIX).as_posix())
    for p in (OUT/'verification').rglob('*'):
        if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
    for p in (OUT/'site').rglob('*'):
        if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
    for p in (ROOT/'synth-base/assets/zombie-pack').glob('*'):
        if p.is_file():z.write(p,'audio-provenance/'+p.name)
    z.write(Path(sys.base_prefix)/'LICENSE.txt','licenses/Python.txt')
    for pattern in ['*.dist-info/LICENSE*','*.dist-info/COPYING*','*.dist-info/licenses/**/*']:
        for p in deps.glob(pattern):
            if p.is_file():z.write(p,'licenses/python-deps/'+p.relative_to(deps).as_posix())
    for p in (Path(sys.base_prefix)/'tcl').glob('*/license*'):
        if p.is_file():z.write(p,'licenses/tcl/'+p.parent.name+'-'+p.name)
with ZipFile(archive) as z:assert z.testzip() is None
for name in [exe+'.exe',FW,archive.name]:
    p=OUT/name;p.with_suffix(p.suffix+'.sha256').write_text(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n')
print('Production preserved:',verify_main(),'files; ready:',archive)
