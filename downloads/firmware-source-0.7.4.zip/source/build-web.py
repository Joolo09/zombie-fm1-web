"""Build a self-contained GitHub Pages folder; never rebuild or flash firmware."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
import hashlib
import json
import shutil

FIX = Path(__file__).resolve().parent
ROOT = FIX.parent
SITE = FIX / 'github-pages'
FW_SHA = '6201f815845bfb91e59fffc349b519330c122700a88aff6d766b30a635d9ed07'

def build(sync=False):
    SITE.mkdir(exist_ok=True)
    for p in (FIX / 'web-installer').rglob('*'):
        if p.is_file() and p.name != 'package.json':
            dest = SITE / p.relative_to(FIX / 'web-installer')
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)
    editor = SITE / 'webapp/editor'
    editor.mkdir(parents=True, exist_ok=True)
    for p in (FIX / 'zombie-core/web').iterdir():
        if p.is_file() and p.name != 'package.json':
            shutil.copy2(p, editor / p.name)
    for name in ['schema.json', 'zombie-core.wasm']:
        shutil.copy2(FIX / 'output/site/webapp/editor' / name, editor / name)
    downloads = SITE / 'downloads'
    downloads.mkdir(exist_ok=True)
    current = FIX / 'output/zombie-core-0.7.4.fwsc'
    assert hashlib.sha256(current.read_bytes()).hexdigest() == FW_SHA, 'Released firmware changed!'
    rollback = FIX / 'output/Return-to-Core-0.7.1.fwsc'
    assert rollback.read_bytes() == (ROOT / 'output/zombie-core-0.7.1.fwsc').read_bytes()
    releases = []
    for file, product, version, label, notes in [
        (current, 'FM-1_61000704', '0.7.4', {'ru':'Zombie Core 0.7.4 · текущая', 'en':'Zombie Core 0.7.4 · current'},
         {'ru':'Standalone при каждом запуске. KNOB 2 — фильтр. Обновлённые Closed / Open Hat.', 'en':'Standalone at every startup. KNOB 2 controls cutoff. Updated Closed / Open Hat.'}),
        (rollback, 'FM-1_61000701', '0.7.1', {'ru':'Zombie Core 0.7.1 · возврат', 'en':'Zombie Core 0.7.1 · rollback'},
         {'ru':'Возврат к прежней сборке. Старые настройки и режим запуска могут отличаться.', 'en':'Return to the earlier build. Settings and startup mode may differ.'})]:
        shutil.copy2(file, downloads / file.name)
        raw = file.read_bytes()
        releases.append(dict(product=product, version=version, label=label, notes=notes,
                             bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), file='downloads/'+file.name))
    (SITE / 'releases.json').write_text(json.dumps(dict(format='zombie-web/1', current=releases[0]['product'], releases=releases),ensure_ascii=False,indent=2)+'\n', encoding='utf-8')
    # Include the complete existing platform/application source. The current web
    # sources replace their previous snapshot; published firmware bytes stay exact.
    snapshot = downloads / 'firmware-source-0.7.4.zip'
    with ZipFile(FIX / 'output/Zombie-Core-0.7.4-Standalone.zip') as old, ZipFile(snapshot,'w',ZIP_DEFLATED) as out:
        for info in old.infolist():
            if info.filename.startswith(('source/','audio-provenance/')) and not info.filename.startswith('source/zombie-core/web/'):
                out.writestr(info, old.read(info))
        for folder, prefix in [(FIX/'zombie-core/web','source/zombie-core/web'), (FIX/'web-installer','source/web-installer')]:
            for p in folder.rglob('*'):
                if p.is_file(): out.write(p, prefix+'/'+p.relative_to(folder).as_posix())
        out.write(FIX/'build-web.py','source/build-web.py')
    licenses = SITE / 'licenses'
    licenses.mkdir(exist_ok=True)
    shutil.copy2(FIX/'zombie-core/LICENSE', SITE/'LICENSE')
    shutil.copy2(FIX/'platform/LICENSE', licenses/'MPL-2.0.txt')
    (licenses/'THIRD-PARTY.txt').write_text('''Zombie Core application, DSP, editor and installer UI: MIT. See ../LICENSE.
FM-1 hardware platform and update transport: Mozilla Public License 2.0.
fm1ota.js / fm1pkg.js: Copyright (C) 2026 Charles Vestal; Copyright (C) 2026
Leo Kuroshita (@kurogedelic), Hugelton Instruments.
Upstream: https://github.com/charlesvestal/fm1-base
Upstream snapshot: b16c177a9086be955cd3e418383f2fd92c6d658b
Zombie Core transport changes: resumed-update reboot/version verification,
MIDI port cleanup, loader model validation, byte progress, injectable test sleeps.
Source of these modified files: ../vendor/fm1ota.js and ../vendor/fm1pkg.js.
Complete firmware/platform source: ../downloads/firmware-source-0.7.4.zip.
Additional component notices are included with that source.
Minecraft sound effects: Mojang/Microsoft. Audio provenance and original asset
URLs / SHA-1 hashes are in audio-provenance/ inside the source archive.
M-VAVE and FM-1 are trademarks of their respective owners.
''',encoding='utf-8')
    (SITE/'.nojekyll').touch()
    (SITE/'package.json').write_text('{"type":"module","scripts":{"test":"node tests/web-installer.mjs"}}\n',encoding='utf-8')
    (SITE/'README.md').write_text('''# Zombie Core · FM-1 Web Studio

Веб-редактор Afterglow и установка Zombie Core по USB MIDI, RU / EN.
Сайт: https://joolo09.github.io/zombie-fm1-web/

Открой сайт в Chrome / Edge на компьютере. Для знакомства нажми «Открыть
студию». Для установки подключи один FM-1 USB-кабелем с передачей данных,
закрой DAW и другие MIDI-вкладки, нажми «Найти FM-1», затем «Установить».
Запрос MIDI требует разрешения SysEx. Загрузка страницы ничего не прошивает.
Установщик проверяет размер, SHA-256 и идентификатор файла до MIDI-доступа.
После обычной установки и повторной записи из загрузчика проверяется
идентификатор перезапущенного устройства. USB не отключать во время записи.
После обрыва повтори установку той же версии; поблочного продолжения нет.

Включение Pages: Settings → Pages → Deploy from a branch → main → / (root).
Все пути относительные, сайт работает и в подкаталоге репозитория.
Локальный просмотр: `python -m http.server 8080 --bind 127.0.0.1`.
Тесты без железа: `npm test`. Физическое устройство этими тестами не прошивается.

Прошивка 0.7.4 и возврат на 0.7.1 включены без изменения опубликованных байтов.
Web-версия 1.0 добавляет установку через браузер; номер прошивки не меняет.
Прошивка 0.7.4 проверена сборкой/host/WASM. Пользователь подтвердил динамик
в 0.7.2; веб-обновление на физическом FM-1 разработчиком не проверялось.
Редактор и сэмплы не отправляют пользовательское аудио на сервер.

Код приложения/синтеза и редактора — MIT; платформа и транспорт — MPL-2.0.
Исходники, notices и provenance: [архив](downloads/firmware-source-0.7.4.zip),
[компоненты](licenses/THIRD-PARTY.txt). Звуки Minecraft — Mojang/Microsoft.
''',encoding='utf-8')
    if (FIX/'tests/web-installer.mjs').exists():
        (SITE/'tests').mkdir(exist_ok=True)
        shutil.copy2(FIX/'tests/web-installer.mjs', SITE/'tests/web-installer.mjs')
    if sync:
        for dest in [ROOT/'output/zombie-core-site', FIX/'output/site']:
            shutil.copytree(SITE,dest,dirs_exist_ok=True,ignore=shutil.ignore_patterns('tests','package.json','README.md'))
    total=sum(p.stat().st_size for p in SITE.rglob('*') if p.is_file())
    print(f'GitHub Pages ready: {SITE} ({total:,} bytes); released firmware unchanged.')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--sync-preview',action='store_true')
    build(parser.parse_args().sync_preview)
