// A browser-created sample slot must sound through the real firmware SAMPLE engine.
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
const python=process.env.PYTHON;
if(!python) throw new Error('Set PYTHON to Python 3.');
execFileSync(python,['-c',`from pathlib import Path
import sys
sys.path.insert(0,'synth-base/tools')
import sampleio as s
sr,x=s.read_any_wav(Path('synth-base/assets/zombie-pack/ZOMBIE.wav'))
x=s.to_int16(s.resample(x,sr,s.SLOT_RATE))
h,d=s.user_slot('USRTEST',[(x,60,None,None)])
Path('.tooling/user-sample-test.bin').write_bytes((h+bytes(512-len(h))+d).ljust(s.SLOT_SIZE,b'\\xff'))
`]);
const {instance}=await WebAssembly.instantiate(fs.readFileSync('synth-base/build/preview/sloop-preview.wasm'),{});
const e=instance.exports;
e.preview_init(); e.preview_render();
new Uint8Array(e.memory.buffer,e.preview_buffer(),81920).set(fs.readFileSync('.tooling/user-sample-test.bin'));
e.preview_sample(0);
e.preview_factory(0,4,8);
e.preview_param(0,63,15); // P_E0 = 63; USR1 follows the 15 built-in sets.
for(let i=0;i<32;i++)e.preview_render();
e.preview_note(0,60,1);
let peak=0,energy=0;
for(let i=0;i<1600;i++){
  const samples=new Float32Array(e.memory.buffer,e.preview_render(),e.preview_frames()*2);
  for(const sample of samples){assert(Number.isFinite(sample));peak=Math.max(peak,Math.abs(sample));energy+=sample*sample;}
}
assert(peak>.01 && energy>1,'uploaded user sample is silent');
console.log('PASS: user WAV -> slot header/ADPCM -> user flash -> SAMPLE USR1 -> audible real-DSP output; peak',peak.toFixed(3));
