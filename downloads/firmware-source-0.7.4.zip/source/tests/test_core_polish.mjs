import fs from 'node:fs';
import assert from 'node:assert/strict';
import {PatternHistory,Link,AudioEngine,STATE_BYTES,decodeState,encodeState} from '../zombie-core/web/core.js';
import {CoreDSP} from '../zombie-core/web/worklet.js';
const module=await WebAssembly.compile(fs.readFileSync('output/zombie-core-site/webapp/editor/zombie-core.wasm'));
const make=()=>{const w=new WebAssembly.Instance(module,{}).exports;w.z_init();return w;};
const bytes=w=>new Uint8Array(w.memory.buffer,w.z_snapshot(),STATE_BYTES);
const state=w=>decodeState(bytes(w).slice());
const render=(w,n=256)=>{while(n){const count=Math.min(n,256);w.z_render(w.z_buffer(),count);n-=count;}};
const pattern=s=>s.tracks.map(t=>({length:t.p[23],steps:structuredClone(t.steps)}));
{
 const w=make();w.z_set(0,23,4);w.z_step_set(0,0,60,110,127,95);w.z_step_set(0,1,62,90,127,70);
 const s=state(w);s.tracks[0].steps[0].chord=[65,68,73];s.tracks[0].steps[0].duration=3;bytes(w).set(encodeState(s));w.z_history_reset();
 const before=state(w);assert.equal(w.z_pattern(0,1,0),0);let after=state(w);assert.equal(after.tracks[0].p[23],8);assert.deepEqual(after.tracks[0].steps.slice(0,4),after.tracks[0].steps.slice(4,8));
 assert.equal(w.z_history(0),1);assert.deepEqual(pattern(state(w)),pattern(before));assert.equal(w.z_history(1),1);assert.deepEqual(pattern(state(w)),pattern(after));
 assert.equal(w.z_pattern(0,2,0),0);assert.equal(w.z_pattern(0,3,0),0);assert.deepEqual(pattern(state(w)),pattern(after));
 w.z_pattern(0,5,0);w.z_pattern(0,5,0);assert.deepEqual(pattern(state(w)),pattern(after));
 const targetSound=state(w).tracks[1].p.slice();w.z_pattern(0,4,1);const copied=state(w);assert.deepEqual(copied.tracks[0].steps,copied.tracks[1].steps);targetSound[23]=8;assert.deepEqual(copied.tracks[1].p,targetSound);
 const old=pattern(state(w));w.z_pattern(0,0,0);assert(state(w).tracks[0].steps.every(s=>s.velocity===0&&s.duration===0&&s.chord.every(n=>n===0)));w.z_history(0);assert.deepEqual(pattern(state(w)),old);
 w.z_history_reset();for(let i=0;i<8;i++)w.z_pattern(0,2,0);assert.equal(w.z_history_state()&255,4);for(let i=0;i<4;i++)assert.equal(w.z_history(0),1);assert.equal(w.z_history(0),0);assert.equal(w.z_history_state()>>8,4);
 w.z_pattern(0,2,0);assert.equal(w.z_history_state()>>8,0,'new edit clears redo branch');
 w.z_set(0,23,64);const rev=w.z_revision(),hist=w.z_history_state(),oldState=state(w);assert.equal(w.z_pattern(0,1,0),-1);assert.equal(w.z_pattern(0,4,0),-1);assert.equal(w.z_pattern(0,9,1),-1);assert.equal(w.z_pattern(6,0,0),-1);assert.equal(w.z_revision(),rev);assert.equal(w.z_history_state(),hist);assert.deepEqual(state(w),oldState);
}
console.log('PASS duplicate / rotate / reverse / copy / clear preserve chords, duration and destination sound; atomic validation and four-level history');
{
 const w=make();const before=state(w);w.z_record(1);w.z_key(0,60,100,1);w.z_key(0,67,90,1);render(w,13000);w.z_key(0,60,0,0);w.z_key(0,67,0,0);w.z_record(0);const take=pattern(state(w));
 w.z_transport(1);assert.equal(w.z_history(0),1);assert.equal(w.z_playing(),1);assert.equal(state(w).recording,0);assert.deepEqual(pattern(state(w)),pattern(before));assert.equal(w.z_history(1),1);assert.deepEqual(pattern(state(w)),take);
 w.z_pattern(0,6,0);const generated=pattern(state(w));w.z_history(0);assert.deepEqual(pattern(state(w)),take);w.z_history(1);assert.deepEqual(pattern(state(w)),generated);
}
console.log('PASS a complete recorded take and generated rhythm undo as one action, while transport keeps playing');
{
 const dsp=new CoreDSP(module),w=dsp.w,s=state(w);s.recording=1;s.tracks[0].steps[5].velocity=100;dsp.state(encodeState(s));w.z_key(0,64,90,1);render(w,1000);w.z_key(0,64,0,0);w.z_record(0);w.z_history(0);assert.equal(state(w).tracks[0].steps[0].velocity,0);assert.equal(state(w).tracks[0].steps[5].velocity,100,'first state is applied before recording checkpoint');
}
console.log('PASS worklet captures the correct baseline even when PC audio starts with REC armed');
{
 const dsp=new CoreDSP(module),w=dsp.w,baseline=state(w);dsp.state(encodeState(baseline));const armed=structuredClone(baseline);armed.recording=1;dsp.state(encodeState(armed));w.z_key(0,60,100,1);render(w,4000);w.z_key(0,60,0,0);w.z_record(0);assert.equal(state(w).tracks[0].steps[0].velocity,100);
 // Baseline bytes equal the previous control snapshot: an explicit pattern replacement must still win.
 dsp.state(encodeState(baseline),true);assert.equal(state(w).tracks[0].steps[0].velocity,0);render(w,8000);assert.equal(state(w).tracks[0].steps[0].velocity,0);
}
console.log('PASS forced Undo snapshot replaces freshly captured audio-thread notes even when UI baseline bytes are unchanged');
{
 const w=make();w.z_set(0,13,0);w.z_set(0,14,0);const mute=state(w).tracks.map(t=>t.p[21]);w.z_solo(2);w.z_note(0,60,100,1);render(w);assert(new Float32Array(w.memory.buffer,w.z_buffer(),512).every(x=>x===0));w.z_solo(0);render(w);assert(new Float32Array(w.memory.buffer,w.z_buffer(),512).some(x=>Math.abs(x)>.001));assert.deepEqual(state(w).tracks.map(t=>t.p[21]),mute);w.z_solo(3);w.z_transport(0);assert.equal(w.z_solo_state(),0);
}
console.log('PASS SOLO actually isolates audio, leaves mute settings intact and resets on Stop');
{
 const s=state(make()),history=new PatternHistory();history.reset(s);const before=pattern(s);history.checkpoint(s);s.recording=1;
 s.tracks[0].steps[0]={note:60,velocity:100,chance:127,gate:70,chord:[65,68,0],duration:2};history.observe(s,true);s.tracks[0].steps[1].velocity=80;history.observe(s,true);s.recording=0;
 const take=pattern(s),undone=history.restore(s);assert.deepEqual(pattern(undone),before);assert.deepEqual(pattern(history.restore(undone,true)),take);
 s.tracks[0].p[4]=42;const undoneAgain=history.restore(s);assert.equal(undoneAgain.tracks[0].p[4],42,'undo never changes sound controls');
 for(let i=0;i<9;i++){s.tracks[0].steps[0].velocity=i;history.observe(s);}assert.equal(history.past.length,4);assert.equal(history.future.length,0);
}
console.log('PASS browser four-level history matches recorded-take boundaries and preserves sound parameters');
{
 const link=new Link();link.modern=true;const data=new Uint8Array(23);data.set([4,1,17,0,3,8,0,1,17,0,0,1]);new DataView(data.buffer).setUint32(12,123,true);data.set([9,5,150,0,4,2,3],16);link.command=async()=>data;const r=await link.runtime();assert.equal(r.undo,4);assert.equal(r.redo,2);assert.equal(r.solo,3);assert.equal(r.bpm,150);assert.equal(r.revision,123);
 const audio=new AudioEngine(module,()=>{}),messages=[];audio.node={port:{postMessage:d=>messages.push(d)}};audio.send('state',{bytes:new Uint8Array(0)});audio.send('note',{on:1});audio.send('state',{bytes:new Uint8Array(0),forcePattern:true});assert.deepEqual(messages.map(m=>m.epoch),[1,1,2]);assert(messages[2].forcePattern);
}
console.log('PASS v4 MIDI runtime exposes history and SOLO; audio state epochs reject stale post-Undo snapshots');
