/* Regression tests for real key release, recording and live editing, using the shipped C DSP. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {CoreDSP} from '../zombie-core/web/worklet.js';
import {STATE_BYTES,decodeState,encodeState,validateState} from '../zombie-core/web/core.js';
const module=await WebAssembly.compile(fs.readFileSync('output/zombie-core-site/webapp/editor/zombie-core.wasm'));
const schema=JSON.parse(fs.readFileSync('output/zombie-core-site/webapp/editor/schema.json'));
const make=()=>{const w=new WebAssembly.Instance(module,{}).exports;w.z_init();return w;};
const state=w=>decodeState(new Uint8Array(w.memory.buffer,w.z_snapshot(),STATE_BYTES).slice());
const advance=(w,frames)=>{while(frames>0){const n=Math.min(256,frames);w.z_render(w.z_buffer(),n);assert(new Float32Array(w.memory.buffer,w.z_buffer(),n*2).every(Number.isFinite));frames-=n;}};
for(let mode=1;mode<=4;mode++){
 const w=make();w.z_set(0,9,127);w.z_arp_set(0,0,mode);w.z_arp_set(0,2,3);
 for(let round=0;round<10;round++){
  w.z_key(0,60,100,1);w.z_key(0,64,100,1);advance(w,15000);assert(w.z_voice_count()>0);
  w.z_key(0,60,0,0);advance(w,6000);w.z_key(0,64,0,0);w.z_sustain(0,0);advance(w,3000);
  assert.equal(w.z_voice_count(),0,`ARP ${mode} must stop after last release, without panic`);
  advance(w,30000);assert.equal(w.z_voice_count(),0,'released notes must never retrigger');
 }
}
console.log('PASS all ARP modes: repeated chords, octave expansion, last-note release, no panic required');
{
 const w=make();w.z_arp_set(0,0,1);w.z_arp_set(0,3,1);w.z_key(0,60,100,1);advance(w,1000);w.z_key(0,60,0,0);advance(w,12000);assert(w.z_voice_count()>0);
 w.z_arp_set(0,3,0);advance(w,3000);assert.equal(w.z_voice_count(),0);w.z_transport(0);assert.equal(state(w).recording,0);
}
console.log('PASS explicit HOLD remains intentional; switching HOLD off releases the latched chord');
{
 const w=make();w.z_record(1);w.z_key(0,60,100,1);w.z_key(0,64,90,1);w.z_key(0,67,85,1);w.z_key(0,72,80,1);
 advance(w,13000);w.z_key(0,60,0,0);assert.equal(state(w).stepEdit,0);
 for(const n of [64,67,72])w.z_key(0,n,0,0);
 const s=state(w),step=s.tracks[0].steps[0];assert.equal(s.stepEdit,1);assert.equal(step.note,60);assert.deepEqual(step.chord,[65,68,73]);assert.equal(step.duration,2);assert(step.gate>=40&&step.gate<=48);
 w.z_record(0);w.z_reset_audio();w.z_transport(1);advance(w,256);assert.equal(w.z_voice_count(),4);
 w.z_transport(0);assert.equal(w.z_voice_count(),0);assert.equal(state(w).recording,0);
 validateState(s,schema);assert.deepEqual(decodeState(encodeState(s)),s);
}
console.log('PASS step-record chords, one advance per chord, measured multi-step duration, four-voice replay and stop disarm');
{
 const w=make();w.z_transport(1);w.z_record(1);advance(w,4000);w.z_key(0,62,100,1);advance(w,3300);w.z_key(0,62,0,0);
 const s=state(w);assert.equal(s.tracks[0].steps[0].velocity,0);assert.equal(s.tracks[0].steps[1].note,62);assert.equal(s.tracks[0].steps[1].velocity,100);
 w.z_transport(0);assert.equal(state(w).recording,0);
 w.z_key(0,69,100,1);advance(w,256);w.z_key(0,69,0,0);assert.equal(state(w).tracks[0].steps[2].velocity,0);
}
console.log('PASS nearest-grid real-time input and no accidental recording after Stop');
{
 const dsp=new CoreDSP(module),w=dsp.w,s=state(w);s.recording=1;dsp.state(encodeState(s));w.z_key(0,60,100,1);advance(w,4000);w.z_key(0,60,0,0);
 s.tracks[0].p[4]=70;dsp.state(encodeState(s));assert.equal(state(w).tracks[0].steps[0].velocity,100,'UI edit must preserve fresh audio-thread notes');
 s.recording=0;dsp.state(encodeState(s));assert.equal(state(w).recording,0);
 s.arp[0].mode=1;dsp.state(encodeState(s));w.z_key(0,60,100,1);advance(w,5000);w.z_key(0,60,0,0);s.bpm=130;dsp.state(encodeState(s));advance(w,3000);assert.equal(w.z_voice_count(),0);
}
console.log('PASS browser control-state merges preserve takes and never resurrect released ARP keys');
for(let effect=1;effect<=16;effect++){
 const w=make();w.z_note(0,60,100,1);w.z_live(effect);advance(w,1200);w.z_live(0);advance(w,1000);assert.equal(state(w).tracks[0].p[15],95);
}
console.log('PASS 16 momentary effects: bounded finite output and no destructive patch changes');
{
 const w=make();w.z_external(1);w.z_clock(250);for(let i=0;i<49;i++){w.z_clock(248);advance(w,735);}assert.equal(state(w).bpm,150);
 advance(w,120000);assert.equal(w.z_playing(),0,'clock loss must stop rather than leave an armed take running');
}
console.log('PASS MIDI clock follows measured 150 BPM; clock-loss watchdog stops playback');
for(const legacy of [true,2]){const s=state(make());s.language=1;s.tracks[2].p[4]=47;const decoded=decodeState(encodeState(s,legacy));validateState(decoded,schema);assert.equal(decoded.tracks[2].p[4],47);assert.equal(decoded.language,1);}
console.log('PASS v1 and v2 project migrations preserve sound and language');
