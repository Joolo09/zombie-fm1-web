import fs from 'node:fs';
import assert from 'node:assert/strict';
const module=await WebAssembly.compile(fs.readFileSync('output/zombie-core-site/webapp/editor/zombie-core.wasm'));
function hit(preset,cutoff){const w=new WebAssembly.Instance(module,{}).exports;w.z_init();w.z_preset(0,preset);w.z_set(0,13,0);w.z_set(0,14,0);if(cutoff!==undefined)w.z_set(0,4,cutoff);w.z_key(0,60,100,1);const a=[];
 for(let at=0;at<88200;at+=256){const n=Math.min(256,88200-at);w.z_render(w.z_buffer(),n);const b=new Float32Array(w.memory.buffer,w.z_buffer(),n*2);for(let i=0;i<n;i++){const x=(b[i*2]+b[i*2+1])*.5;assert(Number.isFinite(x)&&Math.abs(x)<.981);a.push(x);}}
 assert.equal(w.z_voice_count(),0,'silent transient must release its voice without a key-up');
 const rms=(l,h)=>Math.sqrt(a.slice(l,h).reduce((s,x)=>s+x*x,0)/(h-l));return {preset,a,first10ms:rms(0,441),at20to50ms:rms(882,2205),at100to200ms:rms(4410,8820)};
}
const rows=[10,54,53].map(p=>hit(p));
for(const row of rows)assert(row.at20to50ms>row.first10ms*.10,`hat preset ${row.preset} must have an audible body after its attack`);
assert(rows[1].at100to200ms<rows[1].first10ms*.05,'closed hat must still decay promptly');
assert(rows[2].at100to200ms>rows[1].at100to200ms*5,'open and closed hats need distinct lengths');
const dark=hit(10,35);assert(rows[0].first10ms>dark.first10ms*3,'main cutoff must still control hat brightness');
const a=rows.flatMap(r=>r.a.slice(0,44100)),pcm=Buffer.alloc(a.length*2),h=Buffer.alloc(44);
a.forEach((x,i)=>pcm.writeInt16LE(Math.round(x*32767),i*2));h.write('RIFF');h.writeUInt32LE(pcm.length+36,4);h.write('WAVEfmt ',8);h.writeUInt32LE(16,16);h.writeUInt16LE(1,20);h.writeUInt16LE(1,22);h.writeUInt32LE(44100,24);h.writeUInt32LE(88200,28);h.writeUInt16LE(2,32);h.writeUInt16LE(16,34);h.write('data',36);h.writeUInt32LE(pcm.length,40);
fs.writeFileSync('output/verification/hats-after-074.wav',Buffer.concat([h,pcm]));
fs.writeFileSync('output/verification/hats-after-074.json',JSON.stringify(rows.map(({a,...r})=>r),null,2));
console.log('PASS: audible hat body, open/closed timing, cutoff, finite output and transient voice cleanup');
