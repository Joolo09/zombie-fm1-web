"""MIT: FL API contract tests with isolated fake modules; not a claim of testing inside FL."""
from pathlib import Path
from types import SimpleNamespace
import json
import runpy
import sys

clock=[1.0];state=dict(selected=0,count=6,playing=False,recording=False,tempo=140.0,volume=.75,pan=0.0,name='Мой FLEX')
calls=[];frames=[]
def start():state['playing']=True;calls.append('start')
def stop():state['playing']=False;calls.append('stop')
def record():state['recording']=not state['recording'];calls.append('record')
def select(index):state['selected']=index;calls.append(('select',index))
def volume(index,value):state['volume']=value;calls.append(('volume',index,value))
def pan(index,value):state['pan']=value;calls.append(('pan',index,value))
sys.modules['channels']=SimpleNamespace(channelCount=lambda:state['count'],selectedChannel=lambda *args:state['selected'],getChannelName=lambda i:state['name'],getChannelVolume=lambda i:state['volume'],getChannelPan=lambda i:state['pan'],setChannelVolume=volume,setChannelPan=pan,selectOneChannel=select)
sys.modules['device']=SimpleNamespace(isAssigned=lambda:True,midiOutSysex=frames.append)
sys.modules['mixer']=SimpleNamespace(getCurrentTempo=lambda:state['tempo'])
sys.modules['transport']=SimpleNamespace(isPlaying=lambda:state['playing'],isRecording=lambda:state['recording'],start=start,stop=stop,record=record)
script=runpy.run_path(str(Path(__file__).resolve().parents[1]/'fl-studio/Zombie-Core-FM1/device_Zombie_Core_FM1.py'))
scope=script['OnIdle'].__globals__;scope['time']=SimpleNamespace(monotonic=lambda:clock[0])
def event(status,a,b):
 e=SimpleNamespace(status=status,data1=a,data2=b,handled=False);script['OnMidiMsg'](e);return e
script['OnInit']();assert len(frames)==2
assert frames[0][5:8]==bytes([33,0,1])
first=frames[1];assert first[:4]==bytes([240,125,90,67]) and first[5]==32 and first[-1]==247
data=[];packed=first[6:-1]
for at in range(0,len(packed),8):
 group=packed[at:at+8];data.extend(value|((group[0]>>bit&1)<<7) for bit,value in enumerate(group[1:]))
assert data[:7]==[0,0,140,0,0,95,64] and bytes(data[7:]).decode('utf-8')=='Мой FLEX'
assert not event(0x90,60,100).handled and not event(0x80,60,0).handled
assert not event(0xb0,74,100).handled and not event(0xb0,71,90).handled
event(0xbf,114,127);event(0xbf,114,127);assert calls.count('start')==1
event(0xbf,114,0);event(0xbf,114,0);assert calls.count('stop')==1
event(0xbf,115,127);event(0xbf,115,127);assert calls.count('record')==1
event(0xbf,115,0);assert calls.count('record')==2 and not state['recording']
event(0xbf,110,3);assert state['selected']==3
event(0xbf,110,6);assert state['selected']==3
event(0xb3,7,127);assert state['volume']==1.0
for value,want in [(0,-1.0),(64,0.0),(127,1.0)]:event(0xb3,10,value);assert state['pan']==want
state['selected']=-1;before=len(calls);event(0xb0,7,99);assert len(calls)==before;state['selected']=0
clock[0]+=.1;script['OnIdle']();assert len(frames)==2
clock[0]+=.2;script['OnIdle']();assert len(frames)==4
clock[0]+=.5;script['OnIdle']();assert len(frames)==4
clock[0]+=.6;script['OnIdle']();assert len(frames)==6
state['name']='я'*40+'🎹';assert len(scope['_name_bytes'](state['name']))<=47;scope['_name_bytes'](state['name']).decode('utf-8')
e=SimpleNamespace(sysex=bytes([240,125,90,67,1,96,0,0,247]),handled=False);script['OnSysEx'](e);assert e.handled
scope['device'].isAssigned=lambda:False;clock[0]+=2;script['OnIdle']();assert len(frames)==6
out=Path(__file__).resolve().parents[1]/'output/core-verification/fl-feedback-wire.json';out.write_text(json.dumps(dict(frame_hex=first.hex(),payload=data),indent=2),encoding='utf-8')
print('PASS: FL API contracts, notes/macros passthrough, idempotent PLAY/REC, selection, volume/pan, feedback framing/rate limit/UTF-8 and no note echo')
