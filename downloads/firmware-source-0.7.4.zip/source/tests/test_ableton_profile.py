"""MIT: isolated Live API contracts; does not substitute for testing in Live."""
import contextlib
import importlib
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace as NS

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
clock = [10.0]
forwarded, frames, calls = [], [], []
active = [None]

class Surface:
    def __init__(self, host):
        self.host = host
        self.controls = []
        self.received = []
    @contextlib.contextmanager
    def component_guard(self):
        previous, active[0] = active[0], self
        try: yield
        finally: active[0] = previous
    def song(self): return self.host.song
    def build_midi_map(self, handle): calls.append(('build', handle))
    def update_display(self): pass
    def receive_midi(self, data): self.received.append(data)
    def _send_midi(self, data, optimized=None): frames.append(data)
    def disconnect(self): calls.append('disconnect')
    def log_message(self, text): calls.append(text)

class Encoder:
    def __init__(self, kind, channel, cc, mode, **kw):
        self.channel, self.cc, self.parameter = channel, cc, None
        self.connections = self.releases = 0
        active[0].controls.append(self)
    def connect_to(self, parameter):
        self.parameter = parameter
        self.connections += 1
    def release_parameter(self):
        self.parameter = None
        self.releases += 1

sys.modules['Live'] = NS(MidiMap=NS(MapMode=NS(absolute=0), forward_midi_cc=lambda *args: forwarded.append(args)))
sys.modules['_Framework'] = NS()
sys.modules['_Framework.ControlSurface'] = NS(ControlSurface=Surface)
sys.modules['_Framework.EncoderElement'] = NS(EncoderElement=Encoder)
sys.modules['_Framework.InputControlElement'] = NS(MIDI_CC_TYPE=1)
sys.path.insert(0, str(ROOT / 'ableton'))
package = importlib.import_module('Zombie_Core_FM1')
module = importlib.import_module('Zombie_Core_FM1.surface')
module.time = NS(monotonic=lambda: clock[0])

def parameter(value=0.5, low=0, high=1):
    return NS(value=value, min=low, max=high, is_enabled=True)

def track(index):
    device = NS(name='Инструмент Rack', parameters=[parameter() for _ in range(5)])
    return NS(name='Track %d' % index, view=NS(selected_device=device),
              mixer_device=NS(volume=parameter(.75), panning=parameter(0, -1, 1)))

tracks = [track(i) for i in range(7)]
song = NS(tracks=tracks, view=NS(selected_track=tracks[0]), tempo=128.0,
          is_playing=False, record_mode=False, session_record=False)
def start(): song.is_playing = True; calls.append('start')
def stop(): song.is_playing = False; calls.append('stop')
song.start_playing, song.stop_playing = start, stop
surface = package.create_instance(NS(song=song, handle=lambda: 17))
assert len(surface.controls) == 96 and not frames and not song.record_mode
assert [g[0].cc for g in surface._encoders] == [74, 71, 73, 72, 7, 10]
for index, group in enumerate(surface._encoders):
    assert [e.channel for e in group] == list(range(16))
    expected = tracks[0].view.selected_device.parameters[index+1] if index < 4 else (
        tracks[0].mixer_device.volume if index == 4 else tracks[0].mixer_device.panning)
    assert all(e.parameter is expected for e in group)
surface.build_midi_map(99)
assert forwarded == [(17, 99, 15, cc) for cc in (110,114,115)]
assert calls[-1] == ('build',99)

def decode(frame):
    out = []
    packed = frame[6:-1]
    for at in range(0, len(packed),8):
        block = packed[at:at+8]
        out.extend(value | (((block[0] >> bit) & 1) << 7) for bit,value in enumerate(block[1:]))
    return out

surface.update_display()
assert len(frames) == 2 and frames[0][5] == 33 and decode(frames[0]) == [2]
assert frames[1][:4] == (240,125,90,67) and frames[1][5] == 32
payload = decode(frames[1])
assert payload[:7] == [0,0,128,0,0,95,64]
assert bytes(payload[7:]).decode('utf-8') == 'Инструмент Rack'
assert all(0 <= n < 128 for n in frames[1][1:-1])
clock[0] += .3; surface.update_display(); assert len(frames) == 2
clock[0] += .8; surface.update_display(); assert len(frames) == 4
count = sum(e.connections for e in surface.controls)
surface.update_display(); assert sum(e.connections for e in surface.controls) == count
for data in [(0x90,60,100),(0x80,60,0),(0xb0,74,100)]: surface.receive_midi(data)
assert len(surface.received) == 3 and len(frames) == 4
for command in (96,97): surface.receive_midi((240,125,90,67,1,command,0,0,247))
assert len(surface.received) == 3
for value in (127,127,0,0): surface.receive_midi((0xbf,114,value))
assert calls.count('start') == calls.count('stop') == 1
surface.receive_midi((0xbf,115,127)); surface.receive_midi((0xbf,115,127))
assert song.record_mode and not song.session_record
surface.receive_midi((0xbf,115,0)); assert not song.record_mode
module.RECORD_TARGET='session'
surface.receive_midi((0xbf,115,127)); assert song.session_record and not song.record_mode
surface.receive_midi((0xbf,115,0)); assert not song.session_record
module.RECORD_TARGET='arrangement'
surface.receive_midi((0xbf,110,5)); assert song.view.selected_track is tracks[5]
surface.receive_midi((0xbf,110,6)); assert song.view.selected_track is tracks[5]
device=tracks[5].view.selected_device
device.parameters[2].is_enabled=False
device.parameters=device.parameters[:4]
surface.update_display()
assert all(e.parameter is None for e in surface._encoders[1]+surface._encoders[3])
assert all(e.parameter is device.parameters[3] for e in surface._encoders[2])
tracks[5].view.selected_device=None
surface.update_display()
assert all(e.parameter is None for group in surface._encoders[:4] for e in group)
song.view.selected_track=tracks[6]; clock[0]+=2; surface.update_display()
assert decode(frames[-1])[4] == 255
for value,want in [(-1,0),(0,64),(1,127)]:
    tracks[6].mixer_device.panning.value=value
    surface._feedback(True); assert decode(frames[-1])[6] == want
name=module.screen_name('я'*50+'🎹'); assert len(name)<=47; bytes(name).decode('utf-8')
surface.disconnect(); count=len(frames); surface.update_display()
assert calls[-1]=='disconnect' and len(frames)==count
assert all(e.parameter is None and e.releases for e in surface.controls)

sys.path.insert(0,str(ROOT/'installer'))
from ableton_profile import find_user_library, install_profile
with tempfile.TemporaryDirectory() as temp:
    root=Path(temp); library=root/'My Library'; library.mkdir()
    pref=root/'Ableton/Live 12.4/Preferences'; pref.mkdir(parents=True)
    (pref/'Library.cfg').write_text('<Ableton><UserLibrary><LibraryProject><ProjectPath Value="'+library.as_posix()+'"/></LibraryProject></UserLibrary></Ableton>',encoding='utf-8')
    assert find_user_library(root/'Ableton') == library
    source=ROOT/'ableton/Zombie_Core_FM1'
    target=install_profile(source,library)
    assert target == library/'Remote Scripts/Zombie_Core_FM1'
    (target/'settings.py').write_text('# previous settings',encoding='utf-8')
    install_profile(source,library)
    backups=list(target.glob('settings.py.bak-*'))
    assert len(backups)==1 and backups[0].read_text()=='# previous settings'
    assert (target/'surface.py').read_bytes()==(source/'surface.py').read_bytes()
    try: install_profile(source,root/'missing')
    except ValueError: pass
    else: raise AssertionError('must reject missing library')
print('PASS: Ableton 96 native mappings, device changes, note passthrough/no echo, transport, feedback UTF-8/rate, disconnect, library discovery and backup-safe install. Stub APIs; Live/hardware untested.')
