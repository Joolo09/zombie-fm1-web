import fs from 'node:fs';
import assert from 'node:assert/strict';
import {crc32,pack7,unpack7,decodeState,encodeState,validateState,resamplePCM,wavPCM,Link,STATE_BYTES,PRESETS} from '../zombie-core/web/core.js';
const path='output/zombie-core-site/webapp/editor/';
const module=await WebAssembly.compile(fs.readFileSync(path+'zombie-core.wasm'));
assert.equal(WebAssembly.Module.imports(module).length,0);
const make=()=>{const w=new WebAssembly.Instance(module,{}).exports;w.z_init();return w;};
assert.equal(PRESETS.length,64);
const schema=JSON.parse(fs.readFileSync(path+'schema.json'));
const w=make(),state=decodeState(new Uint8Array(w.memory.buffer,w.z_snapshot(),STATE_BYTES));
validateState(state,schema);assert.deepEqual(decodeState(encodeState(state)),state);
for(const bad of [NaN,Infinity,99,-1]){const s=structuredClone(state);s.tracks[0].p[0]=bad;assert.throws(()=>validateState(s,schema));}
const bytes=Uint8Array.from({length:512},(_,i)=>i&255);assert.deepEqual(unpack7(pack7(bytes)),bytes);assert.equal(crc32(new TextEncoder().encode('123456789')),0xcbf43926);
const demos=[];let renders=0;
for(let preset=0;preset<64;preset++){
 const e=make();e.z_preset(0,preset);e.z_note(0,60,100,1);let peak=0,sum=0,n=0;const chunks=[];
 for(let block=0;block<260;block++){if(block===180)e.z_note(0,60,0,0);e.z_render(e.z_buffer(),256);const data=new Float32Array(e.memory.buffer,e.z_buffer(),512);const pcm=Buffer.alloc(1024);for(let i=0;i<data.length;i++){const x=data[i];assert(Number.isFinite(x));assert(Math.abs(x)<=.981);peak=Math.max(peak,Math.abs(x));sum+=x;n++;pcm.writeInt16LE(Math.round(x*32767),i*2);}chunks.push(pcm);}
 assert(peak>.001,`preset ${preset} silent`);assert(Math.abs(sum/n)<.04,`preset ${preset} DC`);
 e.z_reset_audio();e.z_render(e.z_buffer(),256);assert.equal(Math.max(...new Float32Array(e.memory.buffer,e.z_buffer(),512).map(Math.abs)),0);
 demos.push(Buffer.concat(chunks));renders++;console.log('PASS preset',preset,'peak',peak.toFixed(4));
}
for(let model=0;model<9;model++){const e=make();e.z_set(0,0,model);e.z_set(0,4,127);e.z_set(0,5,127);e.z_set(0,12,127);e.z_set(0,17,127);e.z_set(0,18,127);for(let i=0;i<16;i++)e.z_note(i%6,36+i*4,127,1);assert.equal(e.z_voice_count(),8);for(let i=0;i<200;i++){e.z_render(e.z_buffer(),256);assert(new Float32Array(e.memory.buffer,e.z_buffer(),512).every(Number.isFinite));}renders++;}
const zombie=fs.readFileSync('../synth-base/assets/zombie-pack/ZOMBIE.wav');const wav=wavPCM(zombie.buffer.slice(zombie.byteOffset,zombie.byteOffset+zombie.length));const pcm=resamplePCM(wav.pcm,wav.rate,22050);assert(pcm.length<=24448);assert.throws(()=>resamplePCM(new Float32Array(30000),22050,22050));
new Int16Array(w.memory.buffer,w.z_transfer(),pcm.length).set(pcm);w.z_preview_sample(0,pcm.length,22050);w.z_set(0,0,8);w.z_set(0,19,6);w.z_note(0,60,127,1);let samplePeak=0;for(let i=0;i<140;i++){w.z_render(w.z_buffer(),256);samplePeak=Math.max(samplePeak,...new Float32Array(w.memory.buffer,w.z_buffer(),512).map(Math.abs));}assert(samplePeak>.001);
console.log('PASS WAV decode/resample -> original user-sample DSP');
const e=make();e.z_step_set(0,0,60,100,127,80);e.z_external(1);e.z_clock(250);e.z_render(e.z_buffer(),256);assert.equal(e.z_position(),63);e.z_clock(248);assert.equal(e.z_position(),0);for(let i=0;i<6;i++)e.z_clock(248);assert.equal(e.z_position(),1);e.z_clock(252);assert.equal(e.z_playing(),0);
console.log('PASS external MIDI clock, note budget, transport stop');
const arp=make();arp.z_arp_set(0,0,1);arp.z_arp_set(0,2,2);arp.z_key(0,60,100,1);arp.z_key(0,64,100,1);let arpPeak=0;for(let i=0;i<200;i++){arp.z_render(arp.z_buffer(),256);arpPeak=Math.max(arpPeak,...new Float32Array(arp.memory.buffer,arp.z_buffer(),512).map(Math.abs));}assert(arpPeak>.001);arp.z_key(0,60,0,0);arp.z_key(0,64,0,0);arp.z_alloff(0);assert.equal(arp.z_voice_count(),0);
const rec=make();const recordState=decodeState(new Uint8Array(rec.memory.buffer,rec.z_snapshot(),STATE_BYTES));recordState.recording=1;new Uint8Array(rec.memory.buffer,rec.z_snapshot(),STATE_BYTES).set(encodeState(recordState));rec.z_key(0,66,110,1);rec.z_key(0,66,0,0);const recorded=decodeState(new Uint8Array(rec.memory.buffer,rec.z_snapshot(),STATE_BYTES));assert.equal(recorded.tracks[0].steps[0].note,66);assert.equal(recorded.tracks[0].steps[0].velocity,110);assert.equal(recorded.stepEdit,1);console.log('PASS actual arpeggiator audio and step recording');
const pedal=make();pedal.z_set(0,9,0);pedal.z_sustain(0,1);pedal.z_note(0,69,100,1);pedal.z_render(pedal.z_buffer(),256);pedal.z_note(0,69,0,0);for(let i=0;i<50;i++)pedal.z_render(pedal.z_buffer(),256);assert.equal(pedal.z_voice_count(),1);pedal.z_sustain(0,0);for(let i=0;i<50;i++)pedal.z_render(pedal.z_buffer(),256);assert.equal(pedal.z_voice_count(),0);pedal.z_note(1,60,100,1);pedal.z_note(0,60,100,1);pedal.z_alloff(0);assert.equal(pedal.z_voice_count(),1);pedal.z_bend(1,16383);for(let i=0;i<25;i++){pedal.z_render(pedal.z_buffer(),256);assert(new Float32Array(pedal.memory.buffer,pedal.z_buffer(),512).every(Number.isFinite));}
console.log('PASS sustain pedal, per-channel all-notes-off, pitch bend');
// A simulated ZC port must match reply IDs; no physical MIDI is touched.
const link=new Link();link.output={state:'connected',send:frame=>setTimeout(()=>link.receive(Uint8Array.from([240,125,90,67,frame[4],frame[5]|64,...pack7([0,7,8]),247])),1)};assert.deepEqual([...await link.command(1)],[7,8]);
link.output.send=()=>{};await assert.rejects(link.command(2,[],20),/timeout/);
console.log('PASS editor request framing, matching and timeout');
const upload=new Link();let incoming=[],expectedCRC=0,expectedBytes=0;upload.output={state:'connected',send:frame=>{const cmd=frame[5],data=unpack7(frame.slice(6,-1)),v=new DataView(data.buffer,data.byteOffset,data.length);if(cmd===11){assert.equal(data[0],2);expectedBytes=v.getUint32(1,true);expectedCRC=v.getUint32(7,true);incoming=[];}else if(cmd===12){assert.equal(v.getUint16(0,true),incoming.length);incoming.push(...data.slice(2));}else if(cmd===13){assert.equal(incoming.length,expectedBytes);assert.equal(crc32(incoming),expectedCRC);}setTimeout(()=>upload.receive(Uint8Array.from([240,125,90,67,frame[4],cmd|64,...pack7([0]),247])),1);}};await upload.upload(2,pcm.slice(0,512),22050);assert.equal(incoming.length,1024);console.log('PASS browser sample uploader offsets, CRC and commit framing');
let inputClosed=false,outputClosed=false;const failed=new Link();await assert.rejects(failed.connect({open:async()=>{},close:async()=>{inputClosed=true;}},{open:async()=>{throw Error('Busy port');},close:async()=>{outputClosed=true;}}),/Busy port/);assert(inputClosed&&outputClosed);console.log('PASS failed connection releases MIDI ports for FL Studio');
const data=Buffer.concat(demos),head=Buffer.alloc(44);head.write('RIFF');head.writeUInt32LE(data.length+36,4);head.write('WAVEfmt ',8);head.writeUInt32LE(16,16);head.writeUInt16LE(1,20);head.writeUInt16LE(2,22);head.writeUInt32LE(44100,24);head.writeUInt32LE(176400,28);head.writeUInt16LE(4,32);head.writeUInt16LE(16,34);head.write('data',36);head.writeUInt32LE(data.length,40);fs.writeFileSync('output/zombie-core-sounds.wav',Buffer.concat([head,data]));
fs.writeFileSync('output/core-audio-tests.json',JSON.stringify({renderCases:renders,presets:64,models:9,checks:'finite, audible, bounded, DC, panic, eight-voice budget, user WAV, state validation, MIDI clock, sustain, pitch bend, per-channel panic, editor framing, uploader offsets/CRC, port cleanup',physicalDevice:false},null,2));
console.log('PASS:',renders,'original DSP render cases');
