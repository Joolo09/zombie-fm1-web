# Zombie-specific USB controller profile
wait 1500
fixed
expect sound 2
expect chan 0
expect bank 0
tapkey 0
expect_out USB 90 35 64
expect_out USB 80 35 00
spin K1 1
expect_out USB B0 4A 41
tap FX
expect bank 1
tap FX
expect bank 2
spin K1 1
expect_out USB B0 10 41
tap PLAY
expect_out USB BF 72 7F
tap PLAY
expect_out USB BF 72 00
tap REC
expect_out USB BF 73 7F
out
press FX
tap REC
release FX
expect bank 2
expect_out USB B0 7B 00
tap SAVE
wait 4000
reboot
wait 1500
expect bank 2
expect sound 2
shot zombie-play.png
zombie-splash
shot zombie-splash.png
