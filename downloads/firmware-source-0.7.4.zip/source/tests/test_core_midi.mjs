import fs from 'node:fs';
import assert from 'node:assert/strict';
import {decodeSystem} from '../zombie-core/web/system.js';
import {Link,pack7} from '../zombie-core/web/core.js';
const module=await WebAssembly.compile(fs.readFileSync('output/zombie-core-site/webapp/editor/zombie-core.wasm'));
const w=new WebAssembly.Instance(module,{}).exports;w.z_init();w.z_external(1);w.z_clock(250);w.z_songpos(17);w.z_clock(251);w.z_clock(248);assert.equal(w.z_position(),17);w.z_clock(252);assert.equal(w.z_position(),17);w.z_clock(251);for(let i=0;i<6;i++)w.z_clock(248);assert.equal(w.z_position(),18);w.z_transport(0);w.z_clock(250);w.z_clock(248);assert.equal(w.z_position(),0);
const bytes=new Uint8Array(122),v=new DataView(bytes.buffer);v.setUint32(0,0x3153595a,true);v.setUint16(4,2,true);bytes.set([0,100,1,1,0,0],6);bytes.set([2,1,0,0],108);bytes[112]=1;bytes[113]=95;v.setUint32(114,123456,true);v.setUint32(118,3,true);const s=decodeSystem(bytes);assert.equal(s.midiMode,2);assert.equal(s.transport,1);assert.equal(s.jobs,123456);assert.equal(s.timeouts,3);const bad=bytes.slice();bad[108]=3;assert.throws(()=>decodeSystem(bad));
for(const version of ['0.6.0','0.6.1','0.7.0','0.7.1','0.7.2','0.7.3','0.7.4','0.7.9']){const link=new Link(),input={open:async()=>{},close:async()=>{}},output={state:'connected',open:async()=>{},close:async()=>{},send(frame){const data=frame[5]===1?new TextEncoder().encode('ZCORE/1/'+version):bytes;input.onmidimessage({data:Uint8Array.from([240,125,90,67,frame[4],frame[5]|64,...pack7([0,...data]),247])});}};
link.readState=async()=>null;await link.connect(input,output);assert.ok(link.daw&&link.system&&link.polish);assert.equal(link.sampler,version.startsWith('0.7.'));assert.deepEqual(decodeSystem(await link.command(28)),s);link.close();}
console.log('PASS: MIDI SPP/Continue/Start, v2 MIDI settings, input validation and 0.6.0/0.6.1/0.7.0/0.7.1 editor handshakes');
