from pathlib import Path
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'installer'))
sys.path.insert(0, str(ROOT / 'firmware-base/base/tools'))
import core
import fm1pkg_make as maker


class PackageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'test.fwsc'
        # Synthetic UFW only, not a runnable firmware. Never distributed.
        self.raw = maker.ufw(b'fake-flash' * 2000, core.protocol.LOADER_MARK + b'fake-ota' * 100, 'FM-1_6000100')
        self.path.write_bytes(self.raw)

    def tearDown(self):
        self.temp.cleanup()

    def test_valid_package(self):
        p = core.read_package(self.path)
        self.assertEqual(p.product, 'FM-1_6000100')
        self.assertEqual(p.image, core.protocol.logical_image(self.raw))
        self.assertEqual(len(p.sha256), 64)

    def test_corruption_and_truncation(self):
        for offset in (2, 100, 2000, len(self.raw) - 1):
            raw = bytearray(self.raw)
            raw[offset] ^= 1
            self.path.write_bytes(raw)
            with self.assertRaises(ValueError):
                core.read_package(self.path)
        self.path.write_bytes(self.raw[:-10])
        with self.assertRaises(ValueError):
            core.read_package(self.path)

    def test_wrong_model_and_archive(self):
        self.path.write_bytes(maker.ufw(b'x' * 2000, core.protocol.LOADER_MARK, 'OTHER_100'))
        with self.assertRaisesRegex(ValueError, 'не для FM-1'):
            core.read_package(self.path)
        with self.assertRaisesRegex(ValueError, 'ZIP'):
            core.read_package(self.path.with_suffix('.zip'))

    def test_unknown_loader_blocked(self):
        self.path.write_bytes(maker.ufw(b'x' * 2000, b'unknown loader', 'FM-1_900'))
        with self.assertRaisesRegex(ValueError, 'загрузчик'):
            core.read_package(self.path)

    def test_replaced_file_never_opens_midi(self):
        package = core.read_package(self.path)
        self.path.write_bytes(maker.ufw(b'y' * 2000, core.protocol.LOADER_MARK, 'FM-1_900'))
        with patch.object(core, 'find_device') as find:
            with self.assertRaisesRegex(ValueError, 'изменился'):
                core.install(package, object())
            find.assert_not_called()

    def test_loader_link_closed_on_error(self):
        class Link:
            closed = False
            def close(self):
                self.closed = True
        first, loader = Link(), Link()
        class Backend:
            def open(self, *_):
                return loader
        class Updater:
            def install(self, *_):
                tracked.open('loader', 'loader')
                raise RuntimeError('unplugged')
        def find(backend, _):
            nonlocal tracked
            tracked = backend
            tracked.links.append(first)
            return Updater(), object()
        tracked = None
        with patch.object(core, 'find_device', side_effect=find):
            with self.assertRaisesRegex(RuntimeError, 'unplugged'):
                core.install(core.read_package(self.path), Backend())
        self.assertTrue(first.closed and loader.closed)


if __name__ == '__main__':
    unittest.main()
