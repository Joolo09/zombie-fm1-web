import fs from 'node:fs';
import assert from 'node:assert/strict';
import {decodeSampler,encodeSampler,validateSampler,uploadSampler,SAMPLER_BYTES} from '../zombie-core/web/sampler.js';
import {decodeState,STATE_BYTES,Link,unpack7,pack7,crc32} from '../zombie-core/web/core.js';
import {CoreDSP} from '../zombie-core/web/worklet.js';
const module=await WebAssembly.compile(fs.readFileSync('output/zombie-core-site/webapp/editor/zombie-core.wasm'));
const make=()=>{const w=new WebAssembly.Instance(module,{}).exports;w.z_init();return w;};
const read=w=>decodeSampler(new Uint8Array(w.memory.buffer,w.z_sampler_snapshot(),SAMPLER_BYTES).slice());
function render(w,frames){let energy=0,peak=0,sign=0;for(let at=0;at<frames;at+=256){const count=Math.min(256,frames-at);w.z_render(w.z_buffer(),count);for(const x of new Float32Array(w.memory.buffer,w.z_buffer(),count*2)){assert(Number.isFinite(x));assert(Math.abs(x)<1);energy+=x*x;peak=Math.max(peak,Math.abs(x));sign+=x;}}return {energy,peak,sign};}
function source(w,length=4096,rate=4000){const pcm=new Int16Array(w.memory.buffer,w.z_transfer(),length);for(let i=0;i<length;i++)pcm[i]=i<length/2?16000:-16000;w.z_preview_sample(0,length,rate);w.z_sampler_enable(0,1);w.z_sampler_set(0,2,6);w.z_set(0,4,127);w.z_set(0,5,0);w.z_set(0,12,0);w.z_set(0,13,0);w.z_set(0,14,0);return w;}
let w=make(),kit=read(w);assert.equal(kit.pads.length,32);assert.deepEqual(kit.pads.slice(0,4).map(p=>p.source),[10,11,12,13]);assert.deepEqual(decodeSampler(encodeSampler(kit)),kit);
for(const mutate of [k=>k.pads[0].end=0,k=>k.pads[0].source=14,k=>k.pads[0].tune=-25,k=>k.pads[0].mode=3,k=>k.bank=2,k=>k.tracks=64]){const bad=structuredClone(kit);mutate(bad);assert.throws(()=>validateSampler(bad));}
const before=read(w);assert.equal(w.z_sampler_set(0,0,65535),-1);assert.deepEqual(read(w),before);assert.equal(w.z_sampler_set(32,0,0),-1);
for(let source=10;source<14;source++){assert(w.z_sample_frames(source)>1000);assert.equal(w.z_sample_rate(source),11025);assert(w.z_sample_peak(source,2,96)>0);}
for(const slices of [4,8,16]){w=make();w.z_sampler_set(17,0,1000);w.z_sampler_set(17,1,65000);w.z_sampler_set(17,3,-5);assert.equal(w.z_sampler_chop(17,slices),0);const k=read(w);assert.equal(k.pads[16].start,1000);assert.equal(k.pads[15+slices].end,65000);for(let i=16;i<16+slices;i++){assert.equal(k.pads[i].tune,-5);if(i>16)assert.equal(k.pads[i].start,k.pads[i-1].end);}assert.equal(k.selected,16);assert.equal(k.bank,1);assert.equal(w.z_sampler_chop(17,3),-1);}
w=source(make());w.z_key(0,36,100,1);render(w,512);w.z_key(0,36,0,0);render(w,6000);assert.equal(w.z_voice_count(),1,'one-shot survives key-up');render(w,50000);assert.equal(w.z_voice_count(),0,'one-shot ends at source boundary');
for(const mode of [1,2]){w=source(make());w.z_sampler_set(0,6,mode);w.z_key(0,36,100,1);assert(render(w,mode===2?60000:512).energy>.1);assert.equal(w.z_voice_count(),1);w.z_key(0,36,0,0);render(w,9000);assert.equal(w.z_voice_count(),0,'gate/loop releases');}
for(const reverse of [0,1]){w=source(make());w.z_sampler_set(0,7,reverse);w.z_key(0,36,100,1);const result=render(w,256);assert(reverse?result.sign<0:result.sign>0,'reverse starts at opposite sample edge');}
w=source(make(),256,44100);w.z_sampler_set(0,0,32767);w.z_sampler_set(0,1,65535);w.z_key(0,36,100,1);assert(render(w,100).sign<0,'trim starts inside the negative half');render(w,200);assert.equal(w.z_voice_count(),0);
for(const tune of [-24,0,24]){w=source(make(),4096,44100);w.z_sampler_set(0,3,tune);w.z_key(0,36,100,1);render(w,1100);assert.equal(w.z_voice_count(),tune===24?0:1,'pitch changes playback speed');render(w,17000);assert.equal(w.z_voice_count(),0);}
w=source(make());w.z_sampler_set(0,8,1);w.z_sampler_set(1,2,6);w.z_sampler_set(1,8,1);w.z_key(0,36,100,1);render(w,64);w.z_key(0,37,100,1);render(w,1500);assert.equal(w.z_voice_count(),1,'choke fades previous pad');
w=source(make());w.z_sampler_set(0,6,2);w.z_sampler_set(0,0,32767);w.z_sampler_set(0,1,32768);w.z_sampler_set(0,3,24);w.z_key(0,36,100,1);render(w,512);w.z_alloff(0);assert.equal(w.z_voice_count(),0,'short trim cannot underflow/out-of-bounds');
for(const quality of [0,1,2]){w=source(make());w.z_sampler_set(0,9,quality);w.z_key(0,36,100,1);assert(render(w,4096).energy>.1);}
w=source(make());w.z_key(0,36,100,1);w.z_set(0,0,0);render(w,1500);assert.equal(w.z_voice_count(),0,'switching away from sampler ends one-shots');
w=source(make());w.z_key(0,35,100,1);w.z_key(0,68,100,1);assert.equal(w.z_voice_count(),0,'notes outside pad map are silent');
w=source(make());w.z_record(1);for(const note of [36,37,38,39])w.z_key(0,note,100,1);render(w,512);for(const note of [36,37,38,39])w.z_key(0,note,0,0);w.z_record(0);let state=decodeState(new Uint8Array(w.memory.buffer,w.z_snapshot(),STATE_BYTES));assert.deepEqual([state.tracks[0].steps[0].note,...state.tracks[0].steps[0].chord.map(n=>n-1)],[36,37,38,39]);assert.equal(state.stepEdit,1);
// Config edits and pad selection must not cut other running pad voices.
w=source(make());w.z_key(0,36,100,1);kit=read(w);kit.selected=1;new Uint8Array(w.memory.buffer,w.z_sampler_snapshot(),SAMPLER_BYTES).set(encodeSampler(kit));assert.equal(w.z_sampler_apply(),0);assert.equal(w.z_voice_count(),1);
const bad=encodeSampler(kit);bad[12]=255;bad[13]=255;new Uint8Array(w.memory.buffer,w.z_sampler_snapshot(),SAMPLER_BYTES).set(bad);assert.equal(w.z_sampler_apply(),-1);assert.deepEqual(read(w),kit);
const dsp=new CoreDSP(module);dsp.sample(0,new Int16Array(128).fill(12000),11025);assert.equal(dsp.w.z_sample_frames(6),128);
// Transfer protocol: checksum, ordered chunks, atomic commit, no PCM writes.
const link=new Link();let bytes=[],checksum;link.output={state:'connected',send(frame){const command=frame[5],data=unpack7(frame.slice(6,-1)),view=new DataView(data.buffer,data.byteOffset,data.length);if(command===40){bytes=[];checksum=view.getUint32(0,true);}else if(command===17){assert.equal(view.getUint16(0,true),bytes.length);bytes.push(...data.slice(2));}else if(command===41){assert.equal(bytes.length,SAMPLER_BYTES);assert.equal(crc32(bytes),checksum);}else assert.fail('Unexpected sampler upload command');link.receive(Uint8Array.from([240,125,90,67,frame[4],command|64,...pack7([0]),247]));}};await uploadSampler(link,kit);assert.deepEqual(decodeSampler(Uint8Array.from(bytes)),kit);
console.log('PASS: sampler codec/validation, 4 original drums, 32 pads, contiguous bank chops, one-shot/gate/loop, reverse, trim, pitch, choke, short boundaries, bit character, preset change, chord recording, noninterrupting edits and CRC transfer.');
