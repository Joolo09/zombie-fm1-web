import fs from 'node:fs';
import assert from 'node:assert/strict';
import {Link,DeviceSync,pack7,unpack7,encodeState,decodeState,validateState,STATE_BYTES,u16} from '../zombie-core/web/core.js';
const path='output/zombie-core-site/webapp/editor/';
const module=await WebAssembly.compile(fs.readFileSync(path+'zombie-core.wasm'));
const w=new WebAssembly.Instance(module,{}).exports;w.z_init();
const bytes=()=>new Uint8Array(w.memory.buffer,w.z_snapshot(),STATE_BYTES);
const schema=JSON.parse(fs.readFileSync(path+'schema.json'));
let snapshot,token=0,snapshotRevision,requests=0,mutateDuringSnapshot=false,corruptToken=false,legacy=false;
const input={open:async()=>{},close:async()=>{}};
const output={state:'connected',open:async()=>{},close:async()=>{},send(frame){
 const cmd=frame[5],a=unpack7(frame.slice(6,-1));let data=[];requests++;
 if(cmd===1)data=[...new TextEncoder().encode(legacy?'ZCORE/1/0.3.0':'ZCORE/1/0.4.0')];
 else if(cmd===2)data=[...encodeState(decodeState(bytes()),true)];
 else if(cmd===19){const at=a[0]|a[1]<<8,count=a[2];if(at===0){snapshot=bytes().slice();token++;snapshotRevision=w.z_revision();}else assert.equal(new DataView(a.buffer).getUint32(3,true),token);
  const head=new Uint8Array(10),v=new DataView(head.buffer);v.setUint32(0,token+(corruptToken&&at>0?1:0),true);v.setUint32(4,snapshotRevision,true);v.setUint16(8,at,true);data=[...head,...snapshot.slice(at,at+count)];
  if(mutateDuringSnapshot&&at===0){w.z_set(5,15,123);mutateDuringSnapshot=false;}
 }else if(cmd===20){const s=decodeState(bytes()),d=new Uint8Array(16);d.set([2,w.z_playing(),w.z_position(),s.recording,s.octave+3,s.section,s.subpage,s.bank,s.stepEdit,s.selected,s.presets[s.selected],1]);new DataView(d.buffer).setUint32(12,w.z_revision(),true);data=[...d];}
 else throw Error('Unexpected test command '+cmd);
 setTimeout(()=>input.onmidimessage({data:Uint8Array.from([240,125,90,67,frame[4],cmd|64,...pack7([0,...data]),247])}),0);
}};
const link=new Link();const initial=await link.connect(input,output);validateState(initial,schema);assert(link.modern);assert.equal(initial.format,'zombie-core/3');
let state=initial,runtime,editing=false,errors=[];
const sync=new DeviceSync(link,{onState:s=>{state=validateState(s,schema);},onRuntime:r=>{runtime=r;},onError:e=>errors.push(e),isEditing:()=>editing});
w.z_set(0,4,88);await sync.poll();assert.equal(state.tracks[0].p[4],88);
// No focus test exists in the pump: a focused but idle select cannot block it.
const changed=decodeState(bytes());changed.octave=2;changed.language=1;changed.selected=3;changed.bank=2;changed.stepEdit=32;changed.section=3;bytes().set(encodeState(changed));w.z_touch();await sync.poll();assert.equal(state.octave,2);assert.equal(state.language,1);assert.equal(state.selected,3);assert.equal(state.bank,2);
editing=true;w.z_set(3,4,73);await sync.poll();assert.equal(runtime.selected,3);assert.notEqual(state.tracks[3].p[4],73);editing=false;await sync.poll();assert.equal(state.tracks[3].p[4],73);
const before=requests;w.z_transport(1);await sync.poll();assert(runtime.playing);assert.equal(requests-before,1,'unchanged project only needs the small runtime packet');w.z_transport(0);
mutateDuringSnapshot=true;const oldLevel=state.tracks[5].p[15];const coherent=await link.readState();assert.equal(coherent.tracks[5].p[15],oldLevel);await sync.poll();assert.equal(state.tracks[5].p[15],123);
corruptToken=true;await assert.rejects(link.readState(),/Mixed state snapshots/);corruptToken=false;assert.equal(errors.length,0);
link.close();legacy=true;const oldLink=new Link();const old=await oldLink.connect(input,output);assert(!oldLink.modern);assert.equal(old.format,'zombie-core/3');validateState(old,schema);oldLink.close();
console.log('PASS: real-DSP state -> chunked MIDI replies -> editor sync, idle focus, language/octave/track/bank, transport, deferred editing, coherent snapshots, stale-token rejection and 0.3.0 compatibility.');
