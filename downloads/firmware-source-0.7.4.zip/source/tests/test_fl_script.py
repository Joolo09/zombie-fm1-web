"""Exercise FL routing with stand-in FL modules; no FL installation required."""
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[1]

class ScriptTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        def log(name):
            return lambda *args: self.calls.append((name, args))
        sys.modules['mixer'] = SimpleNamespace(setTrackVolume=log('vol'), setTrackPan=log('pan'))
        sys.modules['transport'] = SimpleNamespace(start=log('start'), stop=log('stop'),
                                                   record=log('rec'), isPlaying=lambda: False)
        spec = importlib.util.spec_from_file_location('zombie', ROOT / 'fl-studio/Zombie-FM1/device_Zombie_FM1.py')
        self.script = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.script)

    def send(self, status, cc, value):
        event = SimpleNamespace(status=status, data1=cc, data2=value, handled=False)
        self.script.OnMidiMsg(event)
        return event.handled

    def test_notes_and_plugin_cc_pass(self):
        for status, data, value in [(0x90, 60, 100), (0x80, 60, 0), (0xB0, 74, 99),
                                     (0xB1, 16, 20), (0xB0, 64, 127), (0xF8, 0, 0)]:
            self.assertFalse(self.send(status, data, value))
        self.assertEqual(self.calls, [])

    def test_transport_channel_and_state(self):
        self.assertFalse(self.send(0xB0, 114, 127))
        self.assertTrue(self.send(0xBF, 114, 127))
        sys.modules['transport'].isPlaying = lambda: True
        self.send(0xBF, 114, 127)  # no duplicate start
        self.send(0xBF, 114, 0)
        self.send(0xBF, 115, 0)    # ignore record release
        self.send(0xBF, 115, 127)
        self.assertEqual(self.calls, [('start', ()), ('stop', ()), ('rec', ())])

    def test_mixer_endpoints_and_centre(self):
        self.send(0xB0, 16, 0)
        self.send(0xB0, 19, 127)
        for value in [0, 64, 127]:
            self.send(0xB0, 20, value)
        self.assertEqual(self.calls, [('vol', (1, 0.0, 2)), ('vol', (4, 1.0, 2)),
                                     ('pan', (1, -1.0, 2)), ('pan', (1, 0.0, 2)),
                                     ('pan', (1, 1.0, 2))])

if __name__ == '__main__':
    unittest.main()
