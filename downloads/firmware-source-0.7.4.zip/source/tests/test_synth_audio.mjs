import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const wasm = fs.readFileSync('synth-base/build/preview/sloop-preview.wasm');
const module = await WebAssembly.compile(wasm);
assert.equal(WebAssembly.Module.imports(module).length, 0, 'preview must work offline without external runtime');
function create() { const ex = new WebAssembly.Instance(module, {}).exports; ex.preview_init(); ex.preview_render(); return ex; }
function name(ex,e,p) { const bytes = new Uint8Array(ex.memory.buffer); let at=ex.preview_preset_name(e,p), s=''; while(bytes[at]) s += String.fromCharCode(bytes[at++]); return s; }
let probe = create(), counts = [], custom = [], demos = [];
assert.equal(probe.preview_engine_count(),12);
for(let e=0;e<12;e++) { const n=probe.preview_preset_count(e); counts.push(n); for(let p=0;p<n;p++) if(name(probe,e,p).startsWith('MC ')) custom.push([e,p,name(probe,e,p)]); }
assert.equal(custom.length,7);
let total=counts.reduce((a,b)=>a+b,0);
assert.equal(total,160,'factory bank including seven custom presets');
const cases=[...Array.from({length:12},(_,e)=>[e,0,'ENGINE '+e]), ...custom];
for(const [engine,preset,label] of cases) {
  const ex=create(); ex.preview_factory(0,engine,preset);
  for(let i=0;i<32;i++) ex.preview_render();
  ex.preview_note(0,60,1);
  const frames=ex.preview_frames(), sr=ex.preview_rate(), chunks=[];
  let peak=0, sum=0, clipping=0, n=0;
  for(let t=0;t<Math.ceil(sr*1.5/frames);t++) {
    if(t===Math.floor(sr*.95/frames)) ex.preview_note(0,60,0);
    const ptr=ex.preview_render(), buf=new Float32Array(ex.memory.buffer,ptr,frames*2);
    const pcm=Buffer.alloc(buf.length*2);
    for(let i=0;i<buf.length;i++) { const v=buf[i]; assert(Number.isFinite(v)); assert(Math.abs(v)<=1); peak=Math.max(peak,Math.abs(v)); sum+=v; clipping+=Math.abs(v)>.9999; n++; pcm.writeInt16LE(Math.max(-32768,Math.min(32767,Math.round(v*32767))),i*2); }
    chunks.push(pcm);
  }
  assert(peak>.0005,`${label}: silent`);
  assert(clipping/n < .01, `${label}: excessive clipping`);
  assert(Math.abs(sum/n)<.08,`${label}: excessive DC`);
  ex.preview_panic();
  for(let i=0;i<1024;i++) ex.preview_render();
  const tail=new Float32Array(ex.memory.buffer,ex.preview_render(),frames*2);
  assert(Math.max(...tail.map(Math.abs)) < .01,`${label}: voices hang after panic`);
  if(label.startsWith('MC ')) { const pcm=Buffer.concat(chunks); demos.push(pcm); console.log(label,'peak',peak.toFixed(3),'sha256',crypto.createHash('sha256').update(pcm).digest('hex').slice(0,16)); }
}
assert(new Set(demos.map(p=>crypto.createHash('sha256').update(p).digest('hex'))).size>=6,'distinct mob effects');
const data=Buffer.concat(demos), header=Buffer.alloc(44);
header.write('RIFF');header.writeUInt32LE(data.length+36,4);header.write('WAVEfmt ',8);header.writeUInt32LE(16,16);header.writeUInt16LE(1,20);header.writeUInt16LE(2,22);header.writeUInt32LE(44100,24);header.writeUInt32LE(176400,28);header.writeUInt16LE(4,32);header.writeUInt16LE(16,34);header.write('data',36);header.writeUInt32LE(data.length,40);
fs.writeFileSync('output/zombie-minecraft-demo.wav',Buffer.concat([header,data]));
fs.writeFileSync('output/synth-audio-tests.json',JSON.stringify({engines:12,presets:total,customPresets:custom.map(x=>x[2]),renderCases:cases.length,checks:'finite, audible, bounded, DC, panic release, distinct effects',hardwareTest:false},null,2));
console.log(`PASS: ${cases.length} real-DSP renders, ${total} presets, browser WASM has no external imports.`);
