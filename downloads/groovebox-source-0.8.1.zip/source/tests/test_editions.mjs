/* SPDX-License-Identifier: MIT — actual WASM engines, no physical hardware. */
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
const dir=new URL('../output/editions-'+(process.env.Z_EDITION_RELEASE||'0.8.0')+'/',import.meta.url),report={};
for(const kind of (process.env.Z_EDITION_KIND?[process.env.Z_EDITION_KIND]:['groovebox','sampler'])){
 const module=await WebAssembly.compile(await readFile(new URL(kind+'.wasm',dir)));
 const make=()=>{const w=new WebAssembly.Instance(module,{}).exports;w.z_init();return w;};
 let patches=0,peak=0;const rms=[];
 for(let preset=0;preset<64;preset++){
  const w=make();w.z_preset(0,preset);assert(kind==='sampler'?w.z_get(0,0)===8:w.z_get(0,0)<8);
  w.z_note(0,kind==='sampler'?36:60,110,1);let energy=0,count=0;
  for(let i=0;i<90;i++){w.z_render(w.z_buffer(),256);const data=new Float32Array(w.memory.buffer,w.z_buffer(),512);for(const x of data){assert(Number.isFinite(x));energy+=x*x;count++;peak=Math.max(peak,Math.abs(x));}}
  const level=Math.sqrt(energy/count);assert(level>0.000001,`${kind} preset ${preset} is silent`);rms.push(level);patches++;
 }
 const w=make();assert.equal(w.z_playing(),0);w.z_transport(1);w.z_render(w.z_buffer(),256);assert.equal(w.z_playing(),1);w.z_transport(0);assert.equal(w.z_playing(),0);
 if(kind==='sampler'){
  const pcm=new Int16Array(w.memory.buffer,w.z_transfer(),2048);for(let i=0;i<pcm.length;i++)pcm[i]=Math.sin(i*.1)*15000;
  w.z_preview_sample(0,pcm.length,22050);assert.equal(w.z_sampler_set(0,2,6),0);assert.equal(w.z_sampler_set(0,6,1),0);assert.equal(w.z_sampler_set(0,7,1),0);assert.equal(w.z_sampler_chop(0,16),0);
  w.z_note(0,36,110,1);let signal=0;for(let i=0;i<15;i++){w.z_render(w.z_buffer(),256);for(const x of new Float32Array(w.memory.buffer,w.z_buffer(),512))signal=Math.max(signal,Math.abs(x));}assert(signal>.001,'uploaded user PCM must play');
  w.z_sampler_enable(0,0);assert.equal(w.z_get(0,0),8);
 }else{
  assert.equal(w.z_sampler_enable(0,1),-1);w.z_set(0,0,8);assert.equal(w.z_get(0,0),7);
  const bytes=new Uint8Array(w.memory.buffer,w.z_snapshot(),3452);assert(bytes.some(Boolean));
 }
 const rec=make();rec.z_clear_track(0);rec.z_record(1);rec.z_transport(1);const note=kind==='sampler'?36:60;rec.z_key(0,note,100,1);for(let i=0;i<24;i++)rec.z_render(rec.z_buffer(),256);rec.z_key(0,note,0,0);rec.z_record(0);rec.z_transport(0);
 const noteCount=()=>{const b=new Uint8Array(rec.memory.buffer,rec.z_snapshot(),3452);let n=0;for(let i=0;i<64;i++)if(b[67+i*4])n++;return n;};assert(noteCount()>0,kind+' recording must capture the played note');assert.equal(rec.z_history(0),1);assert.equal(noteCount(),0,'Undo removes take');assert.equal(rec.z_history(1),1);assert(noteCount()>0,'Redo restores take');
 report[kind]={presets:patches,allFinite:true,minimumRMS:Math.min(...rms),maximumPeak:peak,recordUndoRedo:true,physicalHardware:false};
 console.log(kind+': '+patches+' audible presets, finite output, engine separation, transport, user PCM/chop checks passed');
}
await writeFile(new URL('audio-checks.json',dir),JSON.stringify(report,null,2)+'\n');
