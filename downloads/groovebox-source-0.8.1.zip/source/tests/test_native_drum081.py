"""Real host app input/UI/MIDI regression, not hardware."""
from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parents[2];F=R/'zombie-fix';O=F/'output/editions-0.8.1';D=O/'groovebox'
script=O/'native-drum-check.txt'
script.write_text('''defaults
drumtest
turn K2 1
expect note 38
turn K2 1
expect note 42
turn K2 -2
expect note 36
tap SEQ
turn K1 1
expect chord1 37
turn K1 1
expect chord1 39
press EDIT
tap OCT-
release EDIT
expect chord1 37
tap SEQ
tap SEQ
wait 250
shot drum-grid-ru.png
en
wait 250
shot drum-grid-en.png
ru
midiready
track 5
out
key w0 down 100
expect_out USB 95 24 64
key w0 up
expect_out USB 85 24 00
key w1 down 100
expect_out USB 95 26 64
key w1 up
expect_out USB 85 26 00
defaults
track 5
tap SEQ
master 3000
wav groovebox-kit-demo.wav
tap PLAY
wait 300
shot drum-playing-0.png
wait 160
shot drum-playing-1.png
wait 160
shot drum-playing-2.png
wait 160
shot drum-playing-3.png
wait 160
shot drum-playing-4.png
wait 160
shot drum-playing-5.png
tap PLAY
wavstop
expect playing 0
defaults
master 3000
wav groovebox-demo.wav
tap PLAY
wait 8000
tap PLAY
wavstop
''',encoding='utf-8')
r=subprocess.run([str(F/'editions/groovebox/build/host/zombie-groovebox_host'),str(script),str(D)],capture_output=True)
(O/'native-drum-check.log').write_bytes(r.stdout+r.stderr)
if r.returncode:print((r.stdout+r.stderr).decode(errors='replace'));raise SystemExit(r.returncode)
sys.path.insert(0,str(R/'.tooling/audio-deps'))
from PIL import Image
frames=[Image.open(D/f'drum-playing-{i}.png').convert('RGB').resize((480,480),Image.Resampling.NEAREST) for i in range(6)]
frames[0].save(O/'groovebox-native.gif',save_all=True,append_images=frames[1:],duration=160,loop=0)
print('PASS: native instrument selection, extra drum, Undo, white-key GM MIDI and output; rendered drum grid/GIF saved')
