"""Compile/run the actual loader-success branch with stub reset hardware.
The old source must choose CPU-only reset; the new source must choose P33 reset.
This is a source-level hardware contract, not a physical FM-1 test.
"""
from pathlib import Path
import os,re,subprocess,sys
R=Path(__file__).resolve().parents[2];F=R/'zombie-fix';OUT=F/'output/editions-0.8.1'
OUT.mkdir(exist_ok=True)
cc=os.environ.get('CC',str(R/'tools/host-cc.cmd'))
env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(R/'.tooling/zig-global'),ZIG_LOCAL_CACHE_DIR=str(R/'.tooling/zig-local'))
for folder,expected in [('platform',1),('platform-081',2)]:
 source=(F/folder/'bsp/loader/loader.c').read_text()
 branch=source.split('if (ldr_session() == 0) {',1)[1].split('\n            }',1)[0]
 harness='''#include <stdio.h>
static int stage=0,kind=0;
static void fm1_delay_ms(unsigned ms){if((stage==0&&ms==200)||(stage==2&&ms==30))stage++;else stage=-100;}
static void usb_detach(void){if(stage==1)stage++;else stage=-100;}
static void fm1_core_reset(void){kind=1;}
static void fm1_reboot(void){kind=2;}
int main(void){'''+branch+f'\n return stage==3&&kind=={expected}?0:1;}}\n'
 path=OUT/(folder+'-restart.c');path.write_text(harness)
 exe=path.with_suffix('.exe');r=subprocess.run([cc,str(path),'-o',str(exe)],capture_output=True,env=env)
 if r.returncode:sys.exit(r.stderr.decode(errors='replace'))
 subprocess.run([str(exe)],check=True)
 print(f'PASS {folder}: detach + settle + reset={expected} (1 CPU, 2 full chip)')
(OUT/'loader-restart-check.txt').write_text('PASS: old loader CPU-only reset reproduced; new loader full P33 chip reset after detach and 230ms settling. Hardware unverified.\n')
