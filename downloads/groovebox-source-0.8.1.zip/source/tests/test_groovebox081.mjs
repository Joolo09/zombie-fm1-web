/* SPDX-License-Identifier: MIT — actual WASM audio, never physical hardware. */
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
const dir=new URL('../output/editions-0.8.1/',import.meta.url);
const module=await WebAssembly.compile(await readFile(new URL('groovebox.wasm',dir)));
const make=()=>{const w=new WebAssembly.Instance(module,{}).exports;w.z_init();for(let t=0;t<6;t++)w.z_clear_track(t);for(let t=0;t<6;t++){w.z_set(t,13,0);w.z_set(t,14,0);}return w;};
function render(w,frames){const samples=[];while(frames){const n=Math.min(256,frames);w.z_render(w.z_buffer(),n);samples.push(...new Float32Array(w.memory.buffer,w.z_buffer(),n*2));frames-=n;}assert(samples.every(Number.isFinite));return samples;}
const energy=a=>a.reduce((n,x)=>n+x*x,0)/a.length;
const notes=[36,38,42,46,39,37,45,47,50,49,51,56,54,70,75,76],report=[];
for(const note of notes){const w=make();w.z_key(5,note,110,1);render(w,128);w.z_key(5,note,0,0);const a=render(w,44100);assert(energy(a)>.000001,'silent drum '+note);assert(Math.max(...a.map(Math.abs))<=.98);report.push({note,rms:Math.sqrt(energy(a)),endRMS:Math.sqrt(energy(a.slice(-5000)))});}
assert(new Set(report.map(r=>r.rms.toFixed(7))).size===16,'each drum must differ');
const open=make();open.z_note(5,46,110,1);render(open,6000);const ringing=energy(render(open,1800));
const closed=make();closed.z_note(5,46,110,1);render(closed,6000);closed.z_note(5,42,110,1);render(closed,3000);const choked=energy(render(closed,1800));
assert(choked<ringing*.15,'closed hat must choke open hat');
const layer=make();layer.z_step_set(5,0,36,110,127,1);let b=new Uint8Array(layer.memory.buffer,layer.z_snapshot(),3452);b[1908+5*64*3]=39;b[1908+5*64*3+1]=43;layer.z_transport(1);render(layer,256);assert.equal(layer.z_voice_count(),3,'kick/snare/hat on same step');
layer.z_transport(0);assert.equal(layer.z_voice_count(),0);layer.z_transport(1);assert(energy(render(layer,4000))>.0001,'restart has audible drum sequence');
const rec=make();rec.z_record(1);rec.z_transport(1);for(const note of [36,38,42])rec.z_key(5,note,100,1);render(rec,2500);for(const note of [36,38,42])rec.z_key(5,note,0,0);rec.z_transport(0);b=new Uint8Array(rec.memory.buffer,rec.z_snapshot(),3452);assert.equal(b[12+5*310+54],36);assert(b[1908+5*64*3]&&b[1908+5*64*3+1]);rec.z_transport(1);assert(energy(render(rec,4000))>.0001,'recorded kit plays without restarting device');
for(let t=0;t<5;t++){const w=make();w.z_preset(t,16);w.z_key(t,48,110,1);assert(energy(render(w,6000))>.000001,'melodic track '+t+' silent');}
await writeFile(new URL('drum-audio-checks.json',dir),JSON.stringify({drums:report,closedHatChoke:true,layeredStep:true,recordReplay:true,fiveSynthTracks:true,physicalHardware:false},null,2));
console.log('PASS: 16 distinct finite drum sounds, one-shots survive Note Off, hat choke, layered steps, record/replay, all five synth tracks');
