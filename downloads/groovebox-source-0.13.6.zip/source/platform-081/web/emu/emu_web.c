/* SPDX-License-Identifier: MPL-2.0
 * Copyright (C) 2026 Charles Vestal */
/* An fm1-base app in the browser: the host simulator (host/plat_host.c: the whole app, UI and sound, against a
 * simulated FM-1) compiled to WebAssembly and run in an AudioWorklet (from X0X's, by way of FoMni-1's). The worklet asks
 * for audio; producing it advances the device's clock one millisecond at a time, which runs the
 * app's render every APP_BLOCK samples (the I2S half buffer) and the UI every 16 ms, as on the FM-1. The page
 * sends input, and reads the screen, the lights and the saved objects back through these exports.
 *
 *   tools/build.py APP_DIR --web   ->  APP_DIR/build/emu/app.wasm (+ the page) */
#include <stdint.h>

static void web_audio(const int32_t *blk, uint32_t n);
#include "plat_host.c"

#undef __attribute__

/* output ring, stereo float, filled by run_ms, drained by web_render */
#define RING 4096u
static float ring[RING * 2];
static uint32_t ring_w, ring_r;
static void web_audio(const int32_t *blk, uint32_t n)
{
    uint32_t k;
    for (k = 0; k < n; k++) {
        uint32_t i = (ring_w++ % RING) * 2u;
        ring[i] = (float)blk[2 * k] / 8388608.0f;
        ring[i + 1] = (float)blk[2 * k + 1] / 8388608.0f;
    }
}

static float out_l[1024], out_r[1024];
__attribute__((used, visibility("default"))) float *web_out_l(void) { return out_l; }
__attribute__((used, visibility("default"))) float *web_out_r(void) { return out_r; }

/* n frames (<= 1024) into out_l / out_r: the device runs until they exist */
__attribute__((used, visibility("default"))) void web_render(uint32_t n)
{
    uint32_t k;
    if (n > 1024u)
        n = 1024u;
    while (ring_w - ring_r < n)
        run_ms(1);
    for (k = 0; k < n; k++) {
        uint32_t i = (ring_r++ % RING) * 2u;
        out_l[k] = ring[i];
        out_r[k] = ring[i + 1];
    }
}

/* a screen reader (fm1-reader): the page writes a SysEx frame (the bytes between F0 and F7) to web_sysex_buf and
 * calls web_sysex(n); what the firmware says back, whole F0..F7 frames, from web_said_buf (web_said_len bytes;
 * web_said_clear when read) */
static uint8_t said_buf[4096], sx_in[512];
static uint32_t said_n;
static void web_said(const uint8_t *p, uint32_t n)
{
    if (said_n + n <= sizeof said_buf) {
        memcpy(said_buf + said_n, p, n);
        said_n += n;
    }
}
__attribute__((used, visibility("default"))) uint8_t *web_said_buf(void) { return said_buf; }
__attribute__((used, visibility("default"))) uint32_t web_said_len(void) { return said_n; }
__attribute__((used, visibility("default"))) void web_said_clear(void) { said_n = 0; }
__attribute__((used, visibility("default"))) uint8_t *web_sysex_buf(void) { return sx_in; }
__attribute__((used, visibility("default"))) void web_sysex(uint32_t n) { if(n>sizeof sx_in)return;if(!ann_frame(sx_in,n,now_ms))app_sysex(sx_in,n); }

__attribute__((used, visibility("default"))) void web_boot(void) { boot(); }
__attribute__((used, visibility("default"))) void web_buttons(uint32_t m) { held_btn = m; }
__attribute__((used, visibility("default"))) void web_keys(uint32_t m)
{
#ifdef APP_KEY_SENSE
    uint32_t k, ch = m ^ held_keys;       /* each key landing at velocity 100 (the app makes its readings) */
    for (k = 0; k < NKEYS; k++)
        if (ch >> k & 1u)
            app_host_key(k, m >> k & 1u ? 100u : 0u, 0);
#endif
    held_keys = m;
}
/* one key at velocity vel 1..127 (0 = up), pressed press 0..1000 more (APP_KEY_SENSE; else just down or up) */
__attribute__((used, visibility("default"))) void web_key(uint32_t k, uint32_t vel, uint32_t press)
{
    if (k >= NKEYS)
        return;
#ifdef APP_KEY_SENSE
    app_host_key(k, vel > 127u ? 127u : vel, (press > 1000u ? 1000u : press) / 10u);
#endif
    if (vel)
        held_keys |= 1u << k;
    else
        held_keys &= ~(1u << k);
}
__attribute__((used, visibility("default"))) void web_enc(int role, int32_t n)
{
    if (role >= 0 && role < NE)
        enc_acc[role] += n;
}
__attribute__((used, visibility("default"))) void web_master(uint32_t v) { master = v > 4096u ? 4096u : v; }
__attribute__((used, visibility("default"))) uint32_t web_lit_buttons(void) { return lit_btn; }
__attribute__((used, visibility("default"))) uint32_t web_lit_keys(void) { return lit_keys; }
__attribute__((used, visibility("default"))) uint32_t web_dim_buttons(void) { return dim_btn; }
__attribute__((used, visibility("default"))) uint32_t web_dim_keys(void) { return dim_keys; }

/* MIDI: in from the page (port PORT_*: a Web MIDI input is USB), out as the app sent it (USB-MIDI packets) */
__attribute__((used, visibility("default"))) void web_midi_in(uint32_t port, uint32_t pkt)
{
    if (port < NPORTS && mi_w - mi_r < MQ) {
        min_q[mi_w % MQ] = pkt;
        min_port[mi_w++ % MQ] = port;
    }
}
__attribute__((used, visibility("default"))) uint32_t web_out_n(void) { return n_out; }
__attribute__((used, visibility("default"))) uint32_t *web_out_pkts(void) { return out_pkt; }
__attribute__((used, visibility("default"))) void web_out_clear(void) { n_out = 0; }
__attribute__((used, visibility("default"))) uint16_t *web_fb(void) { return fb; }
__attribute__((used, visibility("default"))) uint32_t web_blits(void) { return blits; }
__attribute__((used, visibility("default"))) uint32_t web_now(void) { return now_ms; }
__attribute__((used, visibility("default"))) uint32_t web_cpu(void) { return cpu_pct; }

/* saved objects: the page keeps them (localStorage) and gives them back before boot */
__attribute__((used, visibility("default"))) uint8_t *web_store(uint32_t obj) { store_ready(); return obj < OBJ_NOBJ ? store[obj] : 0; }
__attribute__((used, visibility("default"))) int web_store_len(uint32_t obj) { store_ready(); return obj < OBJ_NOBJ ? store_len[obj] : -1; }
__attribute__((used, visibility("default"))) void web_store_set_len(uint32_t obj, int n)
{
    store_ready();
    if (obj < OBJ_NOBJ)
        store_len[obj] = n < 0 ? -1 : n > (int)PLAT_STORE_MAX ? (int)PLAT_STORE_MAX : n;
}
/* Simulator-only failure injection; no hardware storage hook. */
__attribute__((used, visibility("default"))) void web_store_fail(uint32_t obj){web_store_failed_object=obj<OBJ_NOBJ?(int)obj:-1;}
__attribute__((used, visibility("default"))) uint32_t web_store_writes(void) { return store_writes; }
__attribute__((used, visibility("default"))) uint32_t web_nobj(void) { return OBJ_NOBJ; }
__attribute__((used, visibility("default"))) uint32_t web_store_max(void) { return PLAT_STORE_MAX; }

/* Zombie emulator: a power-cycle clears input and queued audio, while flash objects persist. */
__attribute__((used, visibility("default"))) void web_reset(void){held_btn=held_keys=0;
#ifdef APP_KEY_SENSE
for(uint32_t k=0;k<NKEYS;k++)app_host_key(k,0,0);
#endif
#ifdef APP_TOUCH
touch_on(0);touch_on(1);
#endif
ring_w=ring_r=0;boot();}

__attribute__((used, visibility("default"))) uint32_t web_step_grid(void){return roll_grid();}
