/* SPDX-License-Identifier: MIT
 * Original Zombie Core synthesizer. Same C source runs on AC79 and browser WASM.
 * Floating-point oscillators with polyBLEP, two-pole feedback filter, ADSR,
 * two-operator FM, phase distortion, percussion and linear PCM sampler.
 * Tables are generated from mathematical definitions by tools/build-core.py. */
#include "dsp.h"
#include "z_tables.h"
#if Z_SAMPLER_EDITION
#include "z_samples.h"
#endif
#include "z_presets.h"
#ifndef Z_POOL
#ifdef Z_WASM
#define Z_POOL
#else
#define Z_POOL __attribute__((section(".pool")))
#endif
#endif
const char *const z_models[9]={"ANALOG","FM-2","PHASE","WAVETABLE","NOISE","KICK","SNARE","HAT","SAMPLE"};
const z_descriptor z_desc[Z_PARAMS]={
 {"model",0,8,0},{"wave",0,3,1},{"mix",0,127,64},{"detune",0,127,18},
 {"cutoff",0,127,100},{"resonance",0,127,24},{"attack",0,127,2},{"decay",0,127,45},
 {"sustain",0,127,90},{"release",0,127,35},{"fm",0,127,35},{"ratio",1,16,2},
 {"drive",0,127,0},{"delay",0,127,0},{"reverb",0,127,15},{"level",0,127,95},
 {"pan",-64,63,0},{"lfoRate",0,127,30},{"lfoDepth",0,127,0},{"sample",0,13,0},
 {"root",0,127,60},{"mute",0,1,0},{"channel",1,16,1},{"length",1,64,16},
 {"gate",1,127,80},{"transpose",-24,24,0},{"probability",0,127,127}};
z_project z_song;
typedef struct { float phase,phase2,env,lp1,lp2,velocity,age,pos,inc,glide,fmx,rnd,cutm,hold_x; uint32_t stamp,gate,wait; uint16_t hold_n;
                 uint8_t track,note,stage,active,released,arp,pad,drum;float drum_decay,out_l,out_r;z_pad settings;uint32_t sample_start,sample_end; } voice;
static voice voices[Z_VOICES];
static Z_POOL float delay_l[8192],delay_r[8192],comb_a[1499],comb_b[1877];
static Z_POOL uint8_t transfer[Z_SLOT_BYTES];
#ifdef Z_WASM
static Z_POOL int16_t preview_pcm[4][Z_PCM_MAX];
#endif
static Z_POOL float render_buffer[512];
static const int16_t *pcm[14];
static uint32_t pcm_n[14],pcm_rate[14];
#include "sampler.inc"
static uint32_t rng_state,stamp,delay_i,comb_i,playing,pos,external_clock,clock_ticks;
static float step_time,lfo_phase[Z_TRACKS];
/* 0.21 motion: per-track modulators (vibrato/tremolo phase, the random LFO and drift), the last note for glide, rolls */
static float vib_phase[Z_TRACKS],lfo_hold[Z_TRACKS],lfo_prev[Z_TRACKS],drift_v[Z_TRACKS],drift_to[Z_TRACKS],roll_cd[Z_TRACKS],roll_iv[Z_TRACKS];
static uint8_t last_note[Z_TRACKS]={255,255,255,255,255,255},roll_left[Z_TRACKS],roll_note[Z_TRACKS],roll_vel[Z_TRACKS],seq_trigger;
static float bend[Z_TRACKS];
static uint8_t sustain[Z_TRACKS];
static float dc_xl,dc_xr,dc_yl,dc_yr,bus_gain=1,declick_l,declick_r,wet_l,wet_r;
static uint8_t arp_notes[6][128],arp_physical[6][16];
static float arp_time[6];
static uint32_t arp_index[6],revision;
static void (*midi_out)(uint32_t,uint32_t,uint32_t,uint32_t);
static uint32_t audio_frame,last_step_frame,live_effect,live_requested,click_left,clock_beat_frame,clock_pulses,clock_last_frame;
static float click_phase,live_phase,live_blend,click_hz=1200;
/* Count-in before a live take (Felucca-style): clicks on each beat, then the transport and the take start together. */
static uint32_t countin_left,countin_beat,rec_click=1;
static uint8_t arp_count[6],rec_at[6][128],rec_active[6][128],applied_mode[6];
static uint32_t rec_start[6][128],rec_skip[6][128];
static uint8_t rec_live[6][128];
static uint32_t random32(void);
/* Undo stores musical patterns only. Transport, language and live settings stay put. */
typedef struct {z_step steps[6][64];uint8_t chord[6][64][3],duration[6][64];int16_t length[6];} z_pattern_snapshot;
/* Undo is a ring of the last Z_HIST pattern states (0.17: 8, was 4). The ring moves a start index instead of copying
 * the whole history, so a checkpoint, made with interrupts off, copies one snapshot only. */
#define Z_HIST 8
static Z_POOL z_pattern_snapshot undo_bank[Z_HIST],redo_bank[Z_HIST];
static uint32_t undo_count,redo_count,undo_head,redo_head,solo_track;
static void pattern_capture(z_pattern_snapshot *p){uint32_t t,i,j;for(t=0;t<6;t++){
 p->length[t]=z_song.track[t].p[Z_LENGTH];for(i=0;i<64;i++){p->steps[t][i]=z_song.track[t].steps[i];p->duration[t][i]=z_song.duration[t][i];for(j=0;j<3;j++)p->chord[t][i][j]=z_song.chord[t][i][j];}
}}
static void pattern_restore(const z_pattern_snapshot *p){uint32_t t,i,j;for(t=0;t<6;t++){
 z_song.track[t].p[Z_LENGTH]=p->length[t];for(i=0;i<64;i++){z_song.track[t].steps[i]=p->steps[t][i];z_song.duration[t][i]=p->duration[t][i];for(j=0;j<3;j++)z_song.chord[t][i][j]=p->chord[t][i][j];}
}z_touch();}
static void history_push(z_pattern_snapshot *bank,uint32_t *count,uint32_t *head){if(*count==Z_HIST){*head=(*head+1)%Z_HIST;(*count)--;}pattern_capture(&bank[(*head+(*count)++)%Z_HIST]);}
static const z_pattern_snapshot *history_pop(const z_pattern_snapshot *bank,uint32_t *count,uint32_t head){return &bank[(head+--(*count))%Z_HIST];}
void z_checkpoint(void){history_push(undo_bank,&undo_count,&undo_head);redo_count=0;}
uint32_t z_history_state(void){if(z_drum_track(z_song.selected))return z_dm_history_state();return undo_count|(redo_count<<8);}
void z_history_reset(void){z_dm_history_reset();undo_count=redo_count=0;}
uint32_t z_history(uint32_t redo){if(z_drum_track(z_song.selected))return z_dm_history(redo);
 if(redo>1)return 0;
 if(redo){if(!redo_count)return 0;z_record(0);z_alloff(z_song.selected);history_push(undo_bank,&undo_count,&undo_head);pattern_restore(history_pop(redo_bank,&redo_count,redo_head));}
 else {if(!undo_count)return 0;z_record(0);z_alloff(z_song.selected);history_push(redo_bank,&redo_count,&redo_head);pattern_restore(history_pop(undo_bank,&undo_count,undo_head));}
 return 1;
}
uint32_t z_solo_state(void){return solo_track;}
void z_solo(uint32_t t){uint32_t i;if(t>6)return;solo_track=t;if(t&&midi_out)for(i=0;i<6;i++)if(i+1!=t)midi_out(i,128,0,0);}
int z_pattern(uint32_t t,uint32_t action,uint32_t target){
 uint32_t i,j,len;z_step step;uint8_t chord[3],duration;
 if(t>=6||action>9)return -1;if(action==0)return z_erase(t,0,1);if(z_drum_track(t))return z_dm_pattern(action,target);if(action==4&&z_drum_track(target))return -1;len=z_song.track[t].p[Z_LENGTH];
 if(action==1&&len>32)return -1;if(action==4&&(target>=6||target==t))return -1;if(action==7&&len<2)return -1;
 z_record(0);z_checkpoint();
 if(action==7){z_song.track[t].p[Z_LENGTH]=(int16_t)(len/2);z_touch();return 0;}   /* HALF: the loop cut to its first half */
 if(action==8){/* COOK: two small changes: a step switched on (with the pitch of another active step, so it stays in key) or off, or an accent */
  for(j=0;j<2;j++){z_step *s;uint32_t r=random32();i=r%len;s=&z_song.track[t].steps[i];r=random32();
   if(!s->velocity){uint32_t k,n=0,pick=r%7;uint8_t note=s->note;for(k=0;k<len;k++)if(z_song.track[t].steps[k].velocity){if(n++==pick%(len))note=z_song.track[t].steps[k].note;}s->note=note;s->velocity=(uint8_t)(80+(r>>8&31));s->chance=127;s->gate=70;z_song.duration[t][i]=0;}
   else if(r&1)s->velocity=0;else{int x=s->velocity+((r&2)?22:-22);s->velocity=(uint8_t)(x<20?20:x>127?127:x);}}
  z_touch();return 0;}
 if(action==9){/* EUCLID: HITS spread evenly over the steps (target = hits | rotation << 8); new hits take the cursor step's pitch */
  uint32_t hits=target&255,rot=(target>>8)&255;uint8_t pitch=z_song.track[t].steps[z_song.step_edit%len].velocity?z_song.track[t].steps[z_song.step_edit%len].note:60;
  if(hits>len)hits=len;for(i=0;i<len;i++){uint32_t k=(i+len-rot%len)%len,hit=hits&&((k*hits)%len)<hits;z_step *s=&z_song.track[t].steps[i];
   if(hit){if(!s->velocity){s->note=pitch;s->velocity=100;s->chance=127;s->gate=(uint8_t)z_get(t,Z_GATE);z_song.duration[t][i]=0;for(j=0;j<3;j++)z_song.chord[t][i][j]=0;}}
   else{s->velocity=0;z_song.duration[t][i]=0;for(j=0;j<3;j++)z_song.chord[t][i][j]=0;}}
  z_touch();return 0;}
 if(action==1||action==4){uint32_t dst=action==4?target:t,offset=action==4?0:len;
  for(i=0;i<(action==4?64:len);i++){z_song.track[dst].steps[offset+i]=z_song.track[t].steps[i];z_song.duration[dst][offset+i]=z_song.duration[t][i];for(j=0;j<3;j++)z_song.chord[dst][offset+i][j]=z_song.chord[t][i][j];}
  z_song.track[dst].p[Z_LENGTH]=(int16_t)(action==4?len:len*2);
 }else if(action==6){int model=z_song.track[t].p[Z_MODEL];for(i=0;i<len;i++){static const uint8_t notes[4]={48,48,55,58};z_step *s=&z_song.track[t].steps[i];s->note=model>=5&&model<=7?60:notes[random32()&3];s->velocity=model==5?(i%4==0?110:0):model==6?(i%8==4?110:0):model==7?(i%2==0?85:0):((random32()&3)<2?100:0);s->chance=127;s->gate=70;z_song.duration[t][i]=0;for(j=0;j<3;j++)z_song.chord[t][i][j]=0;}}
 else if(action==5){for(i=0;i<len/2;i++){uint32_t b=len-1-i;step=z_song.track[t].steps[i];duration=z_song.duration[t][i];for(j=0;j<3;j++)chord[j]=z_song.chord[t][i][j];z_song.track[t].steps[i]=z_song.track[t].steps[b];z_song.duration[t][i]=z_song.duration[t][b];z_song.track[t].steps[b]=step;z_song.duration[t][b]=duration;for(j=0;j<3;j++){z_song.chord[t][i][j]=z_song.chord[t][b][j];z_song.chord[t][b][j]=chord[j];}}}
 else {
  uint32_t first=action==2?0:len-1;step=z_song.track[t].steps[first];duration=z_song.duration[t][first];for(j=0;j<3;j++)chord[j]=z_song.chord[t][first][j];
  for(i=0;i<len-1;i++){uint32_t dst=action==2?i:len-1-i,src=action==2?i+1:len-2-i;z_song.track[t].steps[dst]=z_song.track[t].steps[src];z_song.duration[t][dst]=z_song.duration[t][src];for(j=0;j<3;j++)z_song.chord[t][dst][j]=z_song.chord[t][src][j];}
  first=action==2?len-1:0;z_song.track[t].steps[first]=step;z_song.duration[t][first]=duration;for(j=0;j<3;j++)z_song.chord[t][first][j]=chord[j];
 }

 z_touch();return 0;
}
static float step_frames(void){return 661500.0f/z_song.bpm;}
static void dm_record_reset(void);
static void record_finish(uint32_t t,uint32_t n){
 if(rec_active[t][n]&&rec_live[t][n]){uint32_t at=rec_at[t][n];float len=(audio_frame-rec_start[t][n])/step_frames();
  uint32_t whole,gate;if(len<0.04f)len=0.04f;if(len>63.99f)len=63.99f;
  whole=(uint32_t)len;gate=(uint32_t)((len-whole)*127);if(gate<1)gate=1;
  if(whole>z_song.duration[t][at]||(whole==z_song.duration[t][at]&&gate>z_song.track[t].steps[at].gate)){
   z_song.duration[t][at]=(uint8_t)whole;z_song.track[t].steps[at].gate=(uint8_t)gate;
  }
  z_touch();
 }
 rec_active[t][n]=rec_live[t][n]=0;
}
void z_record(uint32_t on){uint32_t t,n;on=!!on;if(on&&!z_song.recording){z_checkpoint();if(!Z_SAMPLER_EDITION)z_dm_checkpoint();}
 if(!on)for(t=0;t<6;t++)for(n=0;n<128;n++)record_finish(t,n);
 if(z_song.recording!=on){if(!Z_SAMPLER_EDITION)dm_record_reset();z_song.recording=(uint8_t)on;z_touch();}
}
void z_live(uint32_t effect){live_requested=effect<=16?effect:0;if(live_requested)live_effect=live_requested;}
uint32_t z_live_state(void){return live_requested;}
void z_clear_track(uint32_t t){(void)z_erase(t,0,2);}
/* Reconcile control changes without copying transient key/transport state. */
void z_apply_state(void){uint32_t t,n;
 for(t=0;t<6;t++){if(Z_SAMPLER_EDITION&&z_song.track[t].p[Z_MODEL]!=8){z_song.track[t].p[Z_MODEL]=8;z_song.track[t].p[Z_ATTACK]=0;z_song.track[t].p[Z_SUSTAIN]=127;z_song.track[t].p[Z_RELEASE]=8;z_song.preset[t]=255;}else if(!Z_SAMPLER_EDITION&&z_song.track[t].p[Z_MODEL]>7&&(t==5||z_song.track[t].p[Z_SAMPLE]<6||z_song.track[t].p[Z_SAMPLE]>9)){z_song.track[t].p[Z_MODEL]=0;z_song.preset[t]=255;}} /* a Groovebox SAMPLE track keeps its USR slot */
 z_sampler.tracks=Z_SAMPLER_EDITION?63:0;
 if(!Z_SAMPLER_EDITION){z_song.track[5].p[Z_MODEL]=7;z_song.preset[5]=255;z_song.arp_mode[5]=z_song.arp_hold[5]=0;}
 for(t=0;t<6;t++){if(applied_mode[t]!=z_song.arp_mode[t]){z_alloff(t);applied_mode[t]=z_song.arp_mode[t];}arp_count[t]=0;for(n=0;n<128;n++){
   if(!z_song.arp_hold[t]&&!(arp_physical[t][n/8]>>(n&7)&1))arp_notes[t][n]=0;
   if(arp_notes[t][n])arp_count[t]++;
  }
  if(!z_song.arp_mode[t]||!arp_count[t]){arp_time[t]=0;arp_index[t]=0;}
  if(z_song.arp_mode[t]&&!arp_count[t]){for(n=0;n<8;n++)if(voices[n].active&&voices[n].track==t&&voices[n].arp){voices[n].stage=4;voices[n].gate=0;}if(midi_out)midi_out(t,128,1,0);}
 }
}
static uint32_t random32(void) { uint32_t x=rng_state; x^=x<<13; x^=x>>17; x^=x<<5; return rng_state=x; }
static float absf(float x) { return x<0?-x:x; }
static float clampf(float x,float a,float b) { return x<a?a:x>b?b:x; }
static float sat(float x) { return x/(1.0f+absf(x)); }
/* p in (-1,0) can round to exactly 1.0f after +1: wrap the index, the table is periodic. */
static float sine(float p) { int i; float f; p-=(int)p; if(p<0)p+=1; p*=512; i=(int)p; f=p-i; i&=511; return z_sine[i]+(z_sine[(i+1)&511]-z_sine[i])*f; }
static float blep(float p,float dt) { if(p<dt) { p/=dt; return p+p-p*p-1; } if(p>1-dt) { p=(p-1)/dt; return p*p+p+p+1; } return 0; }
static float osc(float p,float dt,int shape) {
 if(shape==0)return sine(p);
 if(shape==1)return p*2-1-blep(p,dt);
 if(shape==2){float q=p+0.5f; if(q>=1)q-=1; return (p<0.5f?1:-1)+blep(p,dt)-blep(q,dt);}
 return 1-4*absf(p-0.5f);
}
static uint32_t dm_random(void);
#include "drums.inc"
#include "drum_machine.inc"
void z_set_midi_out(void (*cb)(uint32_t,uint32_t,uint32_t,uint32_t)) { midi_out=cb; }
/* MIDI clock out (24 per quarter note): a pulse on each 16th step and five more evenly inside it, so the clock follows
 * tempo and swing. Start before the first step, stop when the transport stops. Never while the clock is external. */
static void (*clock_out)(uint32_t);static uint32_t clk_left;static float clk_gap,clk_wait;
void z_set_clock_out(void (*cb)(uint32_t)){clock_out=cb;}
void z_touch(void) { if(++revision==0)revision=1; }
uint32_t z_revision(void) { return revision; }
uint32_t z_state_size(void) { return sizeof z_song; }
const char *z_preset_name(uint32_t p) { return p<Z_PRESETS?Z_PRESET_NAMES[p]:"EDITED"; }
int z_set(uint32_t t,uint32_t p,int v) {
 if(t>=Z_TRACKS||p>=Z_PARAMS)return -9999;
 /* 0.20: Groovebox tracks 1-5 may play the player's own WAVs (SAMPLE, USR1-USR4); the drum track stays the kit */
 if(p==Z_MODEL)v=Z_SAMPLER_EDITION?8:z_drum_track(t)?7:(v>8?8:v);
 if(!Z_SAMPLER_EDITION&&p==Z_SAMPLE)v=v<6?6:v>9?9:v;
 if(!Z_SAMPLER_EDITION&&p==Z_MODEL&&v==8){int16_t *s=&z_song.track[t].p[Z_SAMPLE];if(*s<6||*s>9)*s=6;}
 if(v<z_desc[p].min)v=z_desc[p].min;if(v>z_desc[p].max)v=z_desc[p].max;
 if(z_song.track[t].p[p]!=v){if(p==Z_CHANNEL)z_alloff(t);z_song.track[t].p[p]=(int16_t)v;
  if(p==Z_MUTE&&v&&midi_out)midi_out(t,128,0,0);
  if(p!=Z_LEVEL&&p!=Z_PAN&&p!=Z_MUTE&&p!=Z_CHANNEL&&p!=Z_LENGTH&&p!=Z_GATE&&p!=Z_PROBABILITY)z_song.preset[t]=255;
  z_touch();}return v;
}
int z_get(uint32_t t,uint32_t p) { return t<Z_TRACKS&&p<Z_PARAMS?z_song.track[t].p[p]:-9999; }
void z_reset_audio(void) {if(!Z_SAMPLER_EDITION)z_dm_transport(0);
 /* Stopping fades what was sounding (voices, echo and reverb) over ~25 ms instead of cutting it: no click on STOP. */
 uint32_t i,t;declick_l+=wet_l;declick_r+=wet_r;wet_l=wet_r=0;for(i=0;i<Z_VOICES;i++){if(voices[i].active){declick_l+=voices[i].out_l;declick_r+=voices[i].out_r;}voices[i].active=0;}
 live_effect=live_requested=0;live_blend=0;click_left=0;countin_left=0;
 for(t=0;t<6;t++){arp_count[t]=0;sustain[t]=0;applied_mode[t]=z_song.arp_mode[t];if(midi_out)midi_out(t,128,0,0);for(i=0;i<128;i++){arp_notes[t][i]=0;rec_active[t][i]=rec_live[t][i]=0;rec_skip[t][i]=0;}for(i=0;i<16;i++)arp_physical[t][i]=0;arp_time[t]=0;arp_index[t]=0;}
 for(i=0;i<8192;i++)delay_l[i]=delay_r[i]=0;
 for(i=0;i<1499;i++)comb_a[i]=0; for(i=0;i<1877;i++)comb_b[i]=0;
}
/* One catalog generates the native bank and the browser names. */
void z_preset(uint32_t t,uint32_t preset) {
 uint32_t i;int16_t *p;int level,pan,channel,mute,len,gate,prob;
 if(t>=6||preset>=Z_PRESETS)return;p=z_song.track[t].p;
 if(z_drum_track(t)){p[Z_MODEL]=7;p[Z_CUTOFF]=121;p[Z_RESONANCE]=8;p[Z_DRIVE]=16;p[Z_DELAY]=0;p[Z_REVERB]=6;z_song.preset[t]=255;z_touch();return;}
 level=p[Z_LEVEL];pan=p[Z_PAN];channel=p[Z_CHANNEL];mute=p[Z_MUTE];len=p[Z_LENGTH];gate=p[Z_GATE];prob=p[Z_PROBABILITY];
 for(i=0;i<Z_PARAMS;i++)p[i]=Z_PRESET_VALUES[preset][i];
 if(Z_SAMPLER_EDITION){p[Z_MODEL]=8;p[Z_ATTACK]=0;p[Z_SUSTAIN]=127;p[Z_RELEASE]=8;}
 p[Z_LEVEL]=level;p[Z_PAN]=pan;p[Z_CHANNEL]=channel;p[Z_MUTE]=mute;p[Z_LENGTH]=len;p[Z_GATE]=gate;p[Z_PROBABILITY]=prob;
 for(i=0;i<Z_X_SOUND;i++)z_xs.v[t][i]=Z_PRESET_X[preset][i];
 z_song.preset[t]=(uint8_t)preset;z_touch();
}
void z_sample(uint32_t s,const int16_t *data,uint32_t n,uint32_t rate) { if(s<14&&rate>=4000&&rate<=44100) {pcm[s]=data;pcm_n[s]=n;pcm_rate[s]=rate;} }
#include "edition_dsp.inc"
#include "gen.inc"
void z_init(void) {
 uint32_t t,i;z_x_reset();undo_count=redo_count=solo_track=0;for(i=0;i<sizeof z_song;i++)((uint8_t *)&z_song)[i]=0;revision=1; rng_state=0x51f15e37;stamp=0;playing=0;pos=0xffffffffu;step_time=0;external_clock=0;clock_ticks=0;
 z_song.magic=0x31434f5a;z_song.version=3;z_song.fx_amount=90;audio_frame=last_step_frame=0;live_phase=0;z_song.bpm=120;z_song.swing=0;z_song.selected=0;z_song.language=1;z_song.reserved=0; /* 0.18.2: English unless the project says otherwise */
 for(t=0;t<Z_TRACKS;t++){
  for(i=0;i<Z_PARAMS;i++)z_song.track[t].p[i]=z_desc[i].def;
  z_song.track[t].p[Z_CHANNEL]=(int16_t)(t+1);
  for(i=0;i<64;i++){z_step *s=&z_song.track[t].steps[i];s->note=60;s->velocity=0;s->chance=127;s->gate=80;}
  z_song.arp_oct[t]=1;z_song.arp_rate[t]=1;lfo_phase[t]=0;bend[t]=1;sustain[t]=0;
  {static const uint8_t defaults[6]={48,51,54,16,24,32};z_preset(t,Z_SAMPLER_EDITION?t:defaults[t]);}
 }
 for(i=0;i<14;i++){pcm[i]=0;pcm_n[i]=0;pcm_rate[i]=22050;}
#if Z_SAMPLER_EDITION
 for(i=0;i<6;i++)z_sample(i,z_factory_pcm[i],z_factory_n[i],11025);
 for(i=0;i<4;i++)z_sample(10+i,z_drum_pcm[i],z_drum_n[i],11025);
#endif
 sampler_init();z_sampler.tracks=Z_SAMPLER_EDITION?63:0;z_reset_audio();declick_l=declick_r=0;dc_xl=dc_xr=dc_yl=dc_yr=0;bus_gain=1;edition_defaults();if(!Z_SAMPLER_EDITION)z_dm_migrate();
}
void z_note(uint32_t t,uint32_t note,uint32_t vel,uint32_t on) {
 uint32_t i,best=0,oldest=0xffffffffu;voice *v;
 if(t>=Z_TRACKS||note>127)return;if(z_drum_track(t)){z_dm_key(note,vel,on);return;}
 if(!on||!vel){for(i=0;i<Z_VOICES;i++)if(voices[i].active&&voices[i].track==t&&voices[i].note==note){voices[i].released=1;if(!sustain[t]&&(voices[i].pad==255||voices[i].settings.mode))voices[i].stage=3;}return;}
 /* Free voice, else the same synth note (retrigger), else the quietest released voice, else the oldest. */
 {float quiet=2;uint32_t found=Z_VOICES;
  if(z_song.track[t].p[Z_MODEL]!=8)for(i=0;i<Z_VOICES;i++)if(voices[i].active&&voices[i].track==t&&voices[i].note==note&&voices[i].pad==255&&!voices[i].arp){found=i;break;}
  if(found==Z_VOICES)for(i=0;i<Z_VOICES;i++)if(!voices[i].active){found=i;break;}
  if(found==Z_VOICES)for(i=0;i<Z_VOICES;i++)if(voices[i].stage>=3&&voices[i].env<quiet){quiet=voices[i].env;found=i;}
  if(found==Z_VOICES)for(i=0;i<Z_VOICES;i++)if(voices[i].stamp<oldest){oldest=voices[i].stamp;found=i;}
  best=found;}
 v=&voices[best];
 if(z_song.track[t].p[Z_MODEL]==8&&(z_sampler.tracks>>t&1)){
  uint32_t start,end,slot;z_pad pad;if(note<36||note>=68)return;pad=z_sampler.pad[note-36];slot=pad.source;
  if(!pcm[slot]||pcm_n[slot]<2)return;
  start=pcm_n[slot]*(uint32_t)pad.start/65535u;end=(pcm_n[slot]*(uint32_t)pad.end+65534u)/65535u;
  if(end>pcm_n[slot])end=pcm_n[slot];if(end-start<2)return;
  if(pad.choke)for(i=0;i<8;i++)if(voices[i].active&&voices[i].pad!=255&&voices[i].settings.choke==pad.choke){voices[i].stage=4;voices[i].gate=0;}
  v->pad=(uint8_t)(note-36);v->settings=pad;v->sample_start=start;v->sample_end=end;
 }else v->pad=255;
 /* A sounding synth voice keeps its phase, filter and level: the new attack starts where it is, without a click. */
 {uint32_t legato=v->active&&v->pad==255&&v->track==t&&z_song.track[t].p[Z_MODEL]<5&&v->env>0.0005f;
 v->track=(uint8_t)t;v->note=(uint8_t)note;v->stage=0;v->active=1;v->released=0;v->arp=0;v->stamp=++stamp;
 if(!legato&&v->active){declick_l+=v->out_l;declick_r+=v->out_r;} /* a stolen voice fades out instead of stopping dead */
 v->out_l=v->out_r=0;
 if(!legato){v->phase=0;v->phase2=0;v->env=0;v->lp1=v->lp2=0;}v->inc=0;v->age=v->pos=0;v->velocity=(vel>127?127:vel)/127.0f;v->gate=0;
 {const uint8_t *x=z_xs.v[t];float rnd=0;if(x[Z_X_RANDOM]){uint32_t r=random32();rnd=((int32_t)(r>>9)-4194304)/4194304.0f;} /* the noise engines' sequence is unchanged without RANDOM */
  v->glide=x[Z_X_GLIDE]&&last_note[t]<128&&last_note[t]!=note?z_frequency[last_note[t]]/z_frequency[note]:1;last_note[t]=(uint8_t)note;
  v->fmx=1+x[Z_X_FM_ENV]*(8.0f/127);v->rnd=rnd*x[Z_X_RANDOM]/127.0f;v->cutm=(1+v->rnd*0.5f)*(vel>=110?1.25f:1);v->hold_n=0;v->hold_x=0;
  v->wait=0;if(seq_trigger&&x[Z_X_HUMAN]){v->wait=(random32()>>8)%(1+x[Z_X_HUMAN]*12u);v->velocity*=1-(float)((random32()>>8)%(1+x[Z_X_HUMAN]))/600.0f;}}}
}
/* Panel, browser and external MIDI all enter through this same key path. */
void z_key(uint32_t t,uint32_t n,uint32_t v,uint32_t on) {
 uint32_t i,physical=0,was;if(t>=6||n>127)return;if(z_drum_track(t)){z_dm_key(n,v,on);return;}on=on&&v;was=arp_physical[t][n/8]>>(n&7)&1;
 for(i=0;i<16;i++)physical|=arp_physical[t][i];
 if(on){
  if(was)return; /* duplicate MIDI note-on must not advance or multiply a take */
  if(!physical&&z_song.arp_hold[t]){for(i=0;i<128;i++)arp_notes[t][i]=0;arp_count[t]=0;}
  arp_physical[t][n/8]|=1u<<(n&7);if(!arp_notes[t][n])arp_count[t]++;arp_notes[t][n]=(uint8_t)(v>127?127:v);
  if(!physical){arp_time[t]=0;arp_index[t]=0;}
  if(z_song.recording){
   uint32_t len=z_song.track[t].p[Z_LENGTH],at=z_song.step_edit%len,ahead=0;
   if(playing){at=pos==0xffffffffu?0:pos%len;ahead=pos==0xffffffffu;if(!ahead&&!z_song.rec_quant&&(audio_frame-last_step_frame)>=step_frames()*(1+((pos&1)?-1:1)*z_song.swing/200.0f)*0.5f){at=(at+1)%len;ahead=1;}}
   z_step *s=&z_song.track[t].steps[at];uint32_t capture=0;
   for(i=0;i<128;i++)if(rec_active[t][i]&&rec_at[t][i]==at)capture=1;
   if(!capture){z_song.duration[t][at]=0;s->gate=playing?1:(uint8_t)z_get(t,Z_GATE);}
   if(!s->velocity||(z_song.rec_mode&&!capture)){
    s->note=(uint8_t)n;s->velocity=(uint8_t)v;s->chance=127;s->gate=playing?1:(uint8_t)z_get(t,Z_GATE);z_song.duration[t][at]=0;
    for(i=0;i<3;i++)z_song.chord[t][at][i]=0;
   }else if(s->note!=n){for(i=0;i<3;i++)if(z_song.chord[t][at][i]==n+1)break;else if(!z_song.chord[t][at][i]){z_song.chord[t][at][i]=(uint8_t)(n+1);break;}}
   rec_active[t][n]=1;rec_at[t][n]=(uint8_t)at;rec_start[t][n]=audio_frame;rec_live[t][n]=(uint8_t)playing;
   if(playing&&ahead)rec_skip[t][n]=pos+2;
   if(z_song.selected==t){z_song.step_edit=(uint8_t)at;z_song.step_bank=(uint8_t)(at/16);}z_touch();
  }
 }else{
  if(!was)return;
  uint32_t captured=rec_active[t][n],capture_at=rec_at[t][n];record_finish(t,n);arp_physical[t][n/8]&=(uint8_t)~(1u<<(n&7));
  if(!z_song.arp_hold[t]||!z_song.arp_mode[t]){if(arp_notes[t][n])arp_count[t]--;arp_notes[t][n]=0;}
  physical=0;for(i=0;i<16;i++)physical|=arp_physical[t][i];
  uint32_t pending=0;for(i=0;i<128;i++)if(rec_active[t][i]&&rec_at[t][i]==capture_at)pending=1;
  if(z_song.recording&&!playing&&captured&&!pending&&z_song.selected==t&&z_song.step_edit==capture_at){z_song.step_edit=(uint8_t)((z_song.step_edit+1)%z_song.track[t].p[Z_LENGTH]);z_song.step_bank=z_song.step_edit/16;z_touch();}
  if(z_song.arp_mode[t]&&!arp_count[t]){
   arp_time[t]=0;arp_index[t]=0;
   /* Terminate generated gates now. Keep a short click-free release, not seconds of sustained arp. */
   for(i=0;i<8;i++)if(voices[i].active&&voices[i].track==t&&voices[i].arp){voices[i].released=1;voices[i].stage=4;voices[i].gate=0;}
   if(midi_out)midi_out(t,128,1,0); /* cancel pending MIDI gates for this track */
  }
 }
 if(!z_song.arp_mode[t])z_note(t,n,v,on);
}
static void arp_tick(void) {
 uint32_t t;
 for(t=0;t<6;t++)if(z_song.arp_mode[t]){
  uint32_t i,count=0,total,index,nth,n=0,v=0;float frames;
  count=arp_count[t];if(!count)continue;
  if(arp_time[t]>0){arp_time[t]-=1;continue;}total=count*z_song.arp_oct[t];index=arp_index[t]++;
  if(z_song.arp_mode[t]==2)index=total-1-index%total;
  else if(z_song.arp_mode[t]==3){uint32_t period=total>1?total*2-2:1;index%=period;if(index>=total)index=period-index;}
  else if(z_song.arp_mode[t]==4)index=random32()%total;
  else index%=total;
  nth=index%count;
  for(i=0;i<128;i++)if(arp_notes[t][i]){if(!nth){n=i+12*(index/count);v=arp_notes[t][i];break;}nth--;}
  frames=44100.0f*15/z_song.bpm;
  if(z_song.arp_rate[t]==0)frames*=2;else if(z_song.arp_rate[t]==2)frames*=0.5f;else if(z_song.arp_rate[t]==3)frames*=1.3333333f;
  arp_time[t]+=frames;
  if(n<=127&&!z_song.track[t].p[Z_MUTE]&&(!solo_track||solo_track==t+1)){z_note(t,n,v,1);for(i=0;i<8;i++)if(voices[i].active&&voices[i].track==t&&voices[i].stamp==stamp){voices[i].arp=1;voices[i].gate=(uint32_t)(frames*z_song.track[t].p[Z_GATE]/127.0f)+1;}
   if(midi_out)midi_out(t,n,v,0x80000000u|((uint32_t)(frames/44.1f*z_song.track[t].p[Z_GATE]/127.0f)+1));
  }
 }
}

void z_bend(uint32_t t,uint32_t value){float pos,f;uint32_t i;if(t>=6)return;if(value>16383)value=16383;pos=69.0f+((int)value-8192)/4096.0f;i=(uint32_t)pos;f=pos-i;bend[t]=(z_frequency[i]*(1-f)+z_frequency[i+1]*f)/440.0f;}
void z_sustain(uint32_t t,uint32_t on){uint32_t i;if(t>=6)return;sustain[t]=!!on;if(!on)for(i=0;i<8;i++)if(voices[i].active&&voices[i].track==t&&voices[i].released&&voices[i].stage!=4&&(voices[i].pad==255||voices[i].settings.mode))voices[i].stage=3;}
void z_alloff(uint32_t t){uint32_t i;if(t>=6)return;if(z_drum_track(t))z_dm_panic();for(i=0;i<128;i++)record_finish(t,i);arp_count[t]=0;if(midi_out)midi_out(t,128,0,0);sustain[t]=0;for(i=0;i<8;i++)if(voices[i].track==t){if(voices[i].active){declick_l+=voices[i].out_l;declick_r+=voices[i].out_r;}voices[i].active=0;}for(i=0;i<128;i++){arp_notes[t][i]=0;rec_skip[t][i]=0;}for(i=0;i<16;i++)arp_physical[t][i]=0;arp_index[t]=0;arp_time[t]=0;}
int z_arp_set(uint32_t t,uint32_t field,uint32_t value){uint32_t i;if(t>=6||field>3||z_drum_track(t))return -1;
 if(field==0){if(value>4)return -1;if(z_song.arp_mode[t]!=value)z_alloff(t);z_song.arp_mode[t]=(uint8_t)value;applied_mode[t]=(uint8_t)value;}
 else if(field==1){if(value>3)return -1;z_song.arp_rate[t]=(uint8_t)value;}
 else if(field==2){if(value<1||value>3)return -1;z_song.arp_oct[t]=(uint8_t)value;}
 else {if(value>1)return -1;z_song.arp_hold[t]=(uint8_t)value;if(!value)for(i=0;i<128;i++)if(!(arp_physical[t][i/8]>>(i&7)&1))arp_notes[t][i]=0;}
 z_apply_state();if(!arp_count[t]){for(i=0;i<8;i++)if(voices[i].active&&voices[i].track==t&&voices[i].arp){voices[i].stage=4;voices[i].gate=0;}if(midi_out)midi_out(t,128,1,0);}
 z_touch();return 0;
}
static void seq_step(void) {
 uint32_t t;pos++;last_step_frame=audio_frame;if(clock_out&&!external_clock){clock_out(0xF8);clk_gap=44100.0f*15/z_song.bpm*(1+((pos&1)?-1:1)*z_song.swing/200.0f)/6;clk_wait=clk_gap;clk_left=5;}if((z_song.metronome||(z_song.recording&&rec_click))&&!(pos&3)){click_left=1100;click_phase=0;click_hz=(pos&15)?1200.0f:1800.0f;}
 if(!Z_SAMPLER_EDITION)z_dm_clock();
 for(t=0;t<Z_TRACKS;t++) {
  if(z_drum_track(t))continue;
  z_track *tr=&z_song.track[t];z_step *s=&tr->steps[pos%tr->p[Z_LENGTH]];
  if((!solo_track||solo_track==t+1)&&!tr->p[Z_MUTE]&&s->velocity&&(s->chance==127||(random32()&127)<(uint32_t)s->chance)&&(tr->p[Z_PROBABILITY]==127||(random32()&127)<(uint32_t)tr->p[Z_PROBABILITY])){
   uint32_t i,j,at=pos%tr->p[Z_LENGTH];
   float duration=step_frames()*(z_song.duration[t][at]+s->gate/127.0f);seq_trigger=1;
   /* a roll: the step repeats 2-4 times inside itself */
   if(z_xs.v[t][Z_X_ROLL]&&(random32()&127)<z_xs.v[t][Z_X_ROLL]){uint32_t n=1+(random32()>>8)%3;roll_left[t]=(uint8_t)n;roll_iv[t]=step_frames()/(float)(n+1);roll_cd[t]=roll_iv[t];roll_note[t]=s->note;roll_vel[t]=(uint8_t)(s->velocity*4/5);}
   for(j=0;j<4;j++){
    uint32_t note=j?z_song.chord[t][at][j-1]:s->note+1;if(!note)continue;note--;
    /* Do not double the note under the player's finger while overdubbing. */
    if((rec_active[t][note]&&rec_at[t][note]==at)||rec_skip[t][note]==pos+1)continue;
    z_note(t,note,s->velocity,1);
    for(i=0;i<Z_VOICES;i++)if(voices[i].active&&voices[i].track==t&&voices[i].stamp==stamp)voices[i].gate=(uint32_t)duration+1;
    if(midi_out)midi_out(t,note,s->velocity,(uint32_t)(duration/44.1f)+1);
   }
   seq_trigger=0;
  }
 }
 /* evolve: a track mutates as its loop starts again (the drums every 16 steps) */
 for(t=0;t<Z_TRACKS;t++)if(z_xs.v[t][Z_G_EVOLVE]&&pos){uint32_t len=z_drum_track(t)?16:(uint32_t)z_song.track[t].p[Z_LENGTH];if(len&&pos%len==0)g_evolve_at(t);}
}
void z_countin(uint32_t beats){countin_left=0;if(!beats)return;if(external_clock){z_record(1);return;}countin_beat=(uint32_t)(2646000u/z_song.bpm);countin_left=beats*countin_beat;}
uint32_t z_countin_state(void){return countin_left?(countin_left+countin_beat-1)/countin_beat:0;}
void z_rec_click(uint32_t on){rec_click=!!on;}
void z_transport(uint32_t on) {countin_left=0;clk_left=0;if(clock_out&&!external_clock&&(on?!playing:playing))clock_out(on?0xFA:0xFC);if(on)clock_last_frame=audio_frame;if(on)for(uint32_t t=0;t<6;t++)for(uint32_t n=0;n<128;n++)rec_skip[t][n]=0;if(!Z_SAMPLER_EDITION)z_dm_transport(on); if(!on){z_record(0);z_reset_audio();solo_track=0;}playing=!!on;pos=0xffffffffu;step_time=0;clock_ticks=0;last_step_frame=audio_frame; }
uint32_t z_external(uint32_t on) {if(on&&!external_clock){clock_last_frame=audio_frame;clock_pulses=0;clock_beat_frame=audio_frame;}external_clock=!!on;if(z_song.reserved!=(uint8_t)external_clock){z_song.reserved=(uint8_t)external_clock;z_touch();}return external_clock;}
void z_clock(uint32_t status) {
 if(!external_clock)return;
 if(status==0xfa){clock_pulses=0;clock_beat_frame=audio_frame;clock_last_frame=audio_frame;z_transport(1);}
 else if(status==0xfb){playing=1;clock_last_frame=audio_frame;}
 else if(status==0xfc){uint32_t at=pos,ticks=clock_ticks,drums=dm_count;z_transport(0);pos=at;clock_ticks=ticks;dm_count=drums;}
 else if(status==0xf8){
  clock_last_frame=audio_frame;
  if(!clock_pulses)clock_beat_frame=audio_frame;
  if(++clock_pulses==25){uint32_t frames=audio_frame-clock_beat_frame;
   if(frames>=8820&&frames<=88200){uint32_t bpm=(2646000u+frames/2)/frames;if(bpm!=z_song.bpm)z_tempo(bpm,z_song.swing);}
   clock_pulses=1;clock_beat_frame=audio_frame;
  }
  if(playing&&clock_ticks++%6==0)seq_step();
 }
}
void z_songpos(uint32_t sixteenths){if(!external_clock)return;pos=sixteenths-1;if(!Z_SAMPLER_EDITION)z_dm_songpos(sixteenths);clock_ticks=0;last_step_frame=audio_frame;}
void z_tempo(uint32_t bpm,uint32_t swing) {z_song.bpm=(uint16_t)(bpm<30?30:bpm>300?300:bpm);z_song.swing=(uint8_t)(swing>60?60:swing);z_touch();}
void z_step_set(uint32_t t,uint32_t i,uint32_t n,uint32_t v,uint32_t c,uint32_t g) {
 z_step *s;if(t>=Z_TRACKS||i>=64)return;if(z_drum_track(t)){z_dm_step(z_drum_index(n),i,v,c,z_dm.step[z_drum_index(n)][i].ratchet);return;}z_step next={(uint8_t)(n>127?127:n),(uint8_t)(v>127?127:v),(uint8_t)(c>127?127:c),(uint8_t)(g<1?1:g>127?127:g)};s=&z_song.track[t].steps[i];if(s->note==next.note&&s->velocity==next.velocity&&s->chance==next.chance&&s->gate==next.gate&&!z_song.duration[t][i]&&!z_song.chord[t][i][0]&&!z_song.chord[t][i][1]&&!z_song.chord[t][i][2])return;if(z_song.recording){z_record(0);z_alloff(t);}z_checkpoint();*s=next;z_song.duration[t][i]=0;{uint32_t j;for(j=0;j<3;j++)z_song.chord[t][i][j]=0;}z_touch();
}
void z_render(float *out,uint32_t n) {
 uint32_t frame,k,t;float attack[6],decay[6],release[6],cut[6],lfo[6],pm[6],fmm[6],am[6],pano[6],gc[6],fmd[6],crq[6];uint32_t crn[6];
 for(t=0;t<6;t++){int16_t *p=z_song.track[t].p;
  attack[t]=1.0f/(1+p[Z_ATTACK]*p[Z_ATTACK]*9.0f);if(attack[t]>0.1f)attack[t]=0.1f; /* ATTACK 0 ramps like 1 (10 samples): no onset click */decay[t]=1.0f/(20+p[Z_DECAY]*p[Z_DECAY]*5.0f);release[t]=1.0f/(20+p[Z_RELEASE]*p[Z_RELEASE]*6.0f);
  /* Hats use a single audible decay instead of a sub-ms ADSR multiplied by another fade. */
  if(p[Z_MODEL]==7){decay[t]=1.0f/(441+p[Z_DECAY]*90.0f);release[t]=1.0f/(220+p[Z_RELEASE]*60.0f);}
  {const uint8_t *x=z_xs.v[t];float ph,sh,vib;uint32_t wrap;
  lfo_phase[t]+=(0.05f+p[Z_LFO_RATE]*0.12f)*n/44100.0f;wrap=lfo_phase[t]>=1;if(wrap){lfo_phase[t]-=(int)lfo_phase[t];if(x[Z_X_SHAPE]>=4){lfo_prev[t]=lfo_hold[t];lfo_hold[t]=((int32_t)(random32()>>9)-4194304)/4194304.0f;}}ph=lfo_phase[t];
  /* LFO shape: sine, triangle, saw, square, sample & hold, smooth random */
  sh=x[Z_X_SHAPE]==1?(ph<0.5f?4*ph-1:3-4*ph):x[Z_X_SHAPE]==2?1-2*ph:x[Z_X_SHAPE]==3?(ph<0.5f?1.0f:-1.0f):x[Z_X_SHAPE]==4?lfo_hold[t]:x[Z_X_SHAPE]==5?lfo_prev[t]+(lfo_hold[t]-lfo_prev[t])*ph:sine(ph);
  lfo[t]=sh*p[Z_LFO_DEPTH]/127.0f;
  vib_phase[t]+=(0.5f+x[Z_X_VIB_RATE]*0.09f)*n/44100.0f;if(vib_phase[t]>=1)vib_phase[t]-=(int)vib_phase[t];vib=sine(vib_phase[t]);
  if(x[Z_X_DRIFT]&&(random32()&255)<8)drift_to[t]=((int32_t)(random32()>>9)-4194304)/4194304.0f;drift_v[t]+=(drift_to[t]-drift_v[t])*0.02f;
  pm[t]=(1+vib*x[Z_X_VIB]*(0.0595f/127))*(1+drift_v[t]*x[Z_X_DRIFT]*(0.03f/127));if(x[Z_X_TARGET]==1)pm[t]*=1+lfo[t]*0.119f;
  fmm[t]=x[Z_X_TARGET]==2?1+lfo[t]:1;am[t]=1-x[Z_X_TREM]*(0.5f/127)*(1-sine(vib_phase[t]*0.5f+0.25f));if(x[Z_X_TARGET]==3)am[t]*=1+lfo[t]*0.5f;if(am[t]<0)am[t]=0;
  pano[t]=x[Z_X_TARGET]==4?lfo[t]*0.45f:0;
  gc[t]=x[Z_X_GLIDE]?1.0f/(1+x[Z_X_GLIDE]*x[Z_X_GLIDE]*2.7f):1;fmd[t]=1-1.0f/(200+p[Z_DECAY]*p[Z_DECAY]*3.0f);
  crn[t]=x[Z_X_CRUSH]?1+x[Z_X_CRUSH]/8u:0;crq[t]=x[Z_X_CRUSH]?(float)(1u<<(15-x[Z_X_CRUSH]*11/127)):0;
  cut[t]=clampf(z_filter[p[Z_CUTOFF]]*(1+(x[Z_X_TARGET]==0?lfo[t]:0)*0.8f)*(1+drift_v[t]*x[Z_X_DRIFT]*(0.2f/127)),0.001f,0.78f);}
 }
 for(frame=0;frame<n;frame++) {
  audio_frame++;
  if(external_clock&&playing&&audio_frame-clock_last_frame>110250)z_transport(0);
  arp_tick();
  for(t=0;t<5;t++)if(roll_left[t]&&(roll_cd[t]-=1)<=0){uint32_t i;roll_cd[t]+=roll_iv[t];roll_left[t]--;z_note(t,roll_note[t],roll_vel[t],1);for(i=0;i<Z_VOICES;i++)if(voices[i].active&&voices[i].track==t&&voices[i].stamp==stamp)voices[i].gate=(uint32_t)(roll_iv[t]*0.7f)+1;roll_vel[t]=(uint8_t)(roll_vel[t]*7/8);}
  if(clk_left&&--clk_wait<=0){if(clock_out)clock_out(0xF8);clk_left--;clk_wait+=clk_gap;}
  float l=0,r=0,sendd=0,sendr=0;
  if(playing&&!external_clock){if(step_time<=0){seq_step();step_time+=44100.0f*15/z_song.bpm*(1+((pos&1)?-1:1)*z_song.swing/200.0f);}step_time-=1;}
  for(k=0;k<8;k++){
   voice *v=&voices[k];int16_t *p;float x=0,dt,dt2,e,a,pan;int model,note,ss;
   if(!v->active)continue;if(v->wait){v->wait--;continue;}t=v->track;p=z_song.track[t].p;model=Z_SAMPLER_EDITION?8:p[Z_MODEL];
   /* A held one-shot must still end if its track changes to a synth preset. */
   if(v->pad!=255&&(model!=8||!(z_sampler.tracks>>t&1))){v->stage=4;model=8;}
   if(v->gate&&--v->gate==0&&(v->pad==255||v->settings.mode))v->stage=3;
   if(v->stage==0){v->env+=attack[t];if(v->env>=1){v->env=1;v->stage=1;}}
   else if(v->stage==1){v->env+=(p[Z_SUSTAIN]/127.0f-v->env)*decay[t];if(absf(v->env-p[Z_SUSTAIN]/127.0f)<0.0001f)v->stage=2;}
   else if(v->stage==4){v->env*=0.985f;if(v->env<0.00008f){v->active=0;continue;}}
   else if(v->stage==3){v->env-=v->env*release[t];if(v->env<0.00008f){v->active=0;continue;}}
   if(model==7&&v->stage==2&&!p[Z_SUSTAIN]){v->active=0;continue;}
   note=(int)v->note+p[Z_TRANSPOSE];if(note<0)note=0;if(note>127)note=127;
   dt=z_frequency[note]/44100.0f*bend[t]*pm[t]*v->glide;v->glide+=(1-v->glide)*gc[t];dt2=dt*(1+p[Z_DETUNE]*0.00015f);e=v->env;
   {float fx=v->fmx*fmm[t]*(1+v->rnd*0.6f);v->fmx=1+(v->fmx-1)*fmd[t];
   v->age+=1.0f/44100;v->phase+=dt;v->phase2+=dt2;if(v->phase>=1)v->phase-=1;if(v->phase2>=1)v->phase2-=1;
   if(model==0)x=osc(v->phase,dt,p[Z_WAVE])*(1-p[Z_MIX]/254.0f)+osc(v->phase2,dt2,p[Z_WAVE])*p[Z_MIX]/254.0f;
   else if(model==1)x=sine(v->phase+sine(v->phase*p[Z_RATIO])*p[Z_FM]/45.0f*e*fx);
   else if(model==2){float pivot=clampf(0.08f+p[Z_FM]/151.0f*fx,0.02f,0.95f);float ph=v->phase<pivot?v->phase*0.5f/pivot:0.5f+(v->phase-pivot)*0.5f/(1-pivot);x=sine(ph);}
   else if(model==3){float m=clampf(p[Z_MIX]/127.0f+lfo[t]*0.3f+(fx-1)*0.12f,0,1);x=sine(v->phase)*(1-m)+0.5f*(sine(v->phase*3)+sine(v->phase*5))*m;}
   else if(model==4)x=((int32_t)(random32()>>9)-4194304)/4194304.0f;
   else if(model==5){float bend=1+p[Z_FM]/4.0f/(1+v->age*90);v->pos+=dt*0.21f*bend;x=sine(v->pos)/(1+v->age*v->age*(15000.0f/(p[Z_DECAY]+3)));if(v->age>2)v->stage=3;}
   else if(model==6){x=(((int32_t)(random32()>>9)-4194304)/4194304.0f*0.7f+sine(v->phase)*0.3f)/(1+v->age*v->age*10000/(p[Z_DECAY]+1));if(v->age>1)v->stage=3;}
   else if(model==7){float noise=((int32_t)(random32()>>9)-4194304)/4194304.0f;
    /* Remove the low thud; a small inharmonic ring gives the noise a metallic edge. */
    v->inc+=(noise-v->inc)*0.35f;x=(noise-v->inc)*1.2f+sine(v->phase*17)*sine(v->phase2*23)*0.12f;
   }
   else if(v->pad!=255){
    const z_pad *pad=&v->settings;uint32_t span=v->sample_end-v->sample_start,j,next;float f,step;
    ss=pad->source;if(!pcm[ss]||v->sample_end>pcm_n[ss]){v->active=0;continue;}
    if(v->pos>=span){if(pad->mode==2)v->pos-=span*(uint32_t)(v->pos/span);else{v->active=0;continue;}}
    j=(uint32_t)v->pos;f=v->pos-j;next=j+1<span?j+1:pad->mode==2?0:j;
    if(pad->reverse){j=v->sample_end-1-j;next=v->sample_end-1-next;}else{j+=v->sample_start;next+=v->sample_start;}
    x=(pcm[ss][j]*(1-f)+pcm[ss][next]*f)/32768.0f;
    if(pad->quality){int scale=pad->quality==1?2048:128;x=(int)(x*scale)/(float)scale;}
    step=pcm_rate[ss]/44100.0f*z_frequency[60+pad->tune]/z_frequency[60]*bend[t];v->pos+=step;
    /* A short edge ramp avoids clicks at trim boundaries without editing source PCM. */
    {float edge=v->pos<32?v->pos/32:1;if(pad->mode!=2&&span-v->pos<32)edge=clampf((span-v->pos)/32,0,edge);x*=edge;}
    x*=pad->gain/100.0f;
   }
   else {ss=p[Z_SAMPLE];if(!pcm[ss]||v->pos>=pcm_n[ss]-1){v->active=0;continue;}uint32_t j=(uint32_t)v->pos;float f=v->pos-j;x=(pcm[ss][j]*(1-f)+pcm[ss][j+1]*f)/32768.0f;v->pos+=pcm_rate[ss]/44100.0f*z_frequency[note]/z_frequency[p[Z_ROOT]]*bend[t];}
   }
   if(crn[t]){if(v->hold_n==0){v->hold_n=(uint16_t)crn[t];v->hold_x=(float)(int32_t)(x*crq[t])/crq[t];}v->hold_n--;x=v->hold_x;}
   {float c=clampf(cut[t]*v->cutm,0.001f,0.78f);x=clampf(x-v->lp2*p[Z_RESONANCE]/100.0f,-3,3);v->lp1+=(x-v->lp1)*c;v->lp2+=(v->lp1-v->lp2)*c;x=v->lp2;}
   a=1+p[Z_DRIVE]/20.0f;x=sat(x*a)*1.4f*e*v->velocity*p[Z_LEVEL]/127.0f*0.5f*am[t];
   if(p[Z_MUTE]||(solo_track&&solo_track!=t+1))x=0;pan=clampf(p[Z_PAN]/128.0f+pano[t]+(v->pad==255?0:v->settings.pan/128.0f),-0.5f,0.5f);v->out_l=x*(0.5f-pan);v->out_r=x*(0.5f+pan);l+=v->out_l;r+=v->out_r;sendd+=x*p[Z_DELAY]/127.0f;sendr+=x*p[Z_REVERB]/127.0f;
  }
  l+=declick_l;r+=declick_r;declick_l*=0.996f;declick_r*=0.996f;
  if(!Z_SAMPLER_EDITION)z_dm_audio(&l,&r,&sendd,&sendr,cut[5]);
  {uint32_t di=(delay_i+8192-6615)&8191;float dl=delay_l[di],dr=delay_r[di];delay_l[delay_i]=sendd+dr*0.36f;delay_r[delay_i]=sendd+dl*0.31f;wet_l=dl*0.5f;wet_r=dr*0.5f;delay_i=(delay_i+1)&8191;}
  {uint32_t a=comb_i%1499,b=comb_i%1877;float ra=comb_a[a],rb=comb_b[b];comb_a[a]=sendr+ra*0.69f;comb_b[b]=sendr+rb*0.72f;wet_l+=ra*0.24f;wet_r+=rb*0.24f;l+=wet_l;r+=wet_r;comb_i++;}
  if(countin_left){if(countin_left%countin_beat==0){click_left=1100;click_phase=0;click_hz=countin_left/countin_beat%4==0?1800.0f:1200.0f;}if(--countin_left==0){z_transport(1);z_record(1);}}
  if(click_left){float c=sine(click_phase)*0.13f*click_left/1100.0f;click_phase+=click_hz/44100.0f;l+=c;r+=c;click_left--;}
  live_phase+=z_song.bpm/2646000.0f*(1u<<z_song.fx_rate);if(live_phase>=1)live_phase-=1;
  live_blend+=((live_requested?1.0f:0.0f)-live_blend)*0.008f;
  if(live_effect){float dry_l=l,dry_r=r,a=z_song.fx_amount/127.0f,x=(l+r)*0.5f;
   switch(live_effect){
    case 1:l*=1-a;r*=1-a;break;
    case 2:l*=live_phase<0.5f?1:1-a;r*=live_phase<0.5f?1:1-a;break;
    case 3:l*=1-a*(0.5f+0.5f*sine(live_phase));r*=1-a*(0.5f+0.5f*sine(live_phase));break;
    case 4:l=(int)(l*(8+120*(1-a)))/(8+120*(1-a));r=(int)(r*(8+120*(1-a)))/(8+120*(1-a));break;
    case 5:l=sat(l*(1+a*12));r=sat(r*(1+a*12));break;
    case 6:l+=(x-l)*a;r+=(x-r)*a;break;
    case 7:{float q=l;l=r;r=q;break;}
    case 8:l*=1-a*(1-live_phase);r*=1-a*(1-live_phase);break;
    case 9:l*=sine(live_phase*64);r*=sine(live_phase*64);break;
    case 10:l*=1+a;r*=1+a;break;
    case 11:l*=1-a;r*=1+a*0.3f;break;
    case 12:r*=1-a;l*=1+a*0.3f;break;
    case 13:l*=live_phase<0.25f?1:1-a;r*=live_phase<0.25f?1:1-a;break;
    case 14:l=sat(l*(1+a*30));r=sat(r*(1+a*30));break;
    case 15:l*=1-a*0.8f;r=-r*(1-a*0.8f);break;
    case 16:l=0;r=0;break;
   }
   l=dry_l+(l-dry_l)*live_blend;r=dry_r+(r-dry_r)*live_blend;
   if(!live_requested&&live_blend<0.0001f){live_effect=0;live_blend=0;}
  }
  {float yl=l-dc_xl+0.99715f*dc_yl,yr=r-dc_xr+0.99715f*dc_yr;dc_xl=l;dc_xr=r;dc_yl=yl;dc_yr=yr;
   /* Bus limiter: instant gain reduction above 0.9, ~120 ms recovery. Dense chords and drums duck instead of clipping. */
   {float a=absf(yl)>absf(yr)?absf(yl):absf(yr),want=a*bus_gain>0.9f?0.9f/a:1;if(want<bus_gain)bus_gain=want;else bus_gain+=(want-bus_gain)*0.0002f;yl*=bus_gain;yr*=bus_gain;}
   out[2*frame]=clampf(yl,-0.98f,0.98f);out[2*frame+1]=clampf(yr,-0.98f,0.98f);}
 }
}
uint32_t z_position(void){return pos;}
uint32_t z_playing(void){return playing;}
uint32_t z_voice_count(void){uint32_t i,n=0;for(i=0;i<8;i++)n+=voices[i].active;if(!Z_SAMPLER_EDITION)for(i=0;i<16;i++)n+=dm_voice[i].active;return n;}
float *z_buffer(void){return render_buffer;}
uint8_t *z_transfer(void){return transfer;}
uint32_t z_snapshot(void){return (uint32_t)(uintptr_t)&z_song;}
#ifdef Z_WASM
void z_preview_sample(uint32_t slot,uint32_t length,uint32_t rate){uint32_t i;if(slot>=4||length>Z_PCM_MAX)return;for(i=0;i<length;i++)preview_pcm[slot][i]=(int16_t)(transfer[2*i]|transfer[2*i+1]<<8);z_sample(6+slot,preview_pcm[slot],length,rate);}
#endif

/* Finish held captures before erasing so a later key-up cannot restore deleted data. */
int z_erase(uint32_t t,uint32_t at,uint32_t scope){
 if(t>=6||at>=64||scope>2)return -1;
 z_record(0);z_alloff(t);
 if(z_drum_track(t))return z_dm_erase(at,scope);
 uint32_t first=scope?0:at,last=scope?64:at+1,changed=0;for(uint32_t i=first;i<last;i++){z_step *s=&z_song.track[t].steps[i];if(s->note!=60||s->velocity||s->chance!=127||s->gate!=z_get(t,Z_GATE)||z_song.duration[t][i])changed=1;for(uint32_t j=0;j<3;j++)if(z_song.chord[t][i][j])changed=1;}if(!changed)return 0;z_checkpoint();
 for(uint32_t i=first;i<last;i++){z_song.track[t].steps[i]=(z_step){60,0,127,(uint8_t)z_get(t,Z_GATE)};z_song.duration[t][i]=0;for(uint32_t j=0;j<3;j++)z_song.chord[t][i][j]=0;}
 z_touch();return 0;
}

uint32_t z_track_hits(uint32_t t){uint32_t n=0;if(t>=6)return 0;if(z_drum_track(t)){for(uint32_t d=0;d<16;d++)for(uint32_t at=0;at<64;at++)n+=z_dm.step[d][at].velocity!=0;}else for(uint32_t at=0;at<64;at++)n+=z_song.track[t].steps[at].velocity!=0;return n;}

void z_new_project(void){uint32_t previous=revision,language=z_song.language;z_transport(0);z_init();z_song.language=(uint8_t)language;revision=previous;z_touch();} /* a new project keeps the player's language */

/* Display-only query of sounding attacks/gates; release tails do not latch LEDs. */
uint32_t z_note_lights(uint32_t t,int32_t base){
 static const uint8_t white[16]={0,2,4,6,7,9,11,12,14,16,18,19,21,23,24,26};uint32_t mask=0;
 if(t>=6||z_get(t,Z_MUTE)||(solo_track&&solo_track!=t+1))return 0;
 if(z_drum_track(t)){for(uint32_t d=0;d<16;d++)if(dm_voice[d].active&&dm_voice[d].env>.08f&&!z_dm.sound[d].mute)mask|=1u<<white[d];return mask;}
 for(uint32_t i=0;i<8;i++)if(voices[i].active&&voices[i].track==t&&voices[i].stage<3&&voices[i].env>.001f){int n=voices[i].note+z_get(t,Z_TRANSPOSE);if(n<0)n=0;if(n>127)n=127;while(n<base)n+=12;while(n>base+26)n-=12;if(n>=base&&n<=base+26)mask|=1u<<(n-base);}
 return mask;
}
/* A grid key previews its event with bounded gates; it never enters a take. */
void z_audition_step(uint32_t t,uint32_t at){
 if(t>=6||at>=64||z_get(t,Z_MUTE)||(solo_track&&solo_track!=t+1))return;
 if(z_drum_track(t)){uint32_t d=z_dm.selected;if(z_dm.step[d][at].velocity)dm_seqhit(d,z_dm.step[d][at].velocity);return;}
 z_step *s=&z_song.track[t].steps[at];if(!s->velocity)return;
 for(uint32_t j=0;j<4;j++){uint32_t n=j?z_song.chord[t][at][j-1]:s->note+1;if(!n)continue;n--;z_note(t,n,s->velocity,1);for(uint32_t i=0;i<8;i++)if(voices[i].active&&voices[i].track==t&&voices[i].stamp==stamp)voices[i].gate=4410;if(midi_out)midi_out(t,n,s->velocity,100);}
}
#ifdef PLAT_HOST
#include <stdio.h>
/* Host-only diagnostics for tests/fuzz_panel.py. A held voice has not reached its release stage. */
/* Every DSP state variable finite: a NaN in a filter or the reverb would silence the output for good. */
static int fin(float x){return x==x&&x<1e30f&&x>-1e30f;}
uint32_t z_dsp_finite(void){uint32_t i;for(i=0;i<Z_VOICES;i++){voice *v=&voices[i];if(v->active&&!(fin(v->env)&&fin(v->lp1)&&fin(v->lp2)&&fin(v->phase)&&fin(v->phase2)&&fin(v->pos)&&fin(v->inc)))return 0;}
 if(!Z_SAMPLER_EDITION)for(i=0;i<16;i++){voice *v=&dm_voice[i];if(v->active&&!(fin(v->env)&&fin(v->lp1)&&fin(v->lp2)&&fin(v->phase)))return 0;}
 for(i=0;i<8192;i++)if(!fin(delay_l[i])||!fin(delay_r[i]))return 0;for(i=0;i<1499;i++)if(!fin(comb_a[i]))return 0;for(i=0;i<1877;i++)if(!fin(comb_b[i]))return 0;
 return fin(dc_yl)&&fin(dc_yr)&&fin(bus_gain)&&fin(declick_l)&&fin(declick_r)&&fin(live_blend);}
uint32_t z_held_voices(void){uint32_t n=0;for(uint32_t i=0;i<Z_VOICES;i++)n+=voices[i].active&&voices[i].stage<3;return n;}
void z_debug_voices(void){for(uint32_t i=0;i<Z_VOICES;i++)if(voices[i].active)printf("voice %u track %u note %u stage %u released %u arp %u gate %u env %.4f pad %u sustain %u\n",i,voices[i].track,voices[i].note,voices[i].stage,voices[i].released,voices[i].arp,voices[i].gate,voices[i].env,voices[i].pad,sustain[voices[i].track]);
 if(!Z_SAMPLER_EDITION)for(uint32_t d=0;d<16;d++)if(dm_voice[d].active)printf("drum %u env %.4f\n",d,dm_voice[d].env);
 for(uint32_t t=0;t<6;t++)printf("track %u arp_mode %u hold %u arp_count %u playing %u\n",t,z_song.arp_mode[t],z_song.arp_hold[t],arp_count[t],playing);}
#endif
