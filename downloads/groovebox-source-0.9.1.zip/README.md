# Zombie FM-1 · Groovebox / Sampler 0.8.0

Groovebox 0.8.3 fixes the SAVE LED staying lit after K2 edits. Unsaved edits
use an on-screen `*`; SAVE still saves and pulses when pressed. Controls,
project format and DAW profiles remain compatible with 0.8.2. Sampler stays
0.8.0. [Release notes](downloads/Groovebox-0.8.3-RU.md).
The installer also checks the running application's status after its USB identity
returns, so an identity-only safe-mode response cannot report installation success.

Site / installer: https://joolo09.github.io/zombie-fm1-web/

Two dedicated firmware packages. Groovebox: six synthesis tracks, 64 original
presets, native/web four-note piano roll and starter groove. Sampler: 32 pads,
four user PCM slots, chopping, reverse, choke groups and one-shot/gate/loop.
Both boot Standalone with local sound; HOME + SEL cycles Standalone → DAW Synth
→ DAW Controller for the current session. Never automatically flashes a device.

Original 240x240 RGB565 device UI: track colors, output meter, page transitions,
fading pad hits, moving sequencer playhead. English and Russian labels.
Displayed previews are from the host simulator, not physical hardware photos.

Find FM-1, then Install in Chrome/Edge with MIDI SysEx. Back up projects/WAVs
and close the DAW / other MIDI tabs first. Firmware updates are validated with
size, SHA-256 and package identity; success requires the restarted identity.

Dedicated FL Studio and Ableton Live 11/12 Python 3 profiles are in
source/profiles/ and downloads/Zombie-FM1-DAW-Profiles-0.8.0.zip. Read the included
RU/EN guide for installation, pad note maps and manual MIDI Learn in FL.

Both firmware binaries compile; host, actual WASM audio and stub DAW API tests
pass. Physical FM-1 flashing/display and actual FL/Live sessions are not verified
by the developer. Older 0.7.4 / 0.7.1 downloads remain available.

Editable new firmware source: source/editions/. Complete matching platform,
generators/assets and profiles: downloads/editions-source-0.8.0.zip.
Application/DSP/UI/profiles: MIT. Hardware/boot/update platform: MPL-2.0.
Minecraft audio in Sampler: Mojang/Microsoft, provenance in source archive.
GitHub Pages: main, / (root), HTTPS. Paths support a repository subdirectory.


Groovebox 0.8.1: five synth tracks + synthesized GM drum kit on track six.
Native/web drum grid, 16 sounds, hat choke. Successful OTA now uses a full
P33 chip reset. Hardware confirmation pending. Details: downloads/Groovebox-0.8.1-RU.md.
Source: downloads/groovebox-source-0.8.1.zip. Sampler remains 0.8.0.


Groovebox 0.8.2: SELECT always BPM, remembered pages, 180ms holds, HOME layer
lock, SEQ bank shortcuts and additive kit step toggles. Original Zombie FM-1
240x240 splash restored. New matching DAW profiles map relative tempo CC116.
Details: downloads/Groovebox-0.8.2-RU.md. Physical hardware unverified.
Source: downloads/groovebox-source-0.8.2.zip. Sampler stays 0.8.0.


## Groovebox 0.9.0 beta: nested Hortator drums

Track 6 contains eight Hortator drum lanes with its actual DSP, native UI,
sequencer, modulation, effects, motion and song functions. Tracks 1–5 keep their
existing synth audio and panel. Physical selection: ALGO for the outer track,
SEL + PRESET for the inner drum. Experimental editor: `webapp/groovebox-090/`.

This beta has simulator/WASM/protocol checks; physical FM-1 timing, controls,
storage and updates remain unverified. 0.8.3 remains the default.
[Russian release notes](downloads/Groovebox-0.9.0-RU.md) ·
[features, adaptations, source/licensing and tests](source/drum-suite/README.md).
The combined 0.9.0 firmware/WASM is GPL-3.0-only; standalone original Zombie
source retains its MIT notices. The complete matching source archive is
`downloads/groovebox-source-0.9.0.zip`.

Groovebox 0.9.1 beta: [audit fixes and verification](source/AUDIT-091.md),
[Russian release notes](downloads/Groovebox-0.9.1-RU.md). Default remains 0.8.3.
