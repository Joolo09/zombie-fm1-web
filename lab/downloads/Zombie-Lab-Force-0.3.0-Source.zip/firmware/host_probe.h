/* SPDX-License-Identifier: MIT — original bounded USB0 descriptor probe.
 * Register meanings checked against the public AC79 SDK usb_phy.h/usb.h.
 * No class driver, SET_CONFIGURATION, filesystem or storage commands. */
#pragma once
#include <stdint.h>
enum {HP_IDLE,HP_WARM,HP_ATTACH,HP_RESET,HP_SETTLE,HP_SETUP,HP_DATA,HP_STATUS,HP_DONE};
enum {HP_NONE,HP_OK,HP_CANCEL,HP_SIE,HP_NOHOST,HP_NOATTACH,HP_TIMEOUT,HP_STALL,HP_BUS,HP_COUNT,HP_DESCRIPTOR};
typedef struct {
 int (*begin)(void *); int (*rd)(void *,uint32_t,uint32_t *);
 int (*wr)(void *,uint32_t,uint32_t); int (*send)(void *,const uint8_t *,uint32_t);
 int (*take)(void *,uint8_t *,uint32_t); void (*end)(void *);
 uint32_t (*lines)(void *); void *ctx;
} hp_io;
typedef struct {
 uint32_t state,result,attempts,started,changed,elapsed,devctl,power,csr,lines;
 uint32_t packets,received,host_seen,reset_attempted,attach_since,attach_valid,last_state,forced_speed;
 uint8_t descriptor[18]; hp_io io;
} host_probe;
static int hp_active(const host_probe *p){return p->state>HP_IDLE&&p->state<HP_DONE;}
static void hp_finish(host_probe *p,uint32_t result,uint32_t now){
 p->result=result;p->elapsed=now-p->started;p->last_state=p->state;p->state=HP_DONE;p->io.end(p->io.ctx);
}
static int hp_rd(host_probe *p,uint32_t r,uint32_t *v,uint32_t now){
 if(p->io.rd(p->io.ctx,r,v))return 1;hp_finish(p,HP_SIE,now);return 0;
}
static int hp_wr(host_probe *p,uint32_t r,uint32_t v,uint32_t now){
 if(p->io.wr(p->io.ctx,r,v))return 1;hp_finish(p,HP_SIE,now);return 0;
}
static void hp_stage(host_probe *p,uint32_t s,uint32_t now){p->state=s;p->changed=now;}
static int hp_start(host_probe *p,hp_io io,uint32_t now){uint32_t i,n=p->attempts+1;
 if(hp_active(p))return 0;
 p->io=io;p->state=HP_WARM;p->result=0;p->attempts=n;p->started=p->changed=now;
 p->elapsed=p->devctl=p->power=p->csr=p->lines=p->packets=p->received=0;
 p->host_seen=p->reset_attempted=p->attach_valid=p->attach_since=p->last_state=0;
 for(i=0;i<18;i++)p->descriptor[i]=0;
 if(!io.begin(io.ctx)){hp_finish(p,HP_SIE,now);return 0;}return 1;
}
static int hp_descriptor_ok(const uint8_t *d){
 return d[0]==18&&d[1]==1&&(d[7]==8||d[7]==16||d[7]==32||d[7]==64)&&
   (d[8]||d[9])&&!(d[8]==255&&d[9]==255)&&d[17]>0;
}
static void hp_tick(host_probe *p,uint32_t now){uint32_t count,i;
 static const uint8_t setup[8]={128,6,0,1,0,0,18,0};
 if(!hp_active(p))return;p->elapsed=now-p->started;
 if(p->elapsed>15000u){hp_finish(p,HP_TIMEOUT,now);return;}
 if(p->state==HP_WARM){
  if(now-p->changed<5)return;
  if(!hp_wr(p,1,0x60,now)||!hp_wr(p,11,0,now)||!hp_wr(p,7,0,now)||!hp_wr(p,9,0,now)||!hp_wr(p,15,3,now))return;
  hp_stage(p,HP_ATTACH,now);return;
 }
 p->lines=p->io.lines(p->io.ctx);
 if(!hp_rd(p,15,&p->devctl,now)||!hp_rd(p,1,&p->power,now))return;
 if(p->devctl&4)p->host_seen=1;
 if(p->state==HP_ATTACH){
  /* Experimental: skip attachment/speed detection, select the requested
   * signaling speed and issue reset anyway. HOSTMODE itself is still required. */
  if(now-p->changed<150)return;
  if(!(p->devctl&4)){hp_finish(p,HP_NOHOST,now);return;}
  if(!hp_wr(p,0x100,p->forced_speed,now)||!hp_wr(p,1,p->power|8,now))return;
  p->reset_attempted=1;hp_stage(p,HP_RESET,now);
  return;
 }
 if(!(p->devctl&4)){hp_finish(p,HP_NOHOST,now);return;}
 if(p->state==HP_RESET){if(now-p->changed<30)return;
  if(!hp_wr(p,1,p->power&~8u,now))return;hp_stage(p,HP_SETTLE,now);return;
 }
 if(p->state==HP_SETTLE){if(now-p->changed<100)return;
  if(!hp_wr(p,0,0,now)||!hp_wr(p,14,0,now)||!hp_wr(p,17,0,now))return;
  if(!p->io.send(p->io.ctx,setup,8)){hp_finish(p,HP_SIE,now);return;}
  if(!hp_wr(p,17,0x0a,now))return;hp_stage(p,HP_SETUP,now);return;
 }
 if(now-p->changed>750u){hp_finish(p,HP_TIMEOUT,now);return;}
 if(!hp_rd(p,17,&p->csr,now))return;
 if(p->csr&4){hp_finish(p,HP_STALL,now);return;}
 if(p->csr&0x10){hp_finish(p,HP_BUS,now);return;}
 if(p->state==HP_SETUP){if(p->csr&2)return;
  if(!hp_wr(p,17,0x20,now))return;hp_stage(p,HP_DATA,now);return;
 }
 if(p->state==HP_DATA){if(!(p->csr&1))return;
  if(!hp_rd(p,22,&count,now))return;
  if(!count||count>18u-p->received||count>64){hp_finish(p,HP_COUNT,now);return;}
  if(!p->io.take(p->io.ctx,p->descriptor+p->received,count)){hp_finish(p,HP_SIE,now);return;}
  p->received+=count;p->packets++;
  if(!hp_wr(p,17,0,now))return;
  if(p->received<18){
   /* An initial EP0 packet must expose bMaxPacketSize0 before another IN. */
   i=p->received>=8?p->descriptor[7]:0;
   if(!(i==8||i==16||i==32||i==64)||count<i){hp_finish(p,HP_DESCRIPTOR,now);return;}
   if(!hp_wr(p,17,0x20,now))return;p->changed=now;return;
  }
  if(!p->io.send(p->io.ctx,setup,0)||!hp_wr(p,17,0x42,now)){if(hp_active(p))hp_finish(p,HP_SIE,now);return;}
  hp_stage(p,HP_STATUS,now);return;
 }
 if(p->state==HP_STATUS&&!(p->csr&2))hp_finish(p,hp_descriptor_ok(p->descriptor)?HP_OK:HP_DESCRIPTOR,now);
}
