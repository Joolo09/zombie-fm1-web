/* SPDX-License-Identifier: MIT */
#pragma once
#include <stdint.h>
#include "plat.h"
#define APP_NAME "ZOMBIE LAB"
#define APP_BLOCK 256u
/* Diagnostic firmware may only stage an explicitly requested normal firmware update.
 * All project, PCM, calibration, SYS, and pad-map regions reject erase/program. */
#define FL_RANGE_OK(off,n) ((uint32_t)(off)>=0xE0000u && (uint32_t)(off)<=0xE5000u && (uint32_t)(n)<=0xE5000u-(uint32_t)(off))
enum {OBJ_SETTINGS,OBJ_PANEL,OBJ_BLE,OBJ_SYSTEM,OBJ_SAMPLER,OBJ_NOBJ};
#define APP_STORE_MAP {0xD8000u,0xDC000u,0xDE000u,0xDA000u,0xD0000u}
#define APP_SYSEX
void app_init(void);
void app_render(int32_t *,uint32_t,uint32_t);
void app_panic(void);
void app_ui_init(void);
void app_frame(void);
void app_input_only(void);
void app_say(const char *,const char *);
int app_sysex(const uint8_t *,uint32_t);
#ifdef PLAT_HOST
#define APP_HOST_CMD
#define APP_HOST_EXPECT
int app_host_cmd(const char *,const char *,const char *,const char *,const char *);
int app_expect(const char *,int *);
#endif
