"""Publish files for the untested forced-host experiment, without running tests."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,shutil
H=Path(__file__).resolve().parent;R=H.parents[1];S=R/'zombie-fix/github-pages/lab';O=H/'output'
def augment():
 info=json.loads((O/'BUILD-INFO.json').read_text());fw=O/'zombie-lab-force-0.3.0.fwsc'
 assert hashlib.sha256(fw.read_bytes()).hexdigest()==info['sha256']
 source=O/'Zombie-Lab-Force-0.3.0-Source.zip'
 with ZipFile(source,'w',ZIP_DEFLATED,compresslevel=9) as z:
  for folder in ['firmware','platform','web']:
   for p in (H/folder).rglob('*'):
    if p.is_file() and not set(p.relative_to(H).parts)&{'build','__pycache__','.git'}:z.write(p,p.relative_to(H).as_posix())
  for name in ['README-RU.md','RESEARCH.md','build.py','build-web.py']:z.write(H/name,name)
  z.write(R/'zombie-lab/LICENSE','LICENSE')
 for p in [fw,source]:shutil.copy2(p,S/'downloads'/p.name)
 shutil.copy2(H/'README-RU.md',S/'downloads/Zombie-Lab-Force-0.3.0-README-RU.md')
 shutil.copytree(H/'web',S/'force',dirs_exist_ok=True)
 p=S/'releases.json';m=json.loads(p.read_text(encoding='utf8'))
 item=dict(product=info['identity'],version='0.3.0',bytes=info['bytes'],sha256=info['sha256'],file='downloads/'+fw.name,editor='force/',label={'ru':'Zombie Force 0.3.0 · принудительный USB-host','en':'Zombie Force 0.3.0 · forced USB host'},notes={'ru':'НЕПРОВЕРЕННАЯ сборка без прогона тестов. Принудительный сброс и GET_DESCRIPTOR: Full Speed, затем Low Speed, без ожидания обнаружения. Отключи ПК, подключи периферию, нажми GLO и держи PLAY 2 секунды. Выходное питание 5 В не включается.','en':'UNTESTED build, test suites skipped. Forced reset and GET_DESCRIPTOR: full speed then low speed, without attach detection. Unplug PC, connect a peripheral, press GLO and hold PLAY for 2 seconds. No connector 5V power control.'})
 m['releases']=[item]+[x for x in m['releases'] if x['product']!=item['product']];m['current']=item['product'];p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 p=S/'installer.js';s=p.read_text(encoding='utf8');marker=" for(const option of $('release').options)";assert marker in s
 change=""" if(release?.product==='FM-1_62000300'){
  document.querySelector('[data-t=headline]').textContent=lang==='ru'?'Принудительный USB-host.':'Force USB host.';
  document.querySelector('[data-t=preview]').textContent=lang==='ru'?'НЕПРОВЕРЕННАЯ сборка: без прогона тестов. Full Speed → Low Speed. Режим не создаёт выходное питание 5 В.':'UNTESTED build; test suites skipped. Full speed → low speed. Does not create connector 5V power.';
  $('install-heading').textContent=lang==='ru'?'Установить Zombie Force 0.3.0':'Install Zombie Force 0.3.0';
  const forceSource=document.querySelector('a[data-t=source]');if(forceSource)forceSource.href='downloads/Zombie-Lab-Force-0.3.0-Source.zip';
 }
"""
 s=s.replace(marker,change+marker).replace('fm1ota.js?v=lab3','fm1ota.js?v=lab4');p.write_text(s,encoding='utf8')
 p=S/'index.html';s=p.read_text(encoding='utf8').replace('installer.js?v=lab3','installer.js?v=lab4').replace('TEST SITE 1.2 · FW 0.1 / 0.2','TEST SITE 1.3 · FW 0.1 / 0.2 / 0.3').replace('<a href="host/">USB-host ↗</a>','<a href="force/">USB Force ↗</a>');p.write_text(s,encoding='utf8')
 with (S/'README.md').open('a',encoding='utf8') as f:f.write('\n0.3.0 Force is an UNTESTED experiment, test suites skipped at user request.\nForced FS then LS reset/descriptor requests, no board VBUS power control.\nPrior releases are preserved. Results reader: force/.\n')
 print('Force 0.3.0 website files prepared. No tests executed.')
if __name__=='__main__':augment()
