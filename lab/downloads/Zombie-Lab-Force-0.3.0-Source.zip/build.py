"""Build experimental force-host firmware only; tests intentionally skipped."""
from pathlib import Path
import os,subprocess,sys,hashlib,json
H=Path(__file__).resolve().parent;R=H.parents[1];O=H/'output';O.mkdir(exist_ok=True)
env=dict(os.environ,PYTHONUTF8='1',JIELI_TOOLCHAIN=str(R/'.tooling/jieli-win/C$/JL/pi32'),AC79_SDK=str(R/'.tooling/ac79-sdk'),X0X_FONTSET='terminus',ZIG_GLOBAL_CACHE_DIR=str(R/'.tooling/zig-global'),ZIG_LOCAL_CACHE_DIR=str(R/'.tooling/zig-local'))
r=subprocess.run([sys.executable,'-X','utf8',str(H/'platform/tools/build.py'),str(H/'firmware'),'--release','0.3.0'],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(O/'device-build.log').write_bytes(r.stdout);print(r.stdout.decode('utf8',errors='replace')[-2600:])
if r.returncode:raise SystemExit(r.returncode)
fw=H/'firmware/build/zombie-lab-force-0.3.0.fwsc';p=O/fw.name;p.write_bytes(fw.read_bytes())
(O/'BUILD-INFO.json').write_text(json.dumps(dict(version='0.3.0',identity='FM-1_62000300',bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),tests_run=False,tests_skipped_at_user_request=True,hardware_tested=False,device_flashed=False,scope='Forced full-speed reset/GET_DESCRIPTOR, then low-speed fallback, without attach detection',vbus_power_control=False),indent=2))
print('Built WITHOUT test execution:',p)
