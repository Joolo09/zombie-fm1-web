/* SPDX-License-Identifier: MIT — original diagnostic USB0 adapter.
 * Source notes: host-probe/RESEARCH.md. Never controls a board power GPIO.
 * CON0.VBUS is a PHY input override, NOT evidence of external 5 V output. */
#pragma once
static uint8_t hp_dma[64] __attribute__((aligned(4)));
static int hp_hw_rd(void *ctx,uint32_t reg,uint32_t *out){uint32_t tries=20000;(void)ctx;
 if(!fm1_usb_sie_on())return 0;fm1_usb_sie_rd_start(reg);
 while(!fm1_usb_sie_done()&&--tries){}if(!tries)return 0;*out=fm1_usb_sie_data();return 1;
}
static int hp_hw_wr(void *ctx,uint32_t reg,uint32_t val){uint32_t tries=20000;(void)ctx;
 if(reg==0x100){if(val)FM1_USB_CON0|=2;else FM1_USB_CON0&=~2u;return 1;}
 if(!fm1_usb_sie_on())return 0;fm1_usb_sie_wr_start(reg,val);
 while(!fm1_usb_sie_done()&&--tries){}return tries!=0;
}
static int hp_hw_begin(void *ctx){uint32_t f=irq_save();(void)ctx;
 usb.up=0;usb.detached=1;usb.config=0;RING_PUBLISH();
 fm1_usb_off();FM1_CLK_CON1&=~3u;FM1_USB_CON1=0;
 FM1_USB_IO_CON0=(1u<<9)|(1u<<10)|(1u<<4)|(1u<<5);
 *(volatile uint32_t *)0x51004u=0; /* USB IO CON1: SDK usb_h_sie_init(USB0). */
 fm1_usb_ep0_buf(hp_dma);FM1_USB_CON0=0x25u; /* PHY, NRST, internal VBUS; CID=0. */
 irq_restore(f);return 1;
}
static int hp_hw_send(void *ctx,const uint8_t *p,uint32_t n){uint32_t i;(void)ctx;
 if(n>sizeof hp_dma)return 0;for(i=0;i<n;i++)hp_dma[i]=p[i];fm1_usb_ep0_send(hp_dma,n);return 1;
}
static int hp_hw_take(void *ctx,uint8_t *p,uint32_t n){uint32_t i;(void)ctx;
 if(n>sizeof hp_dma)return 0;fm1_usb_rx_sync();for(i=0;i<n;i++)p[i]=hp_dma[i];return 1;
}
static void hp_hw_end(void *ctx){uint32_t f=irq_save();(void)ctx;
 fm1_usb_off();usb.up=0;usb.config=0;usb.suspended=1;usb.detached=0;
 RING_PUBLISH();irq_restore(f); /* main-loop usb_retry restores normal device mode. */
}
static uint32_t hp_hw_lines(void *ctx){(void)ctx;return (FM1_USB_CON0>>16)&3u;}
