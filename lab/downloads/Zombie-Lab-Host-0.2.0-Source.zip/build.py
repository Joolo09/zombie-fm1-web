"""Isolated 0.2.0 firmware build. Never rebuilds Lab 0.1 or flashes hardware."""
from pathlib import Path
import os,subprocess,sys,hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OUT=HERE/'output'
env=dict(os.environ,PYTHONUTF8='1',JIELI_TOOLCHAIN=str(ROOT/'.tooling/jieli-win/C$/JL/pi32'),AC79_SDK=str(ROOT/'.tooling/ac79-sdk'),X0X_FONTSET='terminus',ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.tooling/zig-global'),ZIG_LOCAL_CACHE_DIR=str(ROOT/'.tooling/zig-local'))
OUT.mkdir(exist_ok=True)
(OUT/'ui').mkdir(exist_ok=True)
def run(args,name):
 r=subprocess.run([str(x) for x in args],env=env,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (OUT/name).write_bytes(r.stdout)
 print(r.stdout.decode('utf8',errors='replace')[-4500:])
 if r.returncode:raise SystemExit(r.returncode)
zig=ROOT/'.tooling/zig-windows-x86_64-0.13.0/zig.exe'
run([zig,'cc','-std=c99','-O2','-Wall','-Wextra','-Werror',HERE/'tests/probe_test.c','-o',OUT/'probe-tests.exe'],'probe-compile.log')
run([OUT/'probe-tests.exe'],'probe-tests.log')
run(['node',HERE/'tests/protocol.mjs'],'protocol-tests.log')
env['CC']=str(ROOT/'tools/host-cc.cmd')
run([sys.executable,'-X','utf8',HERE/'platform/tools/build.py',HERE/'firmware','--host'],'ui-build.log')
run([HERE/'firmware/build/host/zombie-lab-host_host',HERE/'tests/ui.ctl',OUT/'ui'],'ui-tests.log')
assert (OUT/'ui/Host-Probe-Instructions.png').is_file()
assert (OUT/'ui/Host-Probe-Simulator.png').is_file()
run([sys.executable,'-X','utf8',HERE/'platform/tools/build.py',HERE/'firmware','--release','0.2.0'],'device-build.log')
fw=HERE/'firmware/build/zombie-lab-host-0.2.0.fwsc'
target=OUT/fw.name;target.write_bytes(fw.read_bytes())
(OUT/'BUILD-INFO.json').write_text(json.dumps(dict(version='0.2.0',identity='FM-1_62000200',sha256=hashlib.sha256(target.read_bytes()).hexdigest(),bytes=target.stat().st_size,hardware_tested=False,device_flashed=False,usb_host_scope='USB0 address-zero GET_DESCRIPTOR only; no class/storage I/O',vbus_output='external measurement required; no GPIO power switching'),indent=2))
print('Ready:',target)
