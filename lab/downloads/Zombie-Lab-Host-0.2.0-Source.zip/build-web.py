"""Add the isolated host-probe release to the separate Lab website only."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,shutil
H=Path(__file__).resolve().parent;R=H.parents[1];S=R/'zombie-fix/github-pages/lab';O=H/'output'
def augment():
 info=json.loads((O/'BUILD-INFO.json').read_text());fw=O/'zombie-lab-host-0.2.0.fwsc'
 assert hashlib.sha256(fw.read_bytes()).hexdigest()==info['sha256']
 source=O/'Zombie-Lab-Host-0.2.0-Source.zip'
 with ZipFile(source,'w',ZIP_DEFLATED,compresslevel=9) as z:
  for folder in ['firmware','platform','web','tests']:
   for p in (H/folder).rglob('*'):
    if p.is_file() and not set(p.relative_to(H).parts)&{'build','__pycache__','.git'}:z.write(p,p.relative_to(H).as_posix())
  for name in ['README-RU.md','RESEARCH.md','build.py','build-web.py']:z.write(H/name,name)
  z.write(R/'zombie-lab/LICENSE','LICENSE')
 with ZipFile(source) as z:assert z.testzip() is None
 for p in [fw,source]:shutil.copy2(p,S/'downloads'/p.name)
 shutil.copy2(H/'README-RU.md',S/'downloads/Zombie-Lab-Host-0.2.0-README-RU.md')
 shutil.copytree(H/'web',S/'host',dirs_exist_ok=True)
 p=S/'releases.json';manifest=json.loads(p.read_text(encoding='utf8'))
 item=dict(product=info['identity'],version='0.2.0',bytes=info['bytes'],sha256=info['sha256'],file='downloads/'+fw.name,editor='host/',label={'ru':'Zombie Lab Host 0.2.0 · тест USB-host','en':'Zombie Lab Host 0.2.0 · USB host probe'},notes={'ru':'Экспериментальная проба USB0: только GET_DESCRIPTOR. После установки отключи ПК, подключи USB-мышь через переходник, нажми GLO и удерживай PLAY 2 секунды. Питание 5 В не измеряется; диски не монтируются. Физическая проверка этой версии ещё не проведена.','en':'Experimental USB0 GET_DESCRIPTOR probe. Unplug the PC, connect a USB mouse using an adapter, press GLO and hold PLAY for 2 seconds. No VBUS voltage measurement or disk support. Not yet tested on physical FM-1.'})
 manifest['releases']=[item]+[x for x in manifest['releases'] if x['product']!=item['product']];manifest['current']=item['product']
 p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 p=S/'installer.js';s=p.read_text(encoding='utf8')
 s=s.replace("release.product!=='FM-1_62000100'","release.product==='FM-1_63000802'").replace("release.product==='FM-1_62000100'","release.product.startsWith('FM-1_62')")
 marker=" for(const option of $('release').options)"
 assert marker in s
 change=""" if(release?.product==='FM-1_62000200'){
  document.querySelector('[data-t=headline]').textContent=lang==='ru'?'Проверяем USB-host.':'Probe USB host.';
  document.querySelector('[data-t=preview]').textContent=lang==='ru'?'Отдельная экспериментальная прошивка: USB-дескриптор, без файловых операций. Без тестера напряжение остаётся неизвестным.':'A separate experimental firmware: USB descriptor only, no file operations. Without a meter the connector voltage remains unknown.';
  $('install-heading').textContent=lang==='ru'?'Установить Lab Host 0.2.0':'Install Lab Host 0.2.0';
 }
 const sourceLink=document.querySelector('a[data-t=source]');if(sourceLink)sourceLink.href=release?.product==='FM-1_62000200'?'downloads/Zombie-Lab-Host-0.2.0-Source.zip':'downloads/Zombie-Lab-Source.zip';
"""
 s=s.replace(marker,change+marker).replace('fm1ota.js?v=lab2','fm1ota.js?v=lab3');p.write_text(s,encoding='utf8')
 p=S/'index.html';s=p.read_text(encoding='utf8').replace('installer.js?v=lab2','installer.js?v=lab3').replace('TEST SITE 1.1 · FW 0.1.0','TEST SITE 1.2 · FW 0.1 / 0.2').replace('EXPERIMENTAL / 0.1.0','EXPERIMENTAL / USB LAB')
 s=s.replace('<a href="diagnostics/">Диагностика ↗</a>','<a href="host/">USB-host ↗</a>')
 s=s.replace('Открой диагностику, выбери MIDI-порты Zombie Lab, запусти тесты и скачай JSON. Проверка на реальном FM-1 разработчиком ещё не проводилась.','Для USB-host следуй инструкции на странице отчёта: тест запускается кнопками FM-1 после отключения ПК. Затем подключись снова без перезагрузки и скачай JSON. Это экспериментальная версия.')
 s=s.replace('<a href="diagnostics/">Перейти к USB-диагностике →</a>','<a data-release-editor href="host/">Открыть диагностику →</a>')
 p.write_text(s,encoding='utf8')
 with (S/'README.md').open('a',encoding='utf8') as f:f.write('\nLab Host 0.2.0 is a separate experimental USB0 GET_DESCRIPTOR-only probe.\nIts reader is host/. Default release is 0.2.0; frozen 0.1.0 remains selectable.\nNo disk/file operations, no VBUS voltage measurement. Physical hardware untested.\n')
 print('Added Lab Host 0.2.0 to isolated /lab/; frozen 0.1.0 artifacts retained')
if __name__=='__main__':augment()
