# USB0 host probe: evidence and limits

Primary sources: JieLi AC79 SDK release/AC79NN_SDK_V1.2.0 at
https://gitee.com/Jieli-Tech/fw-AC79_AIoT_SDK . SDK documentation:
https://doc.zh-jieli.com/AC79/zh-cn/release_v1.2.0/module_example/peripherals/usb.html
describes HID and mass-storage host examples. This establishes chip-family
support, not FM-1 board VBUS source capability.

Register/API references: include_lib/driver/cpu/wl82/asm/usb.h,
include_lib/driver/cpu/wl82/asm/WL82.h,
include_lib/driver/device/usb/usb_phy.h, apps/common/usb/usb_host_config.c,
apps/common/usb/host/usb_ctrl_transfer.c and usb_host.c. Low-level initialization
was checked against LLVM IR in cpu/wl82/liba/cpu.a, members usb.c.o and
usb_phy.c.o, using the existing JieLi tools. No vendor library is linked into
this probe. References downloaded for local research are outside the deliverable.

USB0 usb_h_sie_init clears USB IO CON0/CON1, enables input digital receivers,
disables pullups, enables both pulldowns, leaves peripheral IO mode, and enables
CON0 bits 0/2/5 with CID clear. usb_h_chirp_and_reset requests DEVCTL=3,
checks HOSTMODE bit 2 and FSDEV/LSDEV bits 6/5, selects LOW_SPEED bit 1 for LS,
sets POWER.RESET bit 3, delays, then clears RESET. EP0 control SETUP uses 0x0A,
IN request 0x20, and zero-length OUT status 0x42. USB0 uses the existing DMA
endpoint buffer accessors; no high-speed USB1 registers are touched.

The independently written state machine bounds all waits. It reads only the
18-byte device descriptor at address zero. It does not SET_ADDRESS,
SET_CONFIGURATION, read HID reports, send SCSI/BOT commands or mount a filesystem.
Only receiving a valid descriptor, in observed host mode after reset and the
status stage, can produce HP_OK. This proves a control exchange, not full
enumeration, disk support, current capacity or host stability under load.

The CON0 VBUS override and DEVCTL status are not a measurement of connector
voltage. No board power-control GPIO or USB-C CC configuration is known or
changed. No USB bus 5 V sourcing is claimed. Without a meter, a negative result
remains inconclusive. Physical testing is required. Firmware boots in USB device
mode and requires GLO then a 2-second PLAY hold to attempt the probe. Active PC
traffic blocks starting; the user must physically disconnect the PC. Completion,
timeout or HOME cancellation releases the controller for normal USB device retry.
Results are RAM-only and disappear on reset; reconnect without reboot to export.
