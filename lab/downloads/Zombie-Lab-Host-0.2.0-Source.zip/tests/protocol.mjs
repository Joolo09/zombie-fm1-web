/* SPDX-License-Identifier: MIT — no real MIDI access. */
import assert from 'node:assert/strict';
import {HostLink,decode,pack7,unpack7} from '../web/protocol.js';
const bytes=Uint8Array.from({length:256},(_,i)=>i);assert.deepEqual(unpack7(pack7(bytes)),bytes);
const make=()=>{const b=new Uint8Array(128),v=new DataView(b.buffer);const fields=[0x48505242,1,0,1,8,1,500,0x44,0x60,0,2,3,18,0x1209,1,8,1,1,0,0,7];fields.forEach((n,i)=>v.setUint32(i*4,n,true));b.set([18,1,0,2,0,0,0,8,9,18,1,0,0,1,0,0,0,1],96);return b;};
assert.equal(decode(make()).descriptorReadOnHardware,true);
for(const index of [3,4,11,12,13,14,15,16,17]){const b=make();new DataView(b.buffer).setUint32(index*4,0,true);assert.throws(()=>decode(b));}
const invalid=make();invalid[97]=3;assert.throws(()=>decode(invalid));assert.throws(()=>decode(new Uint8Array(127)));
const simulated=make();new DataView(simulated.buffer).setUint32(8,1,true);assert.equal(decode(simulated).descriptorReadOnHardware,false);
function ports(identity='ZLAB/1/0.2.0'){
 const sent=[];let closed=0;
 const input={open:async()=>{},close:async()=>{closed++;},onmidimessage:null};
 const output={open:async()=>{},close:async()=>{closed++;},send:p=>{sent.push(p[5]);const data=p[5]===1?new TextEncoder().encode(identity):make();queueMicrotask(()=>input.onmidimessage?.({data:[240,125,90,76,p[4],p[5]|64,...pack7([0,...data]),247]}));}};
 return {input,output,sent,closed:()=>closed};
}
const fake=ports(),link=new HostLink();assert.equal((await link.connect(fake.input,fake.output)).result,1);assert.deepEqual(fake.sent,[1,5]);
for(const n of [2,3,4,20,21,30,49,50,60,63])await assert.rejects(link.command(n));assert.deepEqual(fake.sent,[1,5]);link.close();assert.equal(fake.closed(),2);
const wrong=ports('ZLAB/1/0.1.0');await assert.rejects(new HostLink().connect(wrong.input,wrong.output));assert.deepEqual(wrong.sent,[1]);assert.equal(wrong.closed(),2);
console.log('PASS pack7; strict descriptor evidence; simulator label; only identity/report commands; wrong firmware cleanup');
