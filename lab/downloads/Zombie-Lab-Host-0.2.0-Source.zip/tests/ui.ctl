labtest
tap GLO
wait 100
expect lab_screen 3
shot Host-Probe-Instructions.png
press PLAY
wait 2200
release PLAY
wait 100
expect host_attempts 0
expect host_sim_blocked 2
shot Host-Probe-Simulator.png
