/* SPDX-License-Identifier: MIT — mock-controller tests, no USB hardware. */
#undef NDEBUG
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../firmware/host_probe.h"
typedef struct {uint32_t dev,power,csr,count,offset,ended,begin,requests,packet,mode;uint8_t desc[18];} fake;
enum {NORMAL,NO_HOST,NO_DEVICE,STALL,TIMEOUT,OVERSIZE,SIE_FAIL,SHORT,BAD_DESC};
static int begin(void *x){fake *f=x;f->begin++;return 1;}
static int rd(void *x,uint32_t r,uint32_t *v){fake *f=x;if(f->mode==SIE_FAIL)return 0;
 if(r==15)*v=f->mode==NO_HOST?0:f->mode==NO_DEVICE?4:f->dev;
 else if(r==1)*v=f->power;else if(r==17)*v=f->csr;else if(r==22)*v=f->count;else assert(0);return 1;
}
static int wr(void *x,uint32_t r,uint32_t v){fake *f=x;
 assert(r==1||r==11||r==7||r==9||r==15||r==0x100||r==0||r==14||r==17);
 if(r==1)f->power=v;
 if(r==17){f->csr=0;
  if(v==0x0a){if(f->mode==STALL)f->csr=4;else if(f->mode==TIMEOUT)f->csr=2;}
  else if(v==0x20){f->count=18-f->offset;if(f->count>f->packet)f->count=f->packet;
   if(f->mode==OVERSIZE)f->count=65;if(f->mode==SHORT)f->count=3;f->csr=1;}
 }
 return 1;
}
static int send(void *x,const uint8_t *p,uint32_t n){fake *f=x;
 static const uint8_t expected[]={128,6,0,1,0,0,18,0};
 assert(n==0||n==8);if(n){assert(!memcmp(p,expected,8));f->requests++;}return 1;
}
static int take(void *x,uint8_t *p,uint32_t n){fake *f=x;assert(f->offset+n<=18);memcpy(p,f->desc+f->offset,n);f->offset+=n;return 1;}
static void end(void *x){((fake *)x)->ended++;}
static uint32_t lines(void *x){(void)x;return 2;}
static fake fixture(uint32_t mode,uint32_t packet){fake f={0};static const uint8_t desc[]={18,1,0,2,0,0,0,8,9,18,1,0,0,1,0,0,0,1};
 f.dev=0x44;f.mode=mode;f.packet=packet;memcpy(f.desc,desc,18);f.desc[7]=packet;
 if(mode==BAD_DESC)f.desc[1]=3;return f;}
static host_probe run(fake *f){host_probe p={0};hp_io io={begin,rd,wr,send,take,end,lines,f};uint32_t now;
 assert(hp_start(&p,io,0));assert(!hp_start(&p,io,1));
 for(now=10;hp_active(&p)&&now<17000;now+=10)hp_tick(&p,now);
 assert(!hp_active(&p));assert(f->ended==1);assert(p.attempts==1);return p;
}
int main(void){uint32_t packet,i;host_probe p;fake f;
 for(packet=8;packet<=64;packet*=2){f=fixture(NORMAL,packet);p=run(&f);assert(p.result==HP_OK&&p.received==18&&p.host_seen&&p.reset_attempted);assert(f.requests==1);printf("PASS descriptor packets EP0=%u\n",packet);}
 {const uint32_t modes[]={NO_HOST,NO_DEVICE,STALL,TIMEOUT,OVERSIZE,SIE_FAIL,SHORT,BAD_DESC};
 const uint32_t results[]={HP_NOHOST,HP_NOATTACH,HP_STALL,HP_TIMEOUT,HP_COUNT,HP_SIE,HP_DESCRIPTOR,HP_DESCRIPTOR};
 for(i=0;i<8;i++){f=fixture(modes[i],8);p=run(&f);assert(p.result==results[i]);printf("PASS failure mode %u cannot report success\n",modes[i]);}}
 f=fixture(NORMAL,8);{hp_io io={begin,rd,wr,send,take,end,lines,&f};memset(&p,0,sizeof p);hp_start(&p,io,0xfffffff0u);hp_finish(&p,HP_CANCEL,5);assert(p.result==HP_CANCEL&&p.elapsed==21&&f.ended==1);}
 puts("PASS cancel restores device and timer wrap is bounded");return 0;
}
