/* SPDX-License-Identifier: MIT — independent diagnostic app. Never probes arbitrary RAM/MMIO. */
#include "app.h"
#include "fm1_flash_ext.h"
#define LAB_LO 0x97000u
#define LAB_HI 0xE0000u
#define LAB_SECTORS ((LAB_HI-LAB_LO)/4096u)
static volatile uint32_t scratch[8192] __attribute__((section(".pool")));
static uint32_t crc[LAB_SECTORS],blank[LAB_SECTORS];
static uint32_t scan_state,scan_sector,scan_at,scan_crc,scan_blank;
static uint32_t ram_state,ram_phase,ram_at,ram_error,requests,screen,keys_before,redraw_at;
static uint8_t wire_reply[200],raw[160];
static void put32(uint8_t *out,uint32_t value){uint32_t i;for(i=0;i<4;i++)out[i]=(uint8_t)(value>>(i*8));}
static uint32_t jedec(void){
#ifdef PLAT_HOST
 return 0; /* No fabricated hardware ID in a simulated report. */
#else
 return lab_boot_jedec;
#endif
}
static uint32_t simulated(void){
#ifdef PLAT_HOST
 return 1;
#else
 return 0;
#endif
}
static uint32_t stock_verified(void){
#ifdef PLAT_HOST
 return 0;
#else
 return flash_ok;
#endif
}
static int readable(void){return simulated()||stock_verified();}
static uint32_t crc_byte(uint32_t c,uint8_t value){uint32_t b;c^=value;for(b=0;b<8;b++)c=(c>>1)^((c&1)?0xedb88320u:0);return c;}
static int start_scan(void){uint32_t i;if(scan_state==1)return 2;if(!readable()){scan_state=3;return 3;}
 for(i=0;i<LAB_SECTORS;i++){crc[i]=0;blank[i]=0;}scan_state=1;scan_sector=scan_at=0;scan_crc=0xffffffffu;scan_blank=1;return 0;
}
static int start_ram(void){if(ram_state==1)return 2;ram_state=1;ram_phase=ram_at=0;ram_error=0xffffffffu;return 0;}
static uint32_t pattern(uint32_t index){return (index&1?0x55aa55aau:0xaa55aa55u)^(index*0x9e3779b9u);}
static void service(void){uint32_t i;
 if(scan_state==1){const uint8_t *p=plat_data(LAB_LO+scan_sector*4096+scan_at);if(!p){scan_state=3;return;}
  for(i=0;i<256;i++){scan_crc=crc_byte(scan_crc,p[i]);if(p[i]!=255)scan_blank=0;}scan_at+=256;
  if(scan_at==4096){crc[scan_sector]=~scan_crc;blank[scan_sector]=scan_blank;if(++scan_sector==LAB_SECTORS)scan_state=2;else{scan_at=0;scan_crc=0xffffffffu;scan_blank=1;}}
 }
 if(ram_state==1){for(i=0;i<256&&ram_at<8192;i++,ram_at++){
   if(!ram_phase)scratch[ram_at]=pattern(ram_at);
   else if(scratch[ram_at]!=pattern(ram_at)){ram_error=ram_at;ram_state=3;break;}
  }
  if(ram_state==1&&ram_at==8192){if(!ram_phase){ram_phase=1;ram_at=0;}else ram_state=2;}
 }
}
static void snapshot(uint8_t *out){uint32_t data_bss=0,pool_used=0,i;uint32_t fields[32]={0};
#ifndef PLAT_HOST
 extern uint32_t _data_start[],_data_end[],_bss_start[],_bss_end[],_pool_start[],_pool_end[];
 data_bss=(uintptr_t)_data_end-(uintptr_t)_data_start+(uintptr_t)_bss_end-(uintptr_t)_bss_start;pool_used=(uintptr_t)_pool_end-(uintptr_t)_pool_start;
 fields[6]=usb.up;fields[7]=usb.config;fields[8]=usb.resets;fields[9]=usb.rx_pkts;fields[10]=usb.tx_pkts;fields[11]=usb.timeouts;
#endif
 fields[0]=0x42414c5au;fields[1]=1;fields[2]=simulated();fields[3]=jedec();fields[4]=fm1_flash_size_from_jedec(jedec());fields[5]=stock_verified();
 fields[12]=sizeof scratch;fields[13]=ram_state;fields[14]=ram_at+ram_phase*8192;fields[15]=ram_error;fields[16]=scan_state;fields[17]=LAB_SECTORS;fields[18]=scan_sector;fields[19]=scan_at;
 fields[20]=98304;fields[21]=344064;fields[22]=data_bss;fields[23]=pool_used;fields[24]=0; /* host mode NOT tested */
 fields[25]=1; /* only allocated scratch tested, never arbitrary RAM */
 fields[26]=LAB_LO;fields[27]=LAB_HI;fields[28]=plat_ms();fields[29]=requests;
 for(i=0;i<32;i++)put32(out+i*4,fields[i]);
}
static void reply(uint32_t seq,uint32_t cmd,uint32_t status,const uint8_t *data,uint32_t n){uint32_t i=0,o=6,j;raw[0]=status;for(j=0;j<n;j++)raw[j+1]=data[j];n++;
 wire_reply[0]=240;wire_reply[1]=125;wire_reply[2]=90;wire_reply[3]=76;wire_reply[4]=seq;wire_reply[5]=cmd|64;
 while(i<n){uint32_t h=o++;wire_reply[h]=0;for(j=0;j<7&&i<n;j++,i++){wire_reply[h]|=(raw[i]>>7)<<j;wire_reply[o++]=raw[i]&127;}}wire_reply[o++]=247;plat_sysex_send(wire_reply,o);
}
int app_sysex(const uint8_t *wire,uint32_t length){uint8_t args[64],out[128];uint32_t i=5,n=0,j,seq,cmd,status=0,count=0;
 if(length<5||wire[0]!=125||wire[1]!=90||wire[2]!=76)return 0;
 seq=wire[3];cmd=wire[4];if(seq>127||cmd>63)return 1;requests++;
 while(i<length){uint32_t high=wire[i++];if(high>127){reply(seq,cmd,1,0,0);return 1;}for(j=0;j<7&&i<length;j++){if(n>=sizeof args||wire[i]>127){reply(seq,cmd,1,0,0);return 1;}args[n++]=wire[i++]|((high>>j&1)<<7);}}
 if(cmd==1&&n==0){const char *id="ZLAB/1/0.1.0";while(id[count]){out[count]=id[count];count++;}}
 else if(cmd==2&&n==0){snapshot(out);count=128;}
 else if(cmd==3&&n==2&&args[1]>0&&args[1]<=8&&args[0]+args[1]<=LAB_SECTORS){
  for(j=0;j<args[1];j++){uint32_t sector=args[0]+j;put32(out+j*16,LAB_LO+sector*4096);put32(out+j*16+4,crc[sector]);put32(out+j*16+8,blank[sector]);put32(out+j*16+12,sector<scan_sector);}count=args[1]*16;
 }
 else if(cmd==4&&n<=64){for(j=0;j<n;j++)out[j]=args[j];count=n;}
 else if(cmd==20&&n==0)status=start_scan();
 else if(cmd==21&&n==0)status=start_ram();
 else status=1;
 reply(seq,cmd,status,out,count);return 1;
}
static void number(uint32_t value,char *out,uint32_t hex){char temp[16];uint32_t i=0,base=hex?16:10;do{uint32_t digit=value%base;temp[i++]=(char)(digit<10?'0'+digit:'A'+digit-10);value/=base;}while(value);while(i)*out++=temp[--i];*out=0;}
static void row(uint32_t y,const char *name,const char *value){cv_begin(240,20,C_BLACK);cv_text(6,2,&FONT_XS,name,C_GRAY);cv_text(124,2,&FONT_XS,value,C_HI);cv_blit(0,y);}
static void draw(void){char b[24];uint8_t report[128];snapshot(report);
 cv_begin(240,40,C_BLACK);cv_text(6,1,&FONT_S,"ZOMBIE LAB 0.1.0",C_HI);cv_text(6,23,&FONT_XS,simulated()?"SIMULATED / NOT HARDWARE":"DIAGNOSTICS / READ ONLY",C_WHITE);cv_blit(0,0);
 if(screen==0){number(jedec(),b,1);row(44,"JEDEC ID",jedec()?b:"UNKNOWN");number(fm1_flash_size_from_jedec(jedec()),b,0);row(64,"INFERRED BYTES",jedec()?b:"UNKNOWN");row(84,"STOCK VERIFIED",stock_verified()?"YES":"NO");row(104,"RAM CAPACITY","96K + 336K");row(124,"PHYSICAL RAM","NOT PROBED");row(144,"USB HOST","NOT TESTED");row(164,"NV SAVES","BLOCKED");row(184,"UPDATE/ROLLBACK","AVAILABLE");}
 else if(screen==1){number(scan_sector,b,0);row(44,"FLASH SECTORS",b);row(64,"SCAN STATE",scan_state==0?"IDLE":scan_state==1?"RUNNING":scan_state==2?"COMPLETE":"UNAVAILABLE");row(84,"READ RANGE","97000..DFFFF");row(104,"METHOD","CRC32 + FF");row(124,"WRITES","NONE");row(144,"BLANK != FREE","REVIEW MAP");row(164,"DATA EXPORT","WEB / JSON");row(184,"PLAY","START SCAN");}
 else if(screen==2){number(sizeof scratch,b,0);row(44,"OWN RAM BYTES",b);row(64,"TEST STATE",ram_state==0?"IDLE":ram_state==1?"RUNNING":ram_state==2?"PASS":"FAIL");number(ram_at+ram_phase*8192,b,0);row(84,"WORDS / 16384",b);row(104,"OTHER RAM","UNTOUCHED");row(124,"EXTRA RAM","NOT DETECTED");row(144,"CPU1","OFF");row(164,"SDRAM RECONFIG","DISABLED");row(184,"REC","TEST OWN RAM");}
 else {row(44,"USB ROLE","DEVICE ONLY");row(64,"USB HOST","NOT TESTED");row(84,"5V VBUS OUTPUT","UNKNOWN");row(104,"DRIVE / FAT","NOT IMPLEMENTED");row(124,"USB MIDI","WEB PING");row(144,"FIRMWARE","FM-1_62000100");row(164,"HOST SWITCH","DISABLED");row(184,"FLASH > 1MB","NOT READ");}
 cv_begin(240,36,C_BLACK);cv_text(6,2,&FONT_XS,"SELECT: PAGE  PLAY: SCAN",C_GRAY);cv_text(6,18,&FONT_XS,"REC: RAM  SAVE: DISABLED",C_GRAY);cv_blit(0,204);
}
void app_init(void){uint32_t i;scan_state=scan_sector=scan_at=ram_state=ram_phase=ram_at=requests=screen=keys_before=redraw_at=0;ram_error=0xffffffffu;for(i=0;i<LAB_SECTORS;i++)crc[i]=blank[i]=0;}
void app_render(int32_t *lr,uint32_t n,uint32_t master){uint32_t i;(void)master;for(i=0;i<n*2;i++)lr[i]=0;}
void app_panic(void){}
void app_say(const char *a,const char *b){(void)a;(void)b;redraw_at=0;}
void app_ui_init(void){palette_set(0);draw();}
void app_input_only(void){uint32_t buttons=plat_buttons(),pressed=buttons&~keys_before;int delta=plat_enc(EN_SELECT);if(delta)screen=(screen+4+delta%4)%4;
 if(pressed>>B_HOME&1)screen=0;if(pressed>>B_EDIT&1)screen=1;if(pressed>>B_ENV&1)screen=2;if(pressed>>B_GLO&1)screen=3;
 if(pressed>>B_PLAY&1){start_scan();screen=1;}if(pressed>>B_REC&1){start_ram();screen=2;}keys_before=buttons;
}
void app_frame(void){app_input_only();service();if(plat_ms()-redraw_at>=100||!redraw_at){draw();redraw_at=plat_ms();}}
#ifdef PLAT_HOST
#include "lab_host.inc"
#endif
