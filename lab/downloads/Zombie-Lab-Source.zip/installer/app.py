"""Standalone Windows USB-MIDI updater for FM-1; Tk UI, worker-thread transport."""
import argparse
from datetime import datetime
import json
from pathlib import Path
import queue
import shutil
import sys
import threading
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import core
import editor_server
import ableton_profile

BASE = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
PROFILE = json.loads((BASE / 'profile.json').read_text(encoding='utf-8')) if (BASE / 'profile.json').exists() else {}
BUNDLED_FIRMWARE = BASE / 'firmware' / PROFILE.get('firmware', 'zombie-fm1-synth-0.2.0.fwsc')
BG, PANEL, TEXT, MUTED, GREEN = '#101b16', '#1b2a21', '#edf1dd', '#b2bfa5', '#b5e65a'


def backend():
    import mido
    mido.set_backend('mido.backends.rtmidi')
    return core.protocol.MidoBackend()


class Installer:
    def __init__(self, root):
        self.root, self.events = root, queue.Queue()
        self.busy, self.package = False, None
        self.lines = []
        self.editor_http, self.editor_url = None, None
        root.title(PROFILE.get('title', 'Зомби ФМ-1 · Установка прошивки'))
        root.geometry('900x880')
        root.minsize(820, 820)
        root.configure(bg=BG)
        root.protocol('WM_DELETE_WINDOW', self.close)
        style = ttk.Style(root)
        style.theme_use('clam')
        style.configure('TFrame', background=BG)
        style.configure('TLabel', background=BG, foreground=TEXT, font=('Segoe UI', 10))
        style.configure('Muted.TLabel', foreground=MUTED)
        style.configure('TButton', font=('Segoe UI', 10), padding=(12, 7))
        style.configure('Accent.TButton', background=GREEN, foreground=BG, font=('Segoe UI', 11, 'bold'))
        style.map('Accent.TButton', background=[('disabled', '#45523a'), ('active', '#d0f98d')])
        style.configure('TCheckbutton', background=BG, foreground=TEXT, font=('Segoe UI', 10))
        style.map('TCheckbutton', background=[('active', BG)])
        style.configure('Horizontal.TProgressbar', background=GREEN, troughcolor=PANEL)
        frame = ttk.Frame(root, padding=24)
        frame.pack(fill='both', expand=True)
        header = ttk.Frame(frame)
        header.pack(fill='x', pady=(0, 14))
        self.art = tk.PhotoImage(file=str(BASE / 'assets/splash.png')).subsample(2)
        tk.Label(header, image=self.art, bg=BG).pack(side='left', padx=(0, 18))
        title = ttk.Frame(header)
        title.pack(side='left', fill='both', expand=True)
        ttk.Label(title, text=PROFILE.get('heading', 'ЗОМБИ ФМ-1'), font=('Segoe UI', 24, 'bold'), foreground=GREEN).pack(anchor='w')
        ttk.Label(title, text='Установка прошивки по USB-MIDI', font=('Segoe UI', 12)).pack(anchor='w', pady=4)
        ttk.Label(title, text=PROFILE.get('subtitle', 'Synth 0.2 · сэмплер · USB-MIDI / USB audio'), style='Muted.TLabel').pack(anchor='w')
        launch_row = ttk.Frame(title)
        launch_row.pack(anchor="w", pady=(5, 0))
        self.editor_button = ttk.Button(launch_row, text='Диагностика / отчёт', command=self.open_editor)
        self.editor_button.pack(side='left')
        self.fl_profile_button = None
        if PROFILE.get('fl_profile'):
            self.fl_profile_button = ttk.Button(launch_row, text='Профиль FL Studio', command=self.install_fl_profile)
            self.fl_profile_button.pack(side='left', padx=(6, 0))
        self.ableton_profile_button = None
        if PROFILE.get('ableton_profile'):
            self.ableton_profile_button = ttk.Button(launch_row, text='Профиль Ableton', command=self.install_ableton_profile)
            self.ableton_profile_button.pack(side='left', padx=(6, 0))
        self.label(frame, '1   Выбери прошивку')
        row = ttk.Frame(frame)
        row.pack(fill='x', pady=(8, 4))
        self.file_name = tk.StringVar(value='Файл .fwsc не выбран')
        ttk.Label(row, textvariable=self.file_name, width=58).pack(side='left', fill='x', expand=True)
        self.browse = ttk.Button(row, text='Открыть .fwsc…', command=self.choose)
        self.browse.pack(side='right')
        self.package_text = tk.StringVar(value='Выбери готовую прошивку FM-1 в формате .fwsc.')
        ttk.Label(frame, textvariable=self.package_text, style='Muted.TLabel', wraplength=790).pack(anchor='w')
        self.label(frame, '2   Подключи FM-1', (0, 18))
        ttk.Label(frame, text='Подключи USB-кабель с передачей данных. Закрой FL Studio и другие MIDI-программы.',
                  style='Muted.TLabel', wraplength=790).pack(anchor='w', pady=(6, 8))
        row = ttk.Frame(frame)
        row.pack(fill='x')
        self.port = tk.StringVar(value='Автоматический поиск FM-1')
        self.ports = ttk.Combobox(row, textvariable=self.port, state='readonly', width=43,
                                  values=['Автоматический поиск FM-1'])
        self.ports.pack(side='left', fill='x', expand=True, padx=(0, 8))
        self.refresh = ttk.Button(row, text='Обновить USB', command=self.list_ports)
        self.refresh.pack(side='left', padx=(0, 8))
        self.detect = ttk.Button(row, text='Проверить FM-1', command=self.detect_device)
        self.detect.pack(side='left')
        self.device_text = tk.StringVar(value='Устройство ещё не проверено')
        ttk.Label(frame, textvariable=self.device_text, foreground=GREEN).pack(anchor='w', pady=(8, 0))
        self.label(frame, '3   Установи прошивку', (0, 18))
        ttk.Label(frame, text='Запись может стереть пресеты и проекты. Во время записи не отключай питание и USB.',
                  style='Muted.TLabel', wraplength=790).pack(anchor='w', pady=(6, 8))
        self.backup = tk.BooleanVar(value=False)
        self.backup_box = ttk.Checkbutton(frame, text='Я сохранил нужные данные и готов установить выбранную прошивку',
                                          variable=self.backup, command=self.update_controls)
        self.backup_box.pack(anchor='w')
        self.start = ttk.Button(frame, text='Установить на FM-1', style='Accent.TButton', command=self.start_install)
        self.start.pack(fill='x', pady=(12, 10))
        self.progress = ttk.Progressbar(frame, maximum=100)
        self.progress.pack(fill='x')
        self.status = tk.StringVar(value='Выбери готовый файл .fwsc, чтобы начать.')
        ttk.Label(frame, textvariable=self.status, wraplength=790).pack(anchor='w', pady=(7, 10))
        self.log = tk.Text(frame, height=5, bg=PANEL, fg=TEXT, relief='flat', font=('Consolas', 9),
                           wrap='word', padx=10, pady=8, state='disabled')
        self.log.pack(fill='both', expand=True)
        self.save_log = ttk.Button(frame, text='Сохранить журнал…', command=self.export_log)
        self.save_log.pack(anchor='e', pady=(6, 0))
        if BUNDLED_FIRMWARE.exists():
            self.load_package(BUNDLED_FIRMWARE)
        self.update_controls()
        self.root.after(75, self.poll)

    @staticmethod
    def label(frame, text, pady=(0, 0)):
        ttk.Label(frame, text=text, font=('Segoe UI', 12, 'bold')).pack(anchor='w', pady=pady)

    def append(self, text):
        line = f'{datetime.now():%H:%M:%S}  {text}'
        self.lines.append(line)
        self.log.configure(state='normal')
        self.log.insert('end', line + '\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def selected_port(self):
        return None if self.ports.current() <= 0 else self.port.get()

    def update_controls(self):
        for widget in (self.browse, self.refresh, self.detect, self.backup_box, self.editor_button):
            widget.configure(state='disabled' if self.busy else 'normal')
        self.ports.configure(state='disabled' if self.busy else 'readonly')
        self.start.configure(state='normal' if self.package and self.backup.get() and not self.busy else 'disabled')

    def choose(self):
        path = filedialog.askopenfilename(title='Выбери готовую прошивку FM-1',
                                          filetypes=[('Прошивка FM-1', '*.fwsc')])
        if not path:
            return
        self.load_package(path)

    def load_package(self, path):
        self.package = None
        self.backup.set(False)
        self.progress.configure(value=0)
        try:
            package = core.read_package(path)
            self.package = package
            self.file_name.set(package.path.name)
            self.package_text.set(f'{package.product} · {package.size:,} байт · CRC проверены\nSHA-256: {package.sha256}')
            self.status.set('Файл проверен. Подключи FM-1 и подтверди сохранение данных.')
            self.append(f'Выбран файл: {path}\nSHA-256: {package.sha256}')
        except Exception as exc:
            self.file_name.set('Файл не принят')
            self.package_text.set(str(exc))
            self.status.set('Выбери другой, исправный файл .fwsc.')
            messagebox.showerror('Прошивка не подходит', str(exc))
        self.update_controls()

    def task(self, function, kind):
        self.busy = True
        self.update_controls()
        def worker():
            try:
                self.events.put((kind, function()))
            except Exception as exc:
                self.events.put(('error', (str(exc), kind)))
            finally:
                self.events.put(('idle', None))
        threading.Thread(target=worker, daemon=True).start()

    def list_ports(self):
        self.status.set('Получаю список USB-MIDI портов…')
        self.task(lambda: backend().input_names(), 'ports')

    def detect_device(self):
        port = self.selected_port()
        self.status.set('Проверяю ответ FM-1…')
        self.task(lambda: core.inspect_device(backend(), port), 'device')

    def start_install(self):
        if self.busy or self.package is None or not self.backup.get():
            return
        package, port = self.package, self.selected_port()
        self.progress.configure(value=0)
        self.status.set('Проверяю файл и подключение…')
        self.append(f'Начало установки {package.product}')
        self.task(lambda: core.install(package, backend(), port,
                  lambda step, value=None: self.events.put(('progress', (step, value)))), 'done')

    def poll(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == 'idle':
                    self.busy = False
                    self.update_controls()
                elif kind == 'ports':
                    self.ports.configure(values=['Автоматический поиск FM-1', *value])
                    self.ports.current(0)
                    self.status.set(f'MIDI-входов: {len(value)}. Нажми «Проверить FM-1».')
                    self.append('MIDI-входы: ' + (', '.join(value) or 'нет'))
                elif kind == 'device':
                    ident, name, loader = value
                    self.device_text.set(f'{ident} · {name}' + (' · режим обновления' if loader else ''))
                    self.status.set('FM-1 найден и ответил на запрос.')
                    self.append(self.device_text.get())
                elif kind == 'progress':
                    step, argument = value
                    messages = {'start': f'FM-1 ответил: {argument}. Проверка пакета…',
                                'check': f'Устройство проверяет пакет: {argument} запросов',
                                'loader': 'Ожидаю загрузчик обновления…',
                                'write': f'Запись прошивки: {argument}%. Не отключай USB.',
                                'reboot': 'Перезапуск FM-1 и проверка версии…',
                                'done': f'Версия подтверждена: {argument}'}
                    self.status.set(messages.get(step, step))
                    if step == 'write':
                        # Percentage refers to addresses served, not flash verification.
                        self.progress.configure(value=argument)
                    if step not in ('write', 'check') or argument in (0, 100):
                        self.append(self.status.get())
                elif kind == 'done':
                    self.progress.configure(value=100)
                    self.status.set('Готово. FM-1 перезапустился, версия прошивки подтверждена.')
                    self.device_text.set(value)
                    self.backup.set(False)
                    self.append(self.status.get())
                    messagebox.showinfo('Установка завершена', f'FM-1 сообщил версию {value}.\nТеперь можно открыть FL Studio.')
                elif kind == 'error':
                    detail, operation = value
                    title = 'Установка не завершена' if operation == 'done' else 'Ошибка подключения'
                    self.status.set(title + '. Подробности в журнале.')
                    self.append(detail)
                    if operation == 'device':
                        self.device_text.set('FM-1 не найден')
                    messagebox.showerror(title, detail + ('\n\nЕсли запись уже началась, устройство может остаться '
                         'в режиме обновления. Повтори установку того же пакета.' if operation == 'done' else ''))
        except queue.Empty:
            pass
        self.root.after(75, self.poll)

    def export_log(self):
        path = filedialog.asksaveasfilename(defaultextension='.txt', initialfile='fm1-install-log.txt')
        if path:
            try:
                Path(path).write_text('\n'.join(self.lines), encoding='utf-8')
            except OSError as exc:
                messagebox.showerror('Не удалось сохранить журнал', str(exc))

    def install_fl_profile(self):
        default = Path.home() / 'Documents/Image-Line/FL Studio'
        folder = filedialog.askdirectory(title='Папка данных FL Studio (с папкой Settings внутри)', initialdir=str(default))
        if not folder:
            return
        folder = Path(folder)
        if not (folder / 'Settings').is_dir():
            messagebox.showerror('FL Studio', 'Выбери папку данных FL Studio, в которой находится папка Settings.')
            return
        source = BASE / 'fl-studio' / PROFILE['fl_profile']
        target = folder / 'Settings/Hardware' / PROFILE['fl_profile']
        try:
            target.mkdir(parents=True, exist_ok=True)
            for src in source.iterdir():
                if not src.is_file():
                    continue
                dst = target / src.name
                if dst.exists() and dst.read_bytes() != src.read_bytes():
                    shutil.copy2(dst, dst.with_name(dst.name + '.bak-' + datetime.now().strftime('%Y%m%d-%H%M%S')))
                shutil.copy2(src, dst)
            messagebox.showinfo('FL Studio', 'Профиль установлен. Перезапусти FL Studio.\nF10 → Input FM-1 → Enable → Controller type: Zombie Core FM-1.\nВходу и выходу назначь одинаковый свободный Port, например 20.')
        except Exception as exc:
            messagebox.showerror('FL Studio', str(exc))

    def install_ableton_profile(self):
        default = ableton_profile.find_user_library() or Path.home() / 'Documents/Ableton/User Library'
        folder = filedialog.askdirectory(title='Выбери User Library Ableton (Settings → Library)', initialdir=str(default))
        if not folder:
            return
        try:
            target = ableton_profile.install_profile(BASE / 'ableton' / PROFILE['ableton_profile'], folder)
            messagebox.showinfo('Ableton Live', 'Профиль установлен в:\n' + str(target) + '\n\nПерезапусти Live. Settings → Link, Tempo & MIDI → Control Surface: Zombie_Core_FM1.\nInput и Output: FM-1. Для клавиш включи Input Track и Arm MIDI-дорожки.')
        except Exception as exc:
            messagebox.showerror('Ableton Live', str(exc))

    def open_editor(self):
        try:
            if self.editor_http is None:
                self.editor_http, self.editor_url = editor_server.start(BASE / 'site')
            self.append('Редактор: ' + self.editor_url)
            self.status.set('В Chrome/Edge подключи Zombie Lab. Доступны проверка RAM, чтение карты flash и скачивание отчёта.')
            webbrowser.open(self.editor_url)
        except Exception as exc:
            messagebox.showerror('Не удалось открыть редактор', str(exc))

    def close(self):
        if self.busy:
            self.status.set('Дождись завершения операции. Во время записи закрывать программу нельзя.')
            return
        if self.editor_http:
            self.editor_http.shutdown()
            self.editor_http.server_close()
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--smoke-test', type=Path, help='Write GUI/backend diagnostics; never sends MIDI')
    args = parser.parse_args()
    root = tk.Tk()
    if args.smoke_test:
        root.withdraw()
        def diagnostic_error(title, detail):
            raise RuntimeError(f'{title}: {detail}')
        messagebox.showerror = diagnostic_error
    app = Installer(root)
    if args.smoke_test:
        root.update()
        midi = backend()
        report = dict(gui='ok', install_button=str(app.start.cget('state')),
                      midi_inputs=midi.input_names(), midi_outputs=midi.output_names(),
                      firmware_bundled=BUNDLED_FIRMWARE.exists(),
                      firmware_product=app.package.product if app.package else None,
                      firmware_sha256=app.package.sha256 if app.package else None,
                      width=root.winfo_reqwidth(), height=root.winfo_reqheight())
        if PROFILE.get('fl_profile'):
            import hashlib
            profile_file = BASE / 'fl-studio' / PROFILE['fl_profile'] / 'device_Zombie_Core_FM1.py'
            report['fl_profile_bundled'] = profile_file.exists()
            report['fl_profile_sha256'] = hashlib.sha256(profile_file.read_bytes()).hexdigest() if profile_file.exists() else None
            report['fl_profile_button'] = str(app.fl_profile_button.cget('state'))
        if PROFILE.get('ableton_profile'):
            import hashlib
            surface = BASE / 'ableton' / PROFILE['ableton_profile'] / 'surface.py'
            report['ableton_profile_bundled'] = surface.exists()
            report['ableton_profile_sha256'] = hashlib.sha256(surface.read_bytes()).hexdigest() if surface.exists() else None
            report['ableton_profile_button'] = str(app.ableton_profile_button.cget('state'))
        server, url = editor_server.start(BASE / 'site')
        try:
            import http.client
            connection = http.client.HTTPConnection('127.0.0.1', server.server_port, timeout=5)
            try:
                connection.request('GET', '/webapp/editor/')
                response = connection.getresponse()
                if response.status != 200:
                    raise RuntimeError(f'Local editor HTTP {response.status}')
                page = response.read()
            finally:
                connection.close()
            markers = [m.encode() for m in PROFILE.get('editor_markers', ['MC MOBS', 'p-samples'])]
            report['editor_http'] = 'ok' if all(m in page for m in markers) else 'failed'
            report['editor_url_loopback'] = url.startswith('http://127.0.0.1:')
        finally:
            server.shutdown()
            server.server_close()
        args.smoke_test.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        root.destroy()
    else:
        root.mainloop()


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        if '--smoke-test' in sys.argv:
            import traceback
            report_file = Path(sys.argv[sys.argv.index('--smoke-test') + 1])
            report_file.write_text(json.dumps({'error': str(exc), 'traceback': traceback.format_exc()},
                                  ensure_ascii=False, indent=2), encoding='utf-8')
            sys.exit(1)
        raise
