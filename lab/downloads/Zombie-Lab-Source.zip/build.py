"""MIT: isolated Zombie Lab build; never invokes the production Core build."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import os
import shutil
import subprocess
import sys

LAB=Path(__file__).resolve().parent
ROOT=LAB.parent
OUT=LAB/'output'
VERSION='0.1.0'
FW='zombie-lab-'+VERSION+'.fwsc'
EXE='Zombie-Lab-'+VERSION+'.exe'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def verify_main():
    baseline=json.loads((LAB/'MAIN-BASELINE.json').read_text())
    changed=[name for name,sha in baseline.items() if not (ROOT/name).is_file() or digest(ROOT/name)!=sha]
    if changed: raise RuntimeError('Production baseline differs: '+', '.join(changed))
    return len(baseline)
def run(args,env=None,log=None):
    result=subprocess.run([str(a) for a in args],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if log: log.write_bytes(result.stdout)
    if result.returncode:
        print(result.stdout.decode('utf-8',errors='replace'));raise SystemExit(result.returncode)
    return result.stdout.decode('utf-8',errors='replace')

verify_main()
(OUT/'verification').mkdir(parents=True,exist_ok=True)
env=dict(os.environ,PYTHONUTF8='1',JIELI_TOOLCHAIN=str(ROOT/'.tooling/jieli-win/C$/JL/pi32'),
 AC79_SDK=str(ROOT/'.tooling/ac79-sdk'),X0X_FONTSET='terminus',
 ZIG_GLOBAL_CACHE_DIR=str(ROOT/'.tooling/zig-global'),ZIG_LOCAL_CACHE_DIR=str(ROOT/'.tooling/zig-local'))
if '--package-only' not in sys.argv and '--installer-only' not in sys.argv:
    log=run([sys.executable,'-X','utf8',LAB/'platform/tools/build.py',LAB/'firmware','--release',VERSION],env,OUT/'verification/device-build.log')
    shutil.copy2(LAB/'firmware/build'/FW,OUT/FW)
    print(log[-1100:])
site=OUT/'site/webapp/editor';site.mkdir(parents=True,exist_ok=True)
for file in (LAB/'web').iterdir():
    if file.is_file(): shutil.copy2(file,site/file.name)
rollback=OUT/'Return-to-Zombie-Core-0.7.1.fwsc'
shutil.copy2(ROOT/'output/zombie-core-0.7.1.fwsc',rollback)
assert digest(rollback)==json.loads((LAB/'MAIN-BASELINE.json').read_text())['output/zombie-core-0.7.1.fwsc']
if '--firmware-only' in sys.argv:
    print('Main baseline verified:',verify_main(),'files');sys.exit(0)
profile=LAB/'installer/profile.json'
profile.write_text(json.dumps(dict(firmware=FW,title='Zombie Lab · ТЕСТОВАЯ ПРОШИВКА',heading='ZOMBIE LAB / TEST',
 subtitle='0.1.0 · диагностика памяти и USB · отдельный пакет',editor_markers=['ZOMBIE LAB','lab-connect']),ensure_ascii=False),encoding='utf-8')
if '--package-only' not in sys.argv:
    deps=ROOT/'.tooling/installer-deps';buildenv=dict(env,PYTHONPATH=str(deps),PYINSTALLER_CONFIG_DIR=str(LAB/'pyinstaller-config'))
    run([sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onefile','--windowed','--name','Zombie-Lab-'+VERSION,
     '--icon',LAB/'installer/assets/icon.ico','--distpath',OUT,'--workpath',LAB/'installer-build','--specpath',LAB/'installer-build',
     '--paths',LAB/'installer','--paths',deps,'--hidden-import','mido.backends.rtmidi','--hidden-import','rtmidi','--collect-all','rtmidi',
     '--add-data',str(LAB/'installer/assets')+';assets','--add-data',str(profile)+';.',
     '--add-data',str(OUT/'site')+';site','--add-data',str(OUT/FW)+';firmware',LAB/'installer/app.py'],buildenv,OUT/'verification/installer-build.log')
info=dict(version=VERSION,identity='FM-1_62000100',hardware_tested=False,main_unchanged_files=verify_main(),
 firmware_sha256=digest(OUT/FW),rollback_sha256=digest(rollback),usb_host=False,physical_ram_probed=False,
 owned_ram_test_bytes=32768,diagnostic_nv_writes=False,update_staging_allowed=[0xE0000,0xE5000],
 flash_read_range=[0x97000,0xE0000],installed_on_device=False)
(OUT/'LAB-BUILD-INFO.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
source=OUT/'Zombie-Lab-Source.zip'
with ZipFile(source,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for folder in ['firmware','platform','web','installer','tests']:
        for file in (LAB/folder).rglob('*'):
            if file.is_file() and not set(file.relative_to(LAB).parts)&{'build','__pycache__','.git'}:z.write(file,file.relative_to(LAB).as_posix())
    for name in ['build.py','README-RU.md','MAIN-BASELINE.json','LICENSE']:z.write(LAB/name,name)
archive=OUT/('Zombie-Lab-'+VERSION+'-Test-Windows.zip')
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=9) as z:
    for file,name in [(OUT/EXE,EXE),(OUT/FW,'firmware/'+FW),(rollback,'rollback/'+rollback.name),
                      (LAB/'README-RU.md','README-RU.md'),(OUT/'LAB-BUILD-INFO.json','LAB-BUILD-INFO.json'),(source,'source/'+source.name)]:z.write(file,name)
    for folder in ['site','verification']:
        for file in (OUT/folder).rglob('*'):
            if file.is_file() and file.suffix in ('.html','.css','.js','.json','.log','.png','.txt'):z.write(file,file.relative_to(OUT).as_posix())
    for file in (LAB/'platform').rglob('*LICENSE*'):
        if file.is_file():z.write(file,'licenses/platform/'+file.relative_to(LAB/'platform').as_posix())
    z.write(LAB/'LICENSE','licenses/Lab-MIT.txt')
    z.write(Path(sys.base_prefix)/'LICENSE.txt','licenses/Python.txt')
    for pattern in ['*.dist-info/LICENSE*','*.dist-info/COPYING*','*.dist-info/licenses/**/*']:
        for file in (ROOT/'.tooling/installer-deps').glob(pattern):
            if file.is_file():z.write(file,'licenses/python-deps/'+file.relative_to(ROOT/'.tooling/installer-deps').as_posix())
    for file in (Path(sys.base_prefix)/'tcl').glob('*/license*'):
        if file.is_file():z.write(file,'licenses/tcl/'+file.parent.name+'-'+file.name)
for file in [OUT/FW,OUT/EXE,source,archive]:file.with_suffix(file.suffix+'.sha256').write_text(digest(file)+'  '+file.name+'\n')
for file in [source,archive]:
    with ZipFile(file) as z:assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
print('Main baseline verified:',verify_main(),'files')
print('Ready:',OUT/EXE,archive)
